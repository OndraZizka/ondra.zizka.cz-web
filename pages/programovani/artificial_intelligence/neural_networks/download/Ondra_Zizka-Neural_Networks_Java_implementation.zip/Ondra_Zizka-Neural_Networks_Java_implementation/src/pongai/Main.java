/*
 * Main.java
 *
 * Created on 29. prosinec 2005, 18:56
 *
   Koncept: 
					 
	  Kazdy neuron ma neomezeny pocet transmitteru (odchozich)
	a receptoru (prichozich vlaken). T a R se napojuji na sebe.
	Mezi dvema neurony muze byt i vice primych spojeni.
	  Kazdy T i R ma koeficient, jimz se ovlivnuje sila 
	prochazejiciho signalu. Pri kazdem projiti signalu se tento
	koeficient zmeni o danou konstantu. Podle uspechu bude tato
	konstanta nejen velika, ale take bud kladna, nebo zaporna.
 */

package pongai;

/**
 *
 * @author Zizka
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void xmain(String[] args) {
        // TODO code application logic here
    }
    
}
