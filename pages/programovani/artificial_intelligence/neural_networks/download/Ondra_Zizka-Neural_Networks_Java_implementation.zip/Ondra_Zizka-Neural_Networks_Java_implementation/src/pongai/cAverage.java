/* cAverage.java */
package pongai;

/**  Po��t� aritmetick� pr�m�r z postupn� zad�van�ch vzork�.
 * @author Ondra �i�ka
 */
public class cAverage {
	
  /** Po�et vzork� */
	private int iSamples;
  /** Moment�ln� hodnota pr�m�ru */
	private double dCurAvg;
	//int iArrayCapacity;
	//ArrayList adSamples;
	
	
	/** Creates a new instance of cAverage */
	public cAverage() {
		iSamples = 0;
		dCurAvg = 0;
		//iArrayCapacity = 16;
		//adSamples = new ArrayList();
	}
	
  /** Vr�t� popis objektu ve form�tu cAverage{ avg:#dCurAvg, samples: #iSamples } */
	public String toString(){ return "cAverage{ avg:" + this.dCurAvg + ", samples: "+this.iSamples+" }"; }

  /** Vrac� moment�ln� hodnotu pr�m�ru. */
	public double GetAverage(){ return this.dCurAvg; }

  /** P�id� vzorek do pr�m�ru. */
	public void AddSample(double dSample){
		this.dCurAvg = (this.dCurAvg * this.iSamples + dSample) / (this.iSamples + 1);
		this.iSamples++;
	}

  /** Odebere vzorek z pr�m�ru. */
	public void RemSample(double dSample){
		this.dCurAvg = (this.dCurAvg * this.iSamples - dSample) / (this.iSamples - 1);
		this.iSamples--;
	}
	
}// class cAverage


	
 
/*  Test & Usage example:

	var oAvg = new cAverage();
	oAvg.AddSample(1.0);
	oAvg.AddSample(2.0);
	_dw.Write(oAvg);
	oAvg.AddSample(4.0);
	_dw.Write(oAvg);
	oAvg.RemSample(1.0);
	_dw.Write(oAvg);


	Output: 
	
cAverage{ avg:1.5, samples: 2 }
cAverage{ avg:2.3333333333333335, samples: 3 }
cAverage{ avg:3, samples: 2 }
*/