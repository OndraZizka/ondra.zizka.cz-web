/*
 * cFixedLengthQueue.java
 *
 * Created on 4. leden 2006, 15:26
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */
package pongai;


/** Fronta s fixn� d�lkou. push() vytla�� nejstar�� prvek.
 *  @author Ondra �i�ka  */
public class cFixedLengthQueue<E> extends java.util.LinkedList<E> {
  
  private int iCapacity;
  
  /** Vytvo�� frontu s danou fixn� kapacitou (d�lkou). */
  public cFixedLengthQueue(int iCapacity){
    this.iCapacity = Math.max(iCapacity, 0);
  }
  
  /** Pokud je fronta pln�, vytla�� nejstar�� prvek. */
  public void push(E e){
    this.add(e);
    while(this.size() >= this.iCapacity)
      this.poll();
  }
}
