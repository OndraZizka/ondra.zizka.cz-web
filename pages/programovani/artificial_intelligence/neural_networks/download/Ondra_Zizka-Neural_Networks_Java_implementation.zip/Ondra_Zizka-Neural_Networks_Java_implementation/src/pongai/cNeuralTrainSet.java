/*
 * cNeuralNetTrainSet.java
 *
 * Created on 4. leden 2006, 23:34
 */

package pongai;

import java.util.ArrayList;


/************************************************************
 * Tr�novac� mno�ina pro neuronovou s�. 
 *  @author Ondra �i�ka
 ***********************************************************/
public class cNeuralTrainSet{

	ArrayList<cNeuralTrainSetItem> aoItems;
	int _iIndex;
	
	public cNeuralTrainSet(){
		this.aoItems = new ArrayList();
		this._iIndex = 0;
	}

  /** P�id� vzorek do tr�novac� mno�iny. */
	public void Add(cNeuralTrainSetItem oTrainSetItem){
		this.aoItems.add(oTrainSetItem);
	}
  /** Vyhod� v�echny prvky z tr�novac� mno�iny. */
	public void Clear(){ this.aoItems = new ArrayList(); this._iIndex = 0; }
	
  /** Vr�t� vzorek tr�novac� mno�iny z dan� pozice. */
	public cNeuralTrainSetItem GetAt(int iIndex){
		if( iIndex < this.aoItems.size() )
			return this.aoItems.get(iIndex);
		else return null;
	}
  /** Vr�t� n�hodn� vzorek z mno�iny. */
	public cNeuralTrainSetItem GetRandom(){
    if(this.aoItems.size() == 0)
      return null;
		int iIndex = ((int)Math.floor(Math.random() * this.aoItems.size())) % this.aoItems.size();
		return this.aoItems.get(iIndex);
	}


	// Iterator related 
	public void resetIterator(){ this._iIndex = 0; }
	public boolean hasNext(){ return ( this._iIndex < this.aoItems.size() ); }
	public cNeuralTrainSetItem next(){ return this.aoItems.get(this._iIndex++); }

}// class cNeuralTrainSet
