package pongai;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**************************************************************
  T��da pro obecnou neuronovou s�                             
 *  @author Ondra �i�ka
**************************************************************/
public class cNeuralNet{
	
	ArrayList aNeurons;
	ArrayList aoInputNeurons;
	ArrayList aoOutputNeurons;
	double dMinWeight;
	double dMaxWeight;
	ArrayList aoNeuronsOrder;                         // Po�ad� v�po�tu neuron� 
	Boolean bContainsCycles;
	
  /** Vytvo�� neuronovou s� s dan�m po�tem (nepropojen�ch) neuron�.
   * @param iNumberOfNeurons Po��te�n� po�et neuron� v s�ti 
   * @param dMinWeight Minim�ln� v�ha synapse p�i generov�n� n�hodn�ch vah
   * @param dMaxWeight Maxim�ln� v�ha synapse p�i generov�n� n�hodn�ch vah
   */
	cNeuralNet(int iNumberOfNeurons, double dMinWeight, double dMaxWeight){
		this.CreateNeurons(iNumberOfNeurons);
		this.aoInputNeurons  = new ArrayList();
		this.aoOutputNeurons = new ArrayList();
		this.dMinWeight = dMinWeight;
		this.dMaxWeight = dMaxWeight;
		this.aoNeuronsOrder  = null;                         // Po�ad� v�po�tu neuron� 
		this.bContainsCycles = null;                         // Jestli obsahuje cykly  
	}
  /** Defaultn� hodnoty pro dMinWeight: 0.05, dMaxWeight: 0.30 */
	cNeuralNet(int iNumberOfNeurons){ this(iNumberOfNeurons, 0.05, 0.30); }

  /** Vytvo�� a vr�t� (nepropojen�) neuron, s dan�m ID, s danou vnitn�n� funkc�
   * @param iID     Pokud je 0, nov� neuron bude m�t vygenerovan� ID unik�tn�m pro tuto s�.
   *                Jinak p�ijme zadan� (unik�tnost se nekontroluje).
   * @param dValue  Hodnota... k ni�emu to nen�.
   * @param dBias   V�ha u x0 - p��davn�ho vstupu. Pou��v�no p�i nahr�v�n� s�t�.
   * @param sFuncID  String ID vybran� funkce. Fungovalo v JavaScriptu, v Java verzi jen Sigmoida.
   */
	public cNeuron CreateNeuron(int iID, double dValue, double dBias, String sFuncID){
		return new cNeuron(iID, dValue, dBias /*, sFuncID*/);
	}
  /** Vytvo�� a vr�t� neuron s vygenerovan�m ID unik�tn�m pro tuto s� defaultn�mi �i n�hodn�mi hodnotami */
	public cNeuron CreateNeuron(){ return new cNeuron(); }

  /** Vygeneruje dan� po�et neuron� a vlo�� je do s�t�. */
	public void CreateNeurons(int iNumberOfNeurons){
		this.aNeurons = new ArrayList();    // neurons    
		for(int i = iNumberOfNeurons; i > 0; i--){
			//this.aNeurons.push(new cNeuron());
			this.aNeurons.add(this.CreateNeuron());
		}
	}


	/** Spoji dva neurony smerovanym spojenim - u jednoho prida transmitter, u druheho receptor
   *  @param oNeuronFrom  Neuron, ze kter�ho spojit.
   *  @param oNeuronTo    Neuron, do kter�ho spojit.
   *  @param dWeight      V�ha, kter� se na synapsi nastav�.
   */
	public boolean ConnectFromTo(cNeuron oNeuronFrom, cNeuron oNeuronTo, double dWeight){
		if( null == oNeuronFrom || null == oNeuronTo || oNeuronFrom == oNeuronTo ) return false;
		Debug.Write(Debug.E_NOTICE, 1002, "ConnectFromTo( "+(oNeuronFrom.id)+" -> "+(oNeuronTo.id)+" , W: "+dWeight+" )");

		this.aoNeuronsOrder  = null;   // Zru��me p��padn� spo��tan� po�ad� v�po�tu neuron� 
		this.bContainsCycles = null;   // Zru��me p��padn� spo��tanou informaci, jestli obsahuje cykly 

		cSynapse oSynapse = new cSynapse(oNeuronFrom, oNeuronTo, dWeight);
		oNeuronFrom.AddTrans(oSynapse);
		oNeuronTo.AddRecep(oSynapse);
		return true;
	}
  /** Verze s n�hodn� nastavenou v�hou. */
	public boolean ConnectFromTo(cNeuron oNeuronFrom, cNeuron oNeuronTo){
		// Nahodn� v�ha 
		double dWeight = ( Math.random() * (this.dMaxWeight - this.dMinWeight) + this.dMinWeight )  *  ((Math.random() < 0.5) ? -1 : 1);
		return ConnectFromTo(oNeuronFrom, oNeuronTo, dWeight);
	}
	




	/**************************************************************
		V�po�et neuronov� s�t�                                       
	**************************************************************/
	public void Compute(){
		ArrayList aoCurNeurons;
		HashSet setNextNeurons = new HashSet();
		HashSet setDoneNeurons = new HashSet();
		cNeuron oCurNeuron;

		int _iRounds = 0;

		aoCurNeurons = this.aoInputNeurons;

		// Dokud jsou ve front� na v�po�et n�jak� neurony... 
		while(aoCurNeurons.size() > 0) {

			Debug.Write(Debug.E_NOTICE, 1001, "Starting computing round #"+(_iRounds++)+""); ///

			// Pro v�echny neurony ve front� na v�po�et v tomto kole... 
			Iterator i = aoCurNeurons.iterator();
			//for( var i in aoCurNeurons ){
			while(i.hasNext()){

				//oCurNeuron = aoCurNeurons[i];
				oCurNeuron = (cNeuron)i.next();
					//Debug.Write("Computing neuron { "+(oCurNeuron.id)+" }"); ///
				oCurNeuron.Compute();
				setDoneNeurons.add(oCurNeuron);


				//Debug.Write("- Following: [ "+(oCurNeuron.aTrans)+" ]"); ///

				// Pro v�echny navazuj�c� neurony... 
				Iterator j = oCurNeuron.aTrans.iterator();
				//for( var j in oCurNeuron.aTrans ){
				while(j.hasNext()){
					// var oToNeuron = oCurNeuron.aTrans[j].oTo;
					cNeuron oToNeuron = (cNeuron)( ((cSynapse)j.next()).oTo );
					// ...pokud u� navazuj�c� neuron nen� vypo�ten�, 
					if( oToNeuron != null  &&  !setDoneNeurons.contains(oToNeuron) )
						// p�id�me ho do fronty na v�po�et v dal��m kole. 
						setNextNeurons.add(oToNeuron);
				}
			}
			//aoCurNeurons = setNextNeurons.getMembers();
			//Object[] aSetMembers = setNextNeurons.toArray();
			//aoCurNeurons = new ArrayList(aSetMembers);
			aoCurNeurons = new ArrayList(setNextNeurons);
			setNextNeurons.clear();
		}

		//Debug.Write("."); ///
		Debug.Write(Debug.E_NOTICE, 1001, "Computing finished."); ///

	}


 




	/***************************************************************************************
		Rozhodnem, jestli s� obsahuje smy�ky.                                                
		Pokud ne, vyhled� bezprobl�mov� po�ad� v�po�tu neuron�.                               
			Koncept proch�zen� s�t�: 
			- Jsou dv� mno�iny:              (lib.cSet.js) 
				- setDoneNeurons - uchov�v� neurony se spo�ten�m errorem 
				- setNextNeurons - obsahuje kandid�ty na v�po�et v dal��m kole (while)
			- V ka�d�m kole se projdou kandid�ti a zjist� se, jestli v�echny jejich 
				odchoz� synapse vedou do ji� spo�ten�ch neuron� (setDoneNeurons.has(...)).
				- Pokud ne, neuron se ponech� mezi kandid�ty.
				- Pokud ano, neuron se spo�te (dError),
					odstran� se z kandid�t� (setNextNeurons.remove(...)),
					vlo�� se do spo�ten�ch (setDoneNeurons.put()),
					a neurony do n�j vch�zej�c� se p�idaj� do kandid�t� (setNextNeurons.put()).
			- Tento algoritmus nefunguje, pokud s� obsahuje smy�ky.
	***************************************************************************************/
	public ArrayList FindComputingOrder(){

		// Pracovn� prostor... 
		ArrayList aoCurNeurons;
		ArrayList aoNeuronsOrder = new ArrayList();
		HashSet setNextNeurons = new HashSet();
		HashSet setDoneNeurons = new HashSet();
		cNeuron oCurNeuron;
		int _iRounds = 0;

		aoCurNeurons = this.aoOutputNeurons;

		// Dokud jsou ve front� na v�po�et n�jak� neurony... 
		while(aoCurNeurons.size() > 0) {
			Debug.Write(Debug.E_NOTHING, 2311, "."); ///
			Debug.Write(Debug.E_NOTICE, 2312, "Starting backprop round #"+(_iRounds++)+""); ///

			try{
			// Pro v�echny neurony ve front� na v�po�et v tomto kole... 
			Iterator i = aoCurNeurons.iterator();
			for_aoCurNeurons:
			//for( var i in aoCurNeurons ){
			while(i.hasNext()){
				//oCurNeuron = aoCurNeurons[i];
				oCurNeuron = (cNeuron)i.next();
					Debug.Write(Debug.E_NOTICE, 2313, "- Traversing "+(oCurNeuron.toStringFull())+""); ///
				Iterator j; // for cycles 


				// Projedem navazuj�c� neurony 
				boolean bRefersToNonProcessedNeuron = false;
				j = oCurNeuron.aTrans.iterator();
				//for( j in oCurNeuron.aTrans ){
				while(j.hasNext()){
					//var oSynapseOut = oCurNeuron.aTrans[j];
					cSynapse oSynapseOut = (cSynapse)j.next();
					if( oSynapseOut.oTo == null )  continue;  // Pseudoneuron (v�stupn� nebo tak n�co)
					// Pokud neuron je�t� nem� spo�ten dError, p�esko��me ho, a nech�me ho je�t� ve front� na zpracov�n�. 
					if( !setDoneNeurons.contains(oSynapseOut.oTo) ){
						Debug.Write(Debug.E_NOTICE, 2313, "-- Skipping - has synapse to non-ready neuron."); ///
						break for_aoCurNeurons;
					}
				}

				setDoneNeurons.add(oCurNeuron);     // P�id�me zpracov�van� neuron mezi hotov�. 
				setNextNeurons.remove(oCurNeuron);  // Odstran�me zpracov�van� neuron z fronty na zpracov�n�.
				// Neurony bez vstup� p�esko��me - to jsou vstupn� pseudoneurony s hodnotami 
				if( oCurNeuron.aRecep.size() != 0 ){
					aoNeuronsOrder.add(oCurNeuron);    // Ulo��me zpracov�van� neuron do po�ad�.   
				}



					//Debug.Write("- Following: [ "+(oCurNeuron.aRecep)+" ]"); ///

				// Pro v�echny p�edch�zej�c� neurony... 
				j = oCurNeuron.aRecep.iterator();
				//for( j in oCurNeuron.aRecep ){
				while(j.hasNext()){
					// var oFromNeuron = oCurNeuron.aRecep[j].oFrom;
					cNeuron oFromNeuron = (cNeuron)j.next();
					if( oFromNeuron == null )  continue;

					// Pokud u� nen� hotov�, 
					if( !setDoneNeurons.contains(oFromNeuron) ){						
						// p�id�me ho do fronty na v�po�et v dal��m kole. 
						setNextNeurons.add(oFromNeuron);
					}
				}
				Debug.Write(Debug.E_NOTICE, 2313, "+ Traversed "+(oCurNeuron.toStringFull())+""); ///

			}// for( var i in aoCurNeurons )			
			}catch(Exception e){ Debug.Write(Debug.E_ERROR, 2314, "... Exception " + e); }

			// V setNextNeurons m�me mno�inu neuron� na dal�� kolo backpropagation. 
			//aoCurNeurons = setNextNeurons.getMembers();
			aoCurNeurons = new ArrayList(setNextNeurons);
			//setNextNeurons.clear();     // Neurony se odstra�uj�, kdy� jsou spo�ten�. 

		}// while()

		Debug.Write(Debug.E_NOTHING, 2313, "."); ///
		Debug.Write(Debug.E_NOTHING, 2313, "Traversing finished."); ///

		return this.aoNeuronsOrder = aoNeuronsOrder;
	}


	
  

	/** Serializace. Ulo�� neuronovou s� do textu, z n�ho� se d� zrekonstruovat.
   * @see #Unserialize(String)
   */
	public String Serialize(){
		String sSaveString = "";

		sSaveString += "@neurons\n";
		sSaveString += "# id : dValue : dBias : fFunc [ : oNeuronTo.id / dWeight ]*\n";

		//for( var i in this.aoNeuronsOrder ){
		Iterator i = aoNeuronsOrder.iterator();
		while(i.hasNext()) {
			cNeuron oN = (cNeuron)i.next();
			// id, dValue, dBias, fFunc, 
			sSaveString += oN.id+":"+oN.dValue+":"+oN.dBias+":"+oN.fFunc.getID()+"";
			//for( var j in oN.aTrans ){
			Iterator j = oN.aTrans.iterator();
			while(j.hasNext()){
				// dWeight, oFrom, oTo
				cSynapse oS = (cSynapse)j.next();
				if( null == oS.oTo ) continue; // N�jak� pseudosynapse - asi v�stupn� vrstva 
				sSaveString += ":"+(oS.oTo == null ? "null" : oS.oTo.id)+"/"+oS.dWeight+"";
			}
			sSaveString += "\n";
		}

		sSaveString += "@input";
		//for( var i in this.aoInputNeurons ){ sSaveString += " "+this.aoInputNeurons[i].id; }
		i = aoInputNeurons.iterator();
		while(i.hasNext()) { cNeuron oN = (cNeuron)i.next(); sSaveString += " "+oN.id; }
		sSaveString += "\n";

		sSaveString += "@output";
		//for( var i in this.aoOutputNeurons ){ sSaveString += " "+this.aoOutputNeurons[i].id; }
		i = aoOutputNeurons.iterator();
		while(i.hasNext()) { cNeuron oN = (cNeuron)i.next(); sSaveString += " "+oN.id; }
		sSaveString += "\n";

		sSaveString += "@cycles "+this.bContainsCycles+"\n";

		return sSaveString;
	}

  
  
  
  
  
  
  
  /** Deserializace. Ze Stringu zrekonstruuje v n�m zapsanou s�. */
	public void Unserialize(String sSaveString) throws Exception {
		String[] asLines = sSaveString.split("\n", -1);

		// V�sledky 
		ArrayList aoNeurons = new ArrayList();
		ArrayList aoInputNeurons = new ArrayList();
		ArrayList aoOutputNeurons = new ArrayList();
		HashMap aoPendingSynapses = new HashMap();
		String sNetType = null;

		// 0 - nothing; 1 - neurons 
		int iMode = 0;

		// Pro v�echny ��dky 
		//for( var i in asLines ){
		for(String sLine : asLines){
			if('#' == sLine.charAt(0)) continue;
			
			//String[] asReResult = sLine.match( /^@(\w+)(\s+(.*))?/ );
			Pattern p = Pattern.compile("^@(\\w+)(\\s+(.*))?");
			Matcher m = p.matcher(sLine);
			//if("@" == sLine.charAt(0)){
			//if(null != asReResult){
			if(m.matches()){
				String sKeywordParams = m.group(3);
				iMode = 0;
				ArrayList aoIONeurons = aoInputNeurons;
				//if("neurons" == sLine.substring()){
				String sKeyword = m.group(1);
				if(sKeyword == "neurons") iMode = 1;
				if(sKeyword == "nettype")	sNetType = sKeywordParams;
				if(sKeyword == "output")                   // Abych nemusel ps�t znova ten samej k�d, ud�l�me fintu. 
					aoIONeurons = aoOutputNeurons;           // aoIONeurons je bu? aoO... nebo aoI..., podle keywordu.
				if(sKeyword == "output" || sKeyword == "input"){
					String saNeuronIDs = sKeywordParams;
					String[] asNeuronIDs = saNeuronIDs.split(" ");
					for( String sInpNeuID : asNeuronIDs ){
						int iInpNeuID = Integer.valueOf(sInpNeuID);
						if( null == aoNeurons.get(iInpNeuID) )
							throw new Exception("Undefined neuron: ID = "+iInpNeuID+"");
						aoIONeurons.add( aoNeurons.get(iInpNeuID) );
					}
				}
				
				if(sKeyword == "cycles"){
					if     (sKeywordParams == "false") this.bContainsCycles = false;
					else if(sKeywordParams == "true")  this.bContainsCycles = true;
					else                               this.bContainsCycles = null;
				}
				
			}// if(m.matches()){
			
			// Na za��tku nen� "@" 
			else if(iMode == 1){
				// id : dValue : dBias : fFunc [ : oNeuronTo.id / dWeight ]* 
				String[] asParts = sLine.split(":");
				if( asParts.length < 4 )
					throw new Exception("cNeuralNet::Unserialize(): Neuron has to be defined as \"id : dValue : dBias : fFunc [ : oNeuronTo.id / dWeight ]*\"");
															 // iID, dValue, dBias, sFuncID 
				cNeuron oNeuron = new cNeuron(Integer.valueOf(asParts[0]), Double.valueOf(asParts[1]), Double.valueOf(asParts[2])/*, (asParts[3])*/);
				aoNeurons.ensureCapacity(oNeuron.id + 1);
				aoNeurons.set(oNeuron.id, oNeuron);

				for( int iTrans = 4; iTrans < asParts.length; iTrans++ ){
					// oNeuronTo.id / dWeight
					String[] asSynapse = asParts[iTrans].split("/");
					int iToId = Integer.valueOf(asSynapse[0]);
					double dWeight = Double.valueOf(asSynapse[1]);

					// Pokud nen� navazuj�c� neuron je�t� vytvo�en�, d�me si spojen� do fronty pro neuron s dan�m ID. 
					if( null == aoNeurons.get(iToId) ){
						//throw new Exception("No such neuron ID");
						if( null == aoPendingSynapses.get(iToId) ) aoPendingSynapses.put(iToId, new ArrayList());
						((ArrayList)(aoPendingSynapses.get(iToId))).add( new cSynapse( oNeuron, null, dWeight) );
					}
					// Jinak tu synapsi vytvo��me.
					else
						this.ConnectFromTo(oNeuron, (cNeuron)aoNeurons.get(iToId), dWeight);

					// Pokud na tento neuron ji� �ekaj� n�jak� p��choz� synapse, vytvo��me.
					ArrayList aoSynapses;
					if( null != (aoSynapses = (ArrayList)aoPendingSynapses.get(oNeuron.id)) /* && "object" == typeof aoPendingSynapses[oNeuron.id] */ ){
						Iterator iSynIndex = aoSynapses.iterator();
						//for( var iSynIndex in aoPendingSynapses.get(oNeuron.id) )
						while(iSynIndex.hasNext()){
							cSynapse oSynapse = (cSynapse)iSynIndex.next();
							this.ConnectFromTo(
								oSynapse.oFrom,
								oNeuron,
								oSynapse.dWeight );
						}
					}
				}
			}// Na za��tku nen� "@" - else if(iMode == 1)

		}// Pro v�echny ��dky - for( var i in asLines )

		this.aoNeuronsOrder = aoNeurons;

	}



}// class cNeuralNet









