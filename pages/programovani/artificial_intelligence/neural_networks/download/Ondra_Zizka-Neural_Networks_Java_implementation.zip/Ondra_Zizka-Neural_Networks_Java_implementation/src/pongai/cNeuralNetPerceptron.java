/*
 * cNeuralNetPerceptron.java
 *
 * Created on 1. leden 2006, 3:36
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package pongai;

import java.util.ArrayList;

/***************************************************************************** 
 * Trida pro perceptron.                                         
 *
 *  P�et�en je jen konstruktor, kter� podle pole po�tu neuron� ve vrstv�ch
 *  vytvo�� p��slu�n� po�et neuron�, propoj� je, a neurony
 *  z prvn�, resp. posledn� vrstvy ur�� jako vstupn�, resp. v�stupn�.
 *
 *  @author Ondra �i�ka
 *****************************************************************************/
public class cNeuralNetPerceptron extends cNeuralNet {
	
	public ArrayList aaLayers;
	
  /** Se�te pole integer�.
   @param ai Pole integer� k se�ten�. */
	private static int SumArrayOfIntegers(int[] ai){
		int iSum = 0;
		for(int iNum : ai) iSum += iNum;
		return iSum;
	}
	
	/** Vytvo�� neuronovou s� typu perceptron a propoj� neurony podle zadan�ch po�t� neuron� na vrstv�ch.
   * @param aiLevels  Pole s po�ty neuron� ve vrstv�ch.
   *    <code>aiLevels[0]</code> je vstupn� vrstva,
   *    <code>aiLevels[aiLevels.length-1]</code> je v�stupn� vrstva,
   *    vrstvy mezi nimi jsou vnit�n� (v dan�m po�ad�)
   */
	public cNeuralNetPerceptron(int[] aiLevels) {
		//int iCellsNum = 0;
		//for(int iNeuronsNum : aiLevels) iCellsNum += iNeuronsNum;
		super(SumArrayOfIntegers(aiLevels));

		this.aaLayers = new ArrayList(aiLevels.length);
		int iNeuron = 0;
		cNeuron oCurNeuron;

		// -- Za�azen� do vrstev a propojen� -- //

		// Pro v�echny vrstvy 
		for(int i = 0; i < aiLevels.length; i++){
			this.aaLayers.add(new ArrayList(aiLevels[i]));
			// Pro v�echen po�et neuron? ve vrstv� 
			for( int j = 0; j < aiLevels[i]; j++ ){
				// vezmeme dal�� (dosud voln�) neuron ze s�t� a p?i?ad�me ho vrstv� 
				oCurNeuron = (cNeuron)this.aNeurons.get(iNeuron++);
				((ArrayList)this.aaLayers.get(i)).add( oCurNeuron );
				// Pro v�echny neurony p?edchoz� vrstvy 
				if(i > 0)
				//for( int k = 0; k < this.aaLayers[i-1].length; k++ ) {
				for( Object oN : ((ArrayList)(this.aaLayers.get(i-1))) ) {
					// spoj�me s nimi tento nov� neuron.
					//this.ConnectFromTo(this.aaLayers[i-1][k], oCurNeuron);
					this.ConnectFromTo( (cNeuron)oN, oCurNeuron);
				}
			}
		}

		// Pro v�echny neurony prvn� vrstvy - d�me je do seznamu vstupn�ch neuron? 
		//for( var k = 0; k < this.aaLayers[0].length; k++ ){
		for( Object oN : ((ArrayList)(this.aaLayers.get(0))) ){
			//this.aoInputNeurons.add( this.aaLayers[0][k] );
			this.aoInputNeurons.add( oN );
		}
		// To sam� pro posledn� vrstvu - do seznamu v�stupn�ch neuron? 
		//for( var k = 0; k < this.aaLayers[this.aaLayers.length-1].length; k++ ){
		ArrayList oLastLayer = (ArrayList)this.aaLayers.get(this.aaLayers.size()-1);
		for( Object oN : oLastLayer ){
			this.aoOutputNeurons.add( oN );
		}
		//Debug.Write(oLastLayer); ///
    
    this.FindComputingOrder();
		
	}// public cNeuralNetPerceptron(int[] aiLevels) - konstruktor
	
}// class cNeuralNetPerceptron extends cNeuralNet


