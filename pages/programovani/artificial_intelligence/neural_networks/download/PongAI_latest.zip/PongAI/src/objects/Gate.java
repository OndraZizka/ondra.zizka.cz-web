package objects;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

/**
 *
 * <p>Title: Object, what search if collides with activator. Activator is registered dynamic object. If colission
 * occurs, then event is fired to all registered listeners.</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Gate extends SimulationObject {
    ArrayList myGatelistener;
    ArrayList opponentGatelistener;

    public Gate(GateListener myGatelistener, GateListener opponentGatelistener) {
        this.myGatelistener = new ArrayList();
        this.addMyGateListener(myGatelistener);
        this.opponentGatelistener = new ArrayList();
        this.addOpponentGateListener(opponentGatelistener);
    }

    /**
     * method sets myGatelistener, what implements behavior of goalMade event
     * 
     * 
     * @param listener GateListener
     */
    public void addMyGateListener(GateListener listener) {
        this.myGatelistener.add(listener);
    }

    /**
     * implements behavior in each step
     */
    public void doAction() {
        Iterator en;
        Iterator iterator;
        en = oponents.iterator();

        // we have to iterate among all activators
        while (en.hasNext()) {
            SimulationObject obj = (SimulationObject) en.next();
            if (this.colidesWith(obj)) {
                // if activtion ocurs, then goalMade method of Gatelistener is called
                iterator = myGatelistener.listIterator();
                while (iterator.hasNext()) {
                    ((GateListener) iterator.next()).goalMade();
                }
                // if activtion ocurs, then goalReceived method of Gatelistener is called
                iterator = opponentGatelistener.listIterator();
                while (iterator.hasNext()) {
                    ((GateListener) iterator.next()).goalReceived();
                }                
            }
            // = this.myGatelistener.;
        }
    }

    private void addOpponentGateListener(GateListener opponentGatelistener) {
        this.opponentGatelistener.add(opponentGatelistener);
    }
}
