/**
 *
 * <p>Title: Wall</p>
 *
 * <p>Description: Class for static object. This object can be registered into Ball. If is registered and
 * ball colides with this wall, then ball is forced to change vector of velocity.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */


package objects;

public class Wall extends SimulationObject {
    public Wall() {
    }
}
