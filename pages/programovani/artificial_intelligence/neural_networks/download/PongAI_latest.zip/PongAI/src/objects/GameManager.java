package objects;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Component;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.Point;
import java.util.Random;
import pongai.Debug;

/**
 * <p>Description: This manager implements all functionality of simulation model. At the start is run new thread.
 * There is neverending loop in which is called action for all dynamic objects. Each dynamic object implements its own
 * functionality.</p>
 *
 * @author Tom� B�trla
 * @version 1.0
 */
public class GameManager extends Component implements Runnable, MouseMotionListener, GateListener {
  
    public boolean bShowNetCreatingMessages  = false;
    public boolean bShowNetComputingMessages = false;
    public boolean bShowNetAdjustingMessages = false;
    public boolean bShowHitsStoreMessages    = false;

    private static GameManager instance;
    public static final int MaxIterations = 2000;
    
    // Mode 
    public static final int MODE_LEARNING = 2;
    public static final int MODE_PRESENTING = 1;
    private int iMode;
    public int GetMode(){ return this.iMode; }
    public void SetMode(int iMode){
      this.iMode = iMode;
      this.ToggleDebugMessages();
    }
    public void SwitchMode(){ this.SetMode(this.iMode == MODE_PRESENTING ? MODE_LEARNING : MODE_PRESENTING); }

    Agent[] agents = new Agent[2];
    Ball[] balls = new Ball[1];
    Wall[] walls = new Wall[4];
    Gate[] gates = new Gate[2];
    
    Thread t;
    Point old;
    State state;

    
    /************** GameManager **************************/
    public GameManager() {
      GameManager.instance = this;
      this.iMode = GameManager.MODE_PRESENTING;
      //this.iMode = GameManager.MODE_LEARNING;
      
      Debug.DebugOnOff(0);
      agents[0] = new Agent("James Bond");
      agents[1] = new Agent("Diego Maradona");
      state = new State();
      
      this.restart();
      //this.addMouseMotionListener(this);
      
    }
    public static GameManager getInstance(){ return GameManager.instance; }
    
    
     /** If goal event occurs, then this method is called. **/
    public void goalMade() {
        this.restart();
    }
    public void goalReceived() {
        this.restart();
    }


    public State getState(){
        return this.state;
    }


    
    public void start(){
        t = new Thread(this);
        t.start();
    }



    /****************************************************************
     *  Run - smy�ka
     ***************************************************************/
    public void run() {
      
      Debug.Write( /*Debug.E_NOTICE, 2000,*/ "--------------------- run() ---------------------");
      
      while(true) {
        if(iMode == GameManager.MODE_PRESENTING)
          try { t.sleep(10);
          } catch (InterruptedException ex) {}

        try {         
          agents[0].doAction();
          agents[1].doAction();
          balls[0].doAction();
          
          gates[0].doAction();
          gates[1].doAction();
        }
        catch (NullPointerException e){
          e.printStackTrace();
        }

        

        // Po��tadlo
        this.state.increaseIterationNumber();
        long iIterations = this.state.getIterationNumber();
        
        if(iIterations % 250 == 0)
          Debug.Write(Debug.E_NOTICE, 2002, "Iteration " + String.valueOf(iIterations));
        
        /*if(iIterations % 20000 == 1)
          this.SetMode(MODE_PRESENTING);
        if(iIterations % 20000 == 400)
          this.SetMode(MODE_LEARNING);
        /**/
        
        if (this.state.GetEpizodeIterations() > MaxIterations)
          this.restart();
        
        if(GameManager.getInstance().iMode == GameManager.MODE_PRESENTING   ||  (iIterations % 250 == 0)  )
          this.repaint();
        
      }
    }

    private void ToggleDebugMessages(){
      // Debug messages
      boolean bPresenting = this.iMode == GameManager.MODE_PRESENTING;

      Debug.DebugOnOff(1);

      // Agent messages 
      Debug.ToggleKey(2201, true); // "Agent " + this.sName + ": \"Adaptuji neuronovou s�.\" Odm�na: "+cRound.Round(dReward, 3));
      Debug.ToggleKey(2202, true); // "Hit z iterace " + lHitTime + ". V�ha: "+ dWeight);
      Debug.ToggleKey(2203, bPresenting && true); // "U��m s�: Input[ ... ] D�v�: [...] Chceme: [...] (4 ��dky)
      Debug.ToggleKey(2204, false); // "dWeightTurn = " ...

      // Neural Network messages
      Debug.ToggleKey(2301, false);
      Debug.ToggleKey(2302, bPresenting && bShowNetCreatingMessages && false); // "ConnectFromTo( "+(oNeuronFrom.id)+" -> "+(oNeuronTo.id)+" , W: "+dWeight+" )"
      Debug.ToggleKey(2303, bPresenting && bShowNetCreatingMessages); // "Starting computing round #"+(_iRounds++)
      Debug.ToggleKey(2304, bPresenting && bShowNetCreatingMessages); // "Computing finished."

      Debug.ToggleKey(2312, bPresenting && bShowNetComputingMessages); // "Starting backprop round #"+(_iRounds++)+""
      Debug.ToggleKey(2313, bPresenting); // 
      Debug.ToggleKey(2314, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2315, bPresenting && bShowNetComputingMessages); // 

      Debug.ToggleKey(2321, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2322, bPresenting && bShowNetComputingMessages); // "."
      Debug.ToggleKey(2323, bPresenting && bShowNetComputingMessages); // Correcting neuron... 
      Debug.ToggleKey(2324, bPresenting && bShowNetComputingMessages); // "."
      Debug.ToggleKey(2325, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2326, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2327, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2328, bPresenting && bShowNetComputingMessages); // 
      Debug.ToggleKey(2329, bPresenting && bShowNetComputingMessages); // 

      // cNeuralNetTeacher::PerformCorrection()
      Debug.ToggleKey(2330, bPresenting && bShowNetAdjustingMessages); // "V�stupn� hodnoty: [" + cRound.implode(adVystupyReal) + "]"
      Debug.ToggleKey(2331, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2332, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2333, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2334, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2335, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2336, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2337, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2338, bPresenting && bShowNetAdjustingMessages); // 
      Debug.ToggleKey(2339, bPresenting && bShowNetAdjustingMessages); // "Correcting finished. Time: "+this.iLastTimeMs+" ms; Overall avg time: "+this.oAvgCorrectionTime+" ms"

      Debug.ToggleKey(2341, bPresenting && bShowNetComputingMessages); // "V�stupn� hodnoty: [" + cRound.implode(adVystupyReal) + "]"

      Debug.ToggleKey(2351, bPresenting && bShowNetComputingMessages); // "Vstupn� hodnoty: [" + this.oCurTrainSetItem.adI + "]"
      Debug.ToggleKey(2352, bPresenting && bShowNetComputingMessages); // "Cht�n�  hodnoty: [" + this.oCurTrainSetItem.adO + "]"

      Debug.ToggleKey(2501, bPresenting && bShowHitsStoreMessages); // 
      Debug.ToggleKey(2502, bPresenting && bShowHitsStoreMessages); // 
      Debug.ToggleKey(2503, bPresenting && bShowHitsStoreMessages); // cHitStore::GetHitWeightByAge(): ...

      Debug.ToggleKey(2601, bPresenting && false); // NN ��k�: [..., ...]

      // Debug.ToggleKey(1002, bPresenting); // "Connecting neurons A -> B"        

    }

    /**
     * force simulation into start state
     **/
    public void restart() {
        
        this.ToggleDebugMessages();
        
        this.state.IncreaseEpizodeNumber();
        this.state.SetStartIteration();
        Debug.Write(Debug.E_NOTICE, 2001,
          "----------------- Prov�d�m RESTART. (I:"+this.state.getIterationNumber()+"; E:"+this.state.GetEpizodeNumber()+") -------------------"); ///
        
        // --- Ball --- //
        balls[0] = new Ball();
        balls[0].setBounds(150, 150, 10, 10);

        // Set random ball speed
        Random random = new Random(System.currentTimeMillis());
        
        int vx, vy;
        // prevent having zero velocity in axis directions
        do vx = random.nextInt(20) - 10; while (vx == 0);
        //do vy = random.nextInt(20) - 10; while (vy == 0);
        vy = 5;
        
        Debug.Write(Debug.E_NOTICE, 2005, "Ball.v = [" + vx + "," + vy + "]");
        balls[0].setVelocity(vx, vy);
        

        // --- Agenti --- //
        // pridame si agenty        
        agents[0].EndEpizode();
        agents[1].EndEpizode();
        
        agents[0].setBounds(100, 40, 50, 10);        
        agents[1].setBounds(100, 460, 50, 10);

        // kazdemu agentovi pridame oponenta micek
        agents[0].addOponent(balls[0]);
        agents[1].addOponent(balls[0]);
        
        // pridam hitObjekty
        balls[0].addHitObject(agents[0]);
        balls[0].addHitObject(agents[1]);
        


        // vytvorim si brany a v parametru jim pridam vlastniho a ciziho agenta
        gates[0] = new Gate(agents[0], agents[1]);
        gates[0].setBounds(200, 0, 100, 30);
        gates[1] = new Gate(agents[1], agents[0]);
        gates[1].setBounds(200, 490, 100, 30);

        // branam pridam jako listenera tohoto managera
        gates[0].addMyGateListener(this);
        gates[1].addMyGateListener(this);

        // branam pridam jako listenera tento micek
        gates[0].addOponent(balls[0]);
        gates[1].addOponent(balls[0]);

        // vytvorim si steny
        walls[0] = new Wall();
        walls[0].setBounds(0, 0, 500, 20);
        agents[0].addOponent(walls[0]);
        agents[1].addOponent(walls[0]);

        walls[1] = new Wall();
        walls[1].setBounds(0, 500, 520, 20);
        agents[0].addOponent(walls[1]);
        agents[1].addOponent(walls[1]);
        walls[2] = new Wall();
        walls[2].setBounds(0, 0, 20, 500);
        agents[0].addOponent(walls[2]);
        agents[1].addOponent(walls[2]);
        walls[3] = new Wall();
        walls[3].setBounds(500, 0, 20, 500);
        
        agents[0].addOponent(walls[3]);
        agents[1].addOponent(walls[3]);
                
        // micku dam oponenta
        balls[0].addOponent(agents[0]);
        balls[0].addOponent(agents[1]);
        balls[0].addOponent(walls[0]);
        balls[0].addOponent(walls[1]);
        balls[0].addOponent(walls[2]);
        balls[0].addOponent(walls[3]);

        // create list of all objects
        this.state.setList(agents, balls, walls, gates);
        
        this.old = new Point(0, 0);
    }
    
        
    
    
    /**
     * method paints all object in simulation model
     **/
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.blue);
        SimulationObject[] rec =  this.state.getAllObjects();

       for (int i = 0; i < rec.length; i++){
           switch(i){
           case 0:
               g2.setColor(Color.red);
               g2.fillRect((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
              break;
           case 1:
              g2.setColor(Color.red);
              g2.fillRect((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
              break;
           case 2:
               g2.setColor(Color.black);
               g2.fillOval((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
               break;
           case 7:
               g2.setColor(Color.white);
               g2.fillRect((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
               break;
           case 8:
               g2.setColor(Color.white);
               g2.fillRect((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
              break;

           default:
                g2.setColor(Color.black);
                g2.fillRect((int)(rec[i].getX()),(int)(rec[i].getY()),(int)(rec[i].getWidth()),(int)(rec[i].getHeight()));
                break;

           }
        
        }
    }
    
    
    
    public void nauc_agenta(String t,int ag)
    {
      try{
        this.agents[ag].oNetTeacher.GetNet().Unserialize(t);
      }
      catch(Exception exception)
      { exception.printStackTrace();
      }
    }
    

    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseDragged(MouseEvent e) {}


    public void mouseMoved(MouseEvent e) {
      int vx = -old.x + e.getPoint().x;
      int vy;// = -old.y + e.getPoint().y;

      this.old = e.getPoint();
      //vy = this.agents[0].getVelocity().y;
      vy = this.state.getFirstAgentVelocity().y;
      if (Math.abs(vx) < 10)
        this.state.setFirstAgentVelocity(new Point(vx, vy));
    }

}
