/**
 * <p>Title: </p>
 *
 * <p>Description: This class holds informations about all objects</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

package objects;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Tom
 */
public class State {
    public static int AGENT0 = 0;
    public static int AGENT1 = 1;
    public static int BALL = 2;
    
    ArrayList list;
    
    // Po��tadla 
    long iteration;
    long iStartIteration;
    long iEpizode;
    
    public long getIterationNumber(){ return this.iteration; }
    public void increaseIterationNumber(){ ++this.iteration; }
    
    public void SetStartIteration(long iStartIteration){ this.iStartIteration = iStartIteration; }
    public void SetStartIteration(){ this.SetStartIteration(this.iteration); }
    public long GetEpizodeIterations(){ return this.iteration - this.iStartIteration; }
    
    public long GetEpizodeNumber(){ return this.iEpizode; }
    public void IncreaseEpizodeNumber(){ ++this.iEpizode; }

    
    /** Creates a new instance of State */
    public State() {
        list = new ArrayList();
        this.iteration = 0;
        this.SetStartIteration();
    }
    
    
    /** Creates list of all objects
     **/
    public void setList(Agent[] agents, Ball[] balls, Wall[] walls, Gate[] gates){
        list = new ArrayList();
        for (int i = 0; i < agents.length; i++){
            list.add(agents[i]);
        }
        
        for (int i = 0; i < balls.length; i++){
            list.add(balls[i]);
        }
        
        for (int i = 0; i < walls.length; i++){
            list.add(walls[i]);
        }
        for (int i = 0; i < gates.length; i++){
            list.add(gates[i]);
        }
    }
    
    
    private Point getPosition(int agentnum){
        return ((DynamicSO)list.get(agentnum)).getLocation();
    }
    
    public Point getFirstAgentPosition(){
        return this.getPosition(State.AGENT0);
    }
    
    public Point getSecondAgentPosition(){
        return this.getPosition(State.AGENT1);
    }
    
    
    public Point getFirstAgentVelocity(){
       return ((DynamicSO)list.get(State.AGENT0)).getVelocity();
    }
    
    public Point getSecondAgentVelocity(){
        return ((DynamicSO)list.get(State.AGENT1)).getVelocity();
    }
    
    
    public void setFirstAgentVelocity(Point vel){
        ((DynamicSO)list.get(State.AGENT0)).setVelocity(vel);
    }

    public void setSecondAgentVelocity(Point vel){
        ((DynamicSO)list.get(State.AGENT1)).setVelocity(vel);
    }
    
    public Point getBallPosition(){
        return this.getPosition(State.BALL);
    }
    
    public Point getBallVelocity(){
        return ((Ball)this.list.get(State.BALL)).getVelocity();
    }
    
    /**
     * This methods return rectangle of all objects in simulation.
     */
    public Rectangle[] getAllObjectsRectangle(){
        Rectangle[] pole = new Rectangle[this.list.size()];
        
        Iterator it = list.iterator();
        int id = 0;
        
        // prochazim objekty ze seznamu a vytvarim z nich pole zakladnich objektu pro zobrazeni.
        while (it.hasNext()){
            pole[id] = ((SimulationObject)it.next()).getBounds();
            ++id;
        }
        
        return pole;
    }
    
    
    /**
     * This methods return all objects in simulation.
     */
    public SimulationObject[] getAllObjects(){
        SimulationObject[] pole = new SimulationObject[this.list.size()];
        
        Iterator it = list.iterator();
        int id = 0;
        
        // prochazim objekty ze seznamu a vytvarim z nich pole zakladnich objektu pro zobrazeni.
        while (it.hasNext()){
            pole[id] = ((SimulationObject)it.next());
            ++id;
        }
        
        return pole;
    }
    
    
}
