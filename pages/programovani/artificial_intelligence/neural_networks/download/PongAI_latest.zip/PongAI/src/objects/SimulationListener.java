 /**
 * <p>Title: </p>
 *
 * <p>Description: This interface is implemented in all objects. Specify methods for running  simulation</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

package objects;

import java.awt.Rectangle;

public interface SimulationListener {
    /**
     * this methos is called in each simulation step.
     **/
    void doAction();
    
    /**
     * method for testing if object colides with another one.
     **/
    public boolean colidesWith(SimulationObject object);
}
