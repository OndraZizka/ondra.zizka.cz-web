package objects;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.TextArea;
import java.awt.Dimension;
import pongai.Debug;


public class Statist extends JFrame  {

    public Statist() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setTitle("Statistika");
        this.getContentPane().setLayout(borderLayout1);
        this.getContentPane().add(textArea1, java.awt.BorderLayout.CENTER);
        this.setSize(new Dimension(400, 300));

    }

    public static TextArea textArea1 = new TextArea();
    BorderLayout borderLayout1 = new BorderLayout();   
}
