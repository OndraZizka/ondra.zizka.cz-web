package objects;

import java.awt.Point;
import java.util.Iterator;
import java.util.Random;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class DynamicSO extends SimulationObject {
    // Vector of velocity
    Point velocity;
    Point oldPoint;
    Point ptMaxVelocity;
    // Random generator
    Random random;

    /** standart constructor what sets veloctiy vector to (0, 0) **/
    public DynamicSO() {
        this.ptMaxVelocity = new Point(5, 5);
        this.setVelocity(new Point(0, 0));        
    }

    /** method sets velocity vector **/    
    public void setVelocity(Point vector) {
      //this.velocity = vector;
      this.velocity = new Point(
              (int)Math.min(vector.x, this.ptMaxVelocity.x),
              (int)Math.min(vector.y, this.ptMaxVelocity.y)
              );
      this.oldPoint = new Point(0, 0);
    }

    public void AdjustVelocity(int idX, int idY){
      /*this.setVelocity(new Point(
              (int)Math.min(this.velocity.getX() + idX, this.ptMaxVelocity.x),
              (int)Math.min(this.velocity.getY() + idY, this.ptMaxVelocity.y)
              ) );*/
      this.setVelocity(new Point(this.velocity.x + idX, this.velocity.y + idY));
    }
    
    /** increase velocity in left direction */
    public void left() {
      /*Point pom = new Point();
      pom.setLocation(this.velocity.getX() - 1, this.velocity.getY());
      this.setVelocity(pom); */
      this.AdjustVelocity(-1, 0);
    }
    
    /** increase velocity in right direction */
    public void right() {
      /*Point pom = new Point();
      pom.setLocation(this.velocity.getX() + 1, this.velocity.getY());
      this.setVelocity(pom);*/
      this.AdjustVelocity(1, 0);
    }

    /** increase velocity in up direction */
    public void up() {
      /*Point pom = new Point();
      pom.setLocation(this.velocity.getX(), this.velocity.getY() - 1);
      this.setVelocity(pom);*/
      this.AdjustVelocity(0, -1);
    }

    /** increase velocity in down direction */
    public void down() {
      /*Point pom = new Point();
      pom.setLocation(this.velocity.getX(), this.velocity.getY() + 1);
      this.setVelocity(pom);*/
      this.AdjustVelocity(0, 1);
    }

/**
 ** Method tests colission with all <b>registered</b> openents. If a collision occurs, then 
 *  velocity vector is properly changed.
 */
    public void myMove() {

        int vx = this.velocity.x;
        int vy = this.velocity.y;

        double pomx;
        double pomy;

        int max = Math.max(Math.abs(vx), Math.abs(vy));

        pomx = (double) vx / max;
        pomy = (double) vy / max;

        int minx = (int)this.getMinX();
        int maxx = (int)this.getMaxX();
        int maxy = (int)this.getMaxY();
        int miny = (int)this.getMinY();

        for (int iter = 0; iter < max; iter++) {
            vx = (int) (pomx * iter);
            vy = (int) (pomy * iter);
            this.setBounds(minx + vx, miny + vy, maxx - minx, maxy - miny);

            Iterator it = oponents.iterator();
            while (it.hasNext()) {
                SimulationObject ob = (SimulationObject) it.next();
                if (this.intersects(ob.getBounds())) {
                    if (this.velocity.x > 0) {
                        Point x1 = ob.getLocation();
                        Point x2 = new Point((int) ob.getMinX(),
                                             (int) ob.getMaxY());

                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                                x2.getY())) {
                            this.velocity.x *= -1;
                            pomx *= -1;
                        }
                    } else if (this.velocity.x < 0) {
                        Point x1 = new Point((int) ob.getMaxX(),
                                             (int) ob.getMinY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                             (int) ob.getMaxY());

                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                                x2.getY())) {
                            this.velocity.x *= -1;
                            pomx *= -1;
                        }
                    }
                    if (this.velocity.y > 0) {
                        Point x1 = new Point((int) ob.getMinX(),
                                             (int) ob.getMinY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                             (int) ob.getMinY());

                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                                x2.getY())) {
                            this.velocity.y *= -1;
                            pomy *= -1;

                        }
                    } else if (this.velocity.y < 0) {
                        Point x1 = new Point((int) ob.getMinX(),
                                             (int) ob.getMaxY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                             (int) ob.getMaxY());

                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                                x2.getY())) {
                            this.velocity.y *= -1;
                            pomy *= -1;
                        }
                    } //elif
                } // for
            } // for pomx
        }
    }

    /** moves rectangle in velocity direction */
    public void move() {
        this.myMove();
    }

    /** return object to old position **/
    public void unMove() {
        this.oldPoint = this.getLocation();
        this.translate( -1 * this.velocity.x, -1 * this.velocity.y);
    }

    /** sets Velocity vector. */
    public void setVelocity(int x, int y) {
        this.setVelocity(new Point(x, y));
    }
    
    public Point getVelocity(){
        return this.velocity;
    }
}
