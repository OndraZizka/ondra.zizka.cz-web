/*
 * cSynapse.java
 *
 * Created on 30. prosinec 2005, 8:56
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package pongai;


/**************************************************************
 *   Trida pro jednoduchou synapsi.                                
 * Obsahuje informaci, ze kter�ho do kter�ho neuronu vede,
 * a v�hu.
 * @author Ondra �i�ka
**************************************************************/
public class cSynapse {
  
  /** Ze kter�ho neuronu vede. */
  public cNeuron oFrom;
  /** Do kter�ho neuronu vede. */
  public cNeuron oTo;
  /** V�ha t�to synapse. */
  public double dWeight;
    
  /** Creates a new instance of cSynapse */
  public cSynapse(cNeuron oFrom, cNeuron oTo, double dWeight){
    if(0.0 == dWeight)
	    dWeight = ( Math.random() * (0.3 - 0.05) + 0.05 )  *  ((Math.random() < 0.5) ? -1 : 1);
    this.dWeight = dWeight;
    //this.dValue  = 0.0;
    this.oFrom = oFrom;            // z jakeho neuronu to prichazi 
    this.oTo   = oTo;              // na jaky neuron to odchazi 
  }
  /** Vytvo�� synapsi s n�hodnou vahou */
	public cSynapse(cNeuron oFrom, cNeuron oTo){
		//double dWeight = ( Math.random() * (0.3 - 0.05) + 0.05 )  *  ((Math.random() < 0.5) ? -1 : 1);
		this(oFrom, oTo, ( Math.random() * (0.3 - 0.05) + 0.05 )  *  ((Math.random() < 0.5) ? -1 : 1));
	}
  
  /** Vr�t� popis synapse ve form�tu cSy{ oFrom.id -> oTo.id; W:dWeight; I:input } */
  public String toString(){
    return "cSy{ "+(this.oFrom == null ? "null" : this.oFrom.id)+"->"+(this.oTo == null ? "null" : this.oTo.id)+";"
      +" W:"+cRound.Round(this.dWeight,4)+"; I:"+cRound.Round(this.GetInput(),4)+" }";
  }  
  
  /** Nastav� neuron "kam" */
  public void SetTo     (cNeuron oTo)    { this.oTo = oTo; }
  /** Vr�t� neuron "kam" */
  public cNeuron GetTo     ()       { return this.oTo; }
  /** Nastav� neuron "odkud" */
  public void SetFrom   (cNeuron oFrom)  { this.oFrom = oFrom; }
  /** Vr�t� neuron "odkud" */
  public cNeuron GetFrom   ()       { return this.oFrom; }
  /** Nastav� v�hu t�to synapse. */
  public void SetWeight (double dWeight){ this.dWeight = dWeight; }
  //public void StoreValue(dValue){ this.dValue = dValue; }
  /** Vr�t� ulo�enou hodnotu vyn�sobenou vahou. */
  public double GetValue  ()       { return this.oFrom.dValue * this.dWeight; }
  /** Vr�t� ulo�enou hodnotu vyn�sobenou vahou. */
  public double GetInput  ()       { return this.oFrom.dValue; }
  //public double GetRealValue()    { return this.oFrom.dValue; }

}


