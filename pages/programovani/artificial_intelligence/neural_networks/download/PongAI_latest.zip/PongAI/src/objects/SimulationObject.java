package objects;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

/**
 *
 * <p>Title: </p>
 *
 * <p>Description: Root of all objects in simulation model.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SimulationObject extends Rectangle implements SimulationListener {
  
    int iID;
    public  int GetID(){ return this.iID; }
    private static int iNextID; static { iNextID = 0; }    
    private static int GetNextID(){ return ++iNextID; }
    
    ArrayList oponents;

    
    public SimulationObject() {
        this.iID = GetNextID();
        this.oponents = new ArrayList();
    }

    public void doAction() {
        System.out.println("SimulationObject");
    }

    public boolean colidesWith(SimulationObject object) {
        return this.intersects(object.getBounds());
    }

    /**
     * sets collection of activators
     * @param activators ArrayList
     */
    public void setOponents(ArrayList activators) {
        this.oponents = activators;
    }

    /**
     * add new activator to collection
     * @param object SimulationObject
     */
    public void addOponent(SimulationObject object) {
        this.oponents.add(object);
    }

    /**
     * remove activator from collection
     * @param object SimulationObject
     */
    public void remOponent(SimulationObject object) {
        this.oponents.remove(object);
    }

    public void paint(Graphics g) {
        g.drawRect(this.x, this.y, this.width, this.height);
    }


}
