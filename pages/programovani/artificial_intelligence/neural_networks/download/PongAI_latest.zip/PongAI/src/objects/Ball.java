package objects;

import java.util.ArrayList;
import java.awt.Point;
import java.util.Iterator;

public class Ball extends DynamicSO {
    private    ArrayList oponentObjects;
    private ArrayList hitObject;
    
    public Ball() {
        this.oponentObjects = new ArrayList();
        this.hitObject = new ArrayList();
    }
    
    public void setVelocity(Point vector) {
        // Nejprve nech�me nastavit rychlost rodi�ovskou t��du...
        super.setVelocity(vector);
        // Pak to zkontrolujeme, jestli se nepohybujeme po jedn� z os.
        if(this.velocity.y == 0){
            int iRand1to4 = (int)( Math.ceil(Math.random() * 4 ) );
            if( iRand1to4 > 2 )
                iRand1to4 -= 5; // 4 -> -1,  3 -> -2
            this.velocity.y = iRand1to4;
        }
        if(this.velocity.x == 0){
            int iRand1to4 = (int)( Math.ceil(Math.random() * 4 ) );
            if( iRand1to4 > 2 )
                iRand1to4 -= 5; // 4 -> -1,  3 -> -2
            this.velocity.x = iRand1to4;
        }
    }
    
    /** Method tests colission with all <b>registered</b> openents. If a collision occurs, then
     *  velocity vector is properly changed. */
    public void myMove() {
        int vx = this.velocity.x;
        int vy = this.velocity.y;
        
        double pomx;
        double pomy;
        
        int max = Math.max(Math.abs(vx), Math.abs(vy));
        
        pomx = (double) vx / max;
        pomy = (double) vy / max;
        
        int minx = (int)this.getMinX();
        int maxx = (int)this.getMaxX();
        int maxy = (int)this.getMaxY();
        int miny = (int)this.getMinY();
        
        for (int iter = 0; iter < max; iter++) {
            vx = (int) (pomx * iter);
            vy = (int) (pomy * iter);
            this.setBounds(minx + vx, miny + vy, maxx - minx, maxy - miny);
            
            Iterator it = oponents.iterator();
            while (it.hasNext()) {
                SimulationObject ob = (SimulationObject) it.next();
                if (this.intersects(ob.getBounds())) {
                    
                    // tady testuju, jestli jem narazil s mickem do agenta
                    // pokud jsem narazil na nejkeho Agenta, se kterym mam detekovat kolizi, tak zavolam hit
                    if (ob.getClass() == Agent.class){
                      Iterator hitobj = this.hitObject.iterator();
                      while (hitobj.hasNext()){
                        Agent ag = (Agent)hitobj.next();
                        if (ob == ag){
                          // zmenit velocity micku podle rychlosti agenta
                          this.AdjustVelocity(ag.getVelocity().x, ag.getVelocity().y);
                          ag.hitReceived();
                        }
                      }/**/
                    }
                    
                    if (this.velocity.x > 0) {
                        Point x1 = ob.getLocation();
                        Point x2 = new Point((int) ob.getMinX(),
                                (int) ob.getMaxY());
                        
                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                x2.getY())) {
                            this.velocity.x *= -1;
                            pomx *= -1;
                        }
                    } else if (this.velocity.x < 0) {
                        Point x1 = new Point((int) ob.getMaxX(),
                                (int) ob.getMinY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                (int) ob.getMaxY());
                        
                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                x2.getY())) {
                            this.velocity.x *= -1;
                            pomx *= -1;
                        }
                    }
                    if (this.velocity.y > 0) {
                        Point x1 = new Point((int) ob.getMinX(),
                                (int) ob.getMinY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                (int) ob.getMinY());
                        
                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                x2.getY())) {
                            this.velocity.y *= -1;
                            pomy *= -1;
                        }
                    } else if (this.velocity.y < 0) {
                        Point x1 = new Point((int) ob.getMinX(),
                                (int) ob.getMaxY());
                        Point x2 = new Point((int) ob.getMaxX(),
                                (int) ob.getMaxY());
                        
                        if (this.intersectsLine(x1.getX(), x1.getY(), x2.getX(),
                                x2.getY())) {
                            this.velocity.y *= -1;
                            pomy *= -1;
                        }
                    } //elif
                } // for
            } // for pomx
        }
    }
    
    
    
    public void doAction() {
        // System.out.println("ball");
        this.myMove();
    }
    
    public void addHitObject(Agent ob){
        this.hitObject.add(ob);
    }
    
}
