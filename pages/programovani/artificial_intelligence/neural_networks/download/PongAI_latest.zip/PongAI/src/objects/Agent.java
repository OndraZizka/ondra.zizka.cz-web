/**
 * <p>Title: </p>
 *
 * <p>Description: This class implements agent, which is dynamic object. Agent is listener
 * of <b>one</b> Gate. If agent do a goal, then proper gate fires event. And agent is informed
 * by this event.</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

package objects;

import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
import pongai.*;




/** Data pro jedno kolo: aktu�ln� stav transformovan� na vstupy pro s�, a vybran� akce. 
 *  @author Ondra �i�ka
 */
class cTurnData{
  double[] adState;     // Stav v on� situaci - normalizovan�. De facto vstup do neuronov� s�t�.
  int iSelectedAction;  // Vybran� akce (index do v�stupn�ch neuron�). Epsilon-greedy - m��e b�t vybr�na kter�koliv akce.
          
  public cTurnData(double[] adState, int iSelectedAction){
    this.adState = adState;
    this.iSelectedAction = iSelectedAction;
  }
}// class cTurnData


class cTurnDataWithWeight /*extends cTurnData*/ {
  cTurnData oTurnData;
  double dWeight;
  
  public cTurnDataWithWeight(cTurnData oTurnData, double dWeight){
    this.oTurnData = oTurnData;
    this.dWeight = dWeight;
  }
}// class cTurnDataWithWeight




/** Data k jednomu hitu: kopie tehdy aktu�ln� fronty stav� a vybran�ch akc�. 
 * @author Ondra �i�ka
 */
class cHitData {
  /** Data kol p�ed t�mto hitem. */
  cTurnData[] aoTurnDatas;
  /** "�as" (��slo kola), kdy tento hit nastal. */
  long iHitTime;
    
  
  /** Akor�t napln� �lensk� prom�nn� podle atribut�. */
  cHitData(cTurnData[] aoTurnDatas, long iHitTime){
    this.aoTurnDatas = aoTurnDatas;
    this.iHitTime = iHitTime;
  }
  
  /** Vrac� �lenskou prom�nnou aoTurnDatas. */
  public cTurnData[] GetTurnData(){ return this.aoTurnDatas; }
  /** Vrac� �lenskou prom�nnou iHitTime. */
  public long GetTime(){ return this.iHitTime; }

  
  /*public Debase(double dRatio){
    for(cTurnData oTurnData : this.aoTurnDatas){
      oTurnData = oTurnData
    }
  }*/
  
}// class cHitData





/** Skladi�t� hit� za tuto epizodu.
 *  P�i ka�d�m p�id�n� hitu se vol� FlushOldHits().
 *  FlushOldHits() vyhazuje hity star�� ne� pam� tohoto skladi�t�,
 *  ur�en� parametrem iTurnsRemembered p�i konstrukci (defaultn� 1000).
 *  @author Ondra �i�ka
 */
class cHitsStore extends ArrayList<cHitData> {
  
  /** D�lka pam�ti skladi�t�. Star�� hity jsou vyhazov�ny. */
  private int iTurnsRemembered;
  /** Jen pokus... k ni�emu to neni. */
  private boolean bIsDebased; 
  /** Sou�asn� okam�ik - ukl�d� se p�i ka�d� ud�losti. */
  private long lCurrentTime;  
  
  /* --- Getry, setry --- */
  public void SetCurrentTime(long lCurrentTime){ this.lCurrentTime = lCurrentTime; }
  public long GetCurrentTime(){ return this.lCurrentTime; }
  
  /* --- Konstruktory --- */
  public cHitsStore(){ this(1000); }
  /** @param iTurnsRemembered Kolik kol dozadu si skladi�t� pamatuje hity. */
  public cHitsStore(int iTurnsRemembered){ this.iTurnsRemembered = iTurnsRemembered; }
  
  /** P�id� k hit�m t�to epizody dal��. Vymete hity star�� ne� pam� skladi�t�. */
  public boolean add(cHitData oHitData){
    Debug.Write(Debug.E_NOTICE, 2501, "cHitStore: Adding a hit. Current size: " +this.size());
    this.SetCurrentTime(oHitData.GetTime());
    this.FlushOldHits();
    super.add(oHitData);
    return true;
  }
  
  /** Vyhazuje hity star�� ne� pam� tohoto skladi�t�,
   * ur�en� parametrem iTurnsRemembered p�i konstrukci (defaultn� 1000). */
  public void FlushOldHits(/*long lCurrentTime*/){
    Debug.Write(Debug.E_NOTICE, 2501, "cHitStore: Flushing old hits.");///
    Iterator<cHitData> i = this.iterator();
    //for(cHitData oHitData : this){
    while(i.hasNext()){
      cHitData oHitData = i.next();
      if(this.lCurrentTime - oHitData.iHitTime > this.iTurnsRemembered){
        Debug.Write(Debug.E_NOTICE, 2502, "cHitStore: Flushing hit from It["+oHitData.iHitTime+".");///
        i.remove();
      }
    }
  }// public void FlushOldHits(long lCurrentTime)
  
  public void Reset(){
    this.clear();
    this.bIsDebased = false;
  }// public void Reset()
  
  
  /** Sn�� v�hu hit� podle vzd�lenosti od sou�asn�ho �asu */
  /*public void Debase(long lCurrentTime){
    if(this.bIsDebased) return;
    this.bIsDebased = true;
    this.SetCurrentTime(lCurrentTime);
    this.FlushOldHits();
  }/**/
  
  /** Vr�t� v�hu dan�ho hitu podle jeho st��� od sou�asn�ho okam�iku. */
  public double GetHitWeightByAge(cHitData oHitData){
    
    long lAge = this.GetCurrentTime() - oHitData.GetTime();
    if(lAge > this.iTurnsRemembered) return 0.0;
    double dX = (this.iTurnsRemembered - lAge) / (double)this.iTurnsRemembered;
    
    Debug.Write(Debug.E_NOTICE, 2503, "cHitStore::GetHitWeightByAge(): "
            +"(this.GetCurrentTime()["+this.GetCurrentTime()+"] "
            +"- oHitData.GetTime()["+oHitData.GetTime()+"]) "
            +"/ this.iTurnsRemembered ["+this.iTurnsRemembered+"] = " + dX);///
    
    return dX * dX;
  }
  
}// class cHitsStore extends ArrayList<cHitData>









/********************************************************************************
 *  Agent 007
 *  @author Tom� B�trla, Ondra �i�ka
********************************************************************************/
public class Agent extends DynamicSO implements GateListener {
    
    /** Neuronov� s� hodnot�c� pravd�podobnost v�b�ru akc� */
    cNeuralNetIOAdapter oNetAdapter;
    cNeuralNetTeacher oNetTeacher;
    
    /** Fronta kol v posledn� dob� v t�to epizod� */
    cFixedLengthQueue<cTurnData> oRecentTurns;
    public final int iRememberedTurns;
    
    /** Skladi�t� hit� v posledn� dob� v t�to epizod� */
    cHitsStore oHitsStore;
    public final int iRememberedHitsAge;
    
    
    /** Jm�no agenta, nap� &quot;Bond, James Bond&quot;. */
    public String sName;
    

    
    /** Vytvo��  agenta s dan�m jm�nem.
     author Ondra �i�ka
     @param sName Jm�no agenta */
    public Agent(String sName) {
      
      // Jmeno agenta 
      this.sName = sName;
      
      //this.oState = state;
      int[] aiLevels = { 12, 6, 4, 2 };
      cNeuralNet oNet = new cNeuralNetPerceptron(aiLevels);
      this.oNetAdapter = new cNeuralNetIOAdapter(oNet);
      this.oNetTeacher = new cNeuralNetTeacher(oNetAdapter, null);
      
      // Kapacita fronty = kolik posledn�ch iterac� si pamatuje
      this.iRememberedTurns = 50;
      this.oRecentTurns = new cFixedLengthQueue(this.iRememberedTurns);
      
      // Kapacita skladi�t� hit� = kolik 
      this.iRememberedHitsAge = 1000;
      this.oHitsStore = new cHitsStore(this.iRememberedHitsAge);
    }

    

    /****************************************************************
     * Handler - agent m� prov�st jedno kolo - iteraci.
     *  author Ondra �i�ka
     ****************************************************************/
    public void doAction(){
      // Z�sk� stav, z n�j hodnoty.
      State oState = GameManager.getInstance().getState();
      if(null == oState) return; //!!!
      Point ptBV = oState.getBallVelocity();
      Point ptBP = oState.getBallPosition();
      Point ptA1V = oState.getFirstAgentVelocity();
      Point ptA1P = oState.getFirstAgentPosition();
      Point ptA2V = oState.getSecondAgentVelocity();
      Point ptA2P = oState.getSecondAgentPosition();
      
      // Vytvo��me double[], bude slou�it jako vstup pro neuronovou s�
      double[] adValues = {
        ptBP.x,  ptBP.y,
        cRound.Normalize(ptBV.x),  cRound.Normalize(ptBV.y),
        ptA1P.x, ptA1P.y,
        cRound.Normalize(ptA1V.x), cRound.Normalize(ptA1V.y),
        ptA2P.x, ptA2P.y,
        cRound.Normalize(ptA2V.x), cRound.Normalize(ptA2V.y)
      };
      
 
      
      // --- Rozhodovani --- //
      this.oNetAdapter.SetInputValues(adValues);   
      this.oNetAdapter.oNeuralNet.Compute();
      
      // --- Vysledky --- //
      double[] adVysledky = this.oNetAdapter.GetOutputValues();
        Debug.Write(Debug.E_NOTICE, 2601, "Agent "+this.sName+": NN ��k�: ["+cRound.implode(adVysledky)+"]");///
      int iSelectedAction = -1;
      double dMaxProbability = 0.0;
      for(int i = 0; i < adVysledky.length; i++){
        if(dMaxProbability < adVysledky[i]){
          dMaxProbability = adVysledky[i];
          iSelectedAction = i;
        }
      }
      
      // --- Akce --- //
      switch(iSelectedAction){
        case -1: break;
        case  0: this.left(); break;
        case  1: this.right(); break;
        default: Debug.Write(Debug.E_ERROR, "Chyba: Nezn�m� vybran� akce!");
      }
      
      // P�i ka�d�m kole (iteraci) si ulo��me do fronty sou�asn� stav a vybranou akci.
      oRecentTurns.push(new cTurnData(adValues, iSelectedAction));                  
      this.myMove();
            
    }// doAction()
    
    
    /** Provede akce na konci epizody: Vyhod� z�znamy ze skladi�t� oHitStore a fronty oRecentTurns. */
    public void EndEpizode(){
      this.oHitsStore.Reset();
      this.oRecentTurns.clear();
    }
    
    
    /** Handler - agent se dotkl m��e. */
    protected void hitReceived(){
        // timto pricitam k rychlosti micku i rychlost agenta
    //((DynamicSO)this.hitObject).AdjustVelocity(this.velocity.x, this.velocity.y);
        
      State oState = GameManager.getInstance().getState();
      Debug.Write("[It:"+oState.getIterationNumber()+"] Agent " + this.sName + ": ----- Hit -----");
      
      // Pri hitu zkopirujeme obsah fronty,
      // vytvorime novy objekt a vlo��me si ho do skladu
      cTurnData[] aoTurnDatas = new cTurnData[0];
      this.oHitsStore.add(new cHitData(this.oRecentTurns.toArray(aoTurnDatas), oState.getIterationNumber()));
    }

    

    /** Handler - agent dal g�l. */
    public void goalMade() {
      State oState = GameManager.getInstance().getState();
      Debug.Write("[It:"+oState.getIterationNumber()+"] Agent " + this.sName + "  dal G���L!   --->");
      
      int iReward = +100;
      this.oHitsStore.SetCurrentTime(oState.getIterationNumber());
      this.AdaptNeuralNet(iReward);
      this.EndEpizode();
    }
    

    
    /** Handler - agent dostal g�l. */
    public void goalReceived() {
      State oState = GameManager.getInstance().getState();
      Debug.Write("[It:"+oState.getIterationNumber()+"] Agent " + this.sName + "  dostal g�l... <---");
      
      int iReward = -100;
      this.oHitsStore.SetCurrentTime(oState.getIterationNumber());
      this.AdaptNeuralNet(iReward);
      this.EndEpizode();
    }
                    
    
    
    
    /** Adaptuje neuronovou s� podle odm�ny a podle dosavadn�ho d�n� v epizod�.
     author Ondra �i�ka
     @param dReward  Odm�na v rozmez� 0.0 a� 1.0 */
    protected void AdaptNeuralNet(double dReward){
      dReward *= 0.01; // +100, -100 - ��dov� stovky na ��dov� jednotky
      
      Debug.Write(Debug.E_NOTICE, 2201, "Agent " + this.sName + ": \"Adaptuji neuronovou s�.\""
              + " Odm�na: "+cRound.Round(dReward, 3)
              + ";  Hit� ve skladi�ti: " + this.oHitsStore.size() );
      
      //if(GameManager.getInstance().iMode == GameManager.STATE_PRESENTING)
      //  try{Thread.currentThread().sleep(40/*00*/);}catch(Exception e){}
            
      cHitData[] aoHits = new cHitData[0];
      aoHits = this.oHitsStore.toArray(aoHits);
      
      // Stack - na obr�cen� po�ad� 
      Stack<cTurnDataWithWeight> aoTurnDataStack = new Stack();
            
      // Pro ka�d� z�sah plo�ky v t�to epizod�...
      for(cHitData oHit : aoHits){
        
        double dWeight = this.oHitsStore.GetHitWeightByAge(oHit);
        long lHitTime = oHit.GetTime();
        Debug.Write(Debug.E_NOTICE, 2202, "Hit z iterace " + lHitTime + "("+oHit.aoTurnDatas.length+" kol). V�ha: "+ dWeight);
        
        int i = -this.iRememberedTurns;
        // Pro ka�dou ulo�enou iteraci p�ed t�mto z�sahem...
        for(cTurnData oTurnData : oHit.GetTurnData()){
          
          double dWeightTurn = Math.max(0.0, (this.iRememberedTurns+i) / (double)this.iRememberedTurns);
          Debug.Write(Debug.E_NOTHING, 2204, "dWeightTurn = "+dWeightTurn+"("+(dWeightTurn*dWeightTurn)+") = "
                  + "Math.max(0.0, (this.iRememberedTurns+i) / "+(double)this.iRememberedTurns+" = "
                  +((this.iRememberedTurns+i) / (double)this.iRememberedTurns)+");");///
          dWeightTurn = dWeightTurn * dWeightTurn;
          dWeightTurn *= dWeight; // Sn�eno v�hou hitu 
          
          aoTurnDataStack.push(new cTurnDataWithWeight(oTurnData, dWeightTurn));
          i++;
        }// for(cTurnData oTurnData : oHit.GetTurnData())
      }// for(cHitData oHit : aoHits)
      
      //for(cTurnData oTurnData : aoTurnDataStack){   
      cTurnDataWithWeight oTurnDataWW;
      while(!aoTurnDataStack.empty()){
        oTurnDataWW = aoTurnDataStack.pop();
        
        // Optimalizovat - teacherovi d�vat rovnou errory na jednotliv� v�stupy!!
        double[] adInputValues  = oTurnDataWW.oTurnData.adState;
        this.oNetAdapter.SetInputValues(adInputValues);
        this.oNetAdapter.oNeuralNet.Compute();
        double[] adOutputValues = this.oNetAdapter.GetOutputValues();
          Debug.Write(Debug.E_NOTICE, 2203, "U��m s�: Input["+cRound.implode(adInputValues)+ "]");///
          Debug.Write(Debug.E_NOTICE, 2203, "  D�v�:   ["+cRound.implode(adOutputValues)+"]");///
        double[] adWantedValues = adOutputValues/*.clone()*/;
        adWantedValues[oTurnDataWW.oTurnData.iSelectedAction] += dReward * oTurnDataWW.dWeight;
          Debug.Write(Debug.E_NOTICE, 2203, "  Chceme: ["+cRound.implode(adWantedValues)+"]");///
          Debug.Write(Debug.E_NOTICE, 2203, "  (adWantedValues["+oTurnDataWW.oTurnData.iSelectedAction+"] += "
                  +dReward+" * "+oTurnDataWW.dWeight+";");///
        
        cNeuralTrainSetItem oTrainSetItem = new cNeuralTrainSetItem(adInputValues, adWantedValues);
        cNeuralTrainSet oTrainSet = new cNeuralTrainSet();
        oTrainSet.Add(oTrainSetItem);
        this.oNetTeacher.SetTrainSet(oTrainSet);          
        this.oNetTeacher.Turn();
        this.oNetTeacher.PerformCorrection();
      }      
      
    }// protected void AdaptNeuralNet(double dReward)
    
    
    
    
   /* public void addHitObject(SimulationObject ob){
        this.hitObject = ob;
    }*/

    
    
}// class Agent