/*
 * cNeuralNetTeacher.java
 *
 * Created on 1. leden 2006, 11:37
 */

package pongai;

import java.util.Date;
import java.util.HashSet;
import java.util.ArrayList;



/**************************************************************
    class cNeuralNetTeacher                                    
	Implementation of supervised learning with backpropagation.   
 *  @author Ondra �i�ka
**************************************************************/
public class cNeuralNetTeacher {
	
	cNeuralNetIOAdapter oNetAdapter;
	cNeuralTrainSet     oTrainSet;
	cNeuralTrainSetItem oCurTrainSetItem;

	double  dLearn;                    // Learning rate - correction amount (LAMBDA) 
	double  dMomentum;                 // Momentum - net's momentum (setrva�nost)    
	int     iMaxRepeats;               // Maximum mumber of repeats of training step 
	double  dTargetError;              // Target error - stop training when reached ?


	int iTurns;                        // Number of network computations        
	int  iCorrections;                 // Number of backpropagation corrections 
	double dLastErrorLevel;            // Average error on output neurons (error sum / # of output neurons)
	double dLastErrorSum;              // Sum of errors on all output neurons   
	
	class cLearnRateInterval {
		public double dError;
		public double dLearnRate;
		public cLearnRateInterval(double dError, double dLearnRate){
			this.dError = dError;
			this.dLearnRate = dLearnRate;
		}
	}
	cLearnRateInterval[] aodLearnRateIntervals;
	
	// adErrorLevels = [1.0];
	// oAvgErrorLevels = new cAverage();  oAvgErrorLevels.AddSample( adErrorLevels[0]);
	ArrayList adErrorLevels = new ArrayList();
	cAverage oAvgErrorLevels = new cAverage();

	cAverage oAvgCorrectionTime = new cAverage();
	int iLastTimeMs = 0;
	
	
	/** Vytvo�� u�itele neuronov� s�t�.
   @param oNeuralNetIOAdapter  NN adapt�r s p�idru�enou neuronovou s�t�.
   @param oTrainSet            Tr�novac� mno�ina pro tohoto u�itele. */
	public cNeuralNetTeacher(cNeuralNetIOAdapter oNeuralNetIOAdapter, cNeuralTrainSet oTrainSet){
		this(oNeuralNetIOAdapter, oTrainSet, 0.2, 0.5, 0.03, 1000);
	}
  /** Vytvo�� u�itele neuronov� s�t�.
   @param oNeuralNetIOAdapter  NN adapt�r s p�idru�enou neuronovou s�t�.
   @param oTrainSet            Tr�novac� mno�ina pro tohoto u�itele.
   @param dLearn               Learning rate - correction amount (LAMBDA) 
   @param dMomentum            Momentum - net's momentum (setrva�nost) (does not work)
   @param dTargetError         Target error - stop training when reached?
   @param iMaxRepeats          Maximum mumber of repeats of training step.
  */
	public cNeuralNetTeacher(cNeuralNetIOAdapter oNeuralNetIOAdapter, cNeuralTrainSet oTrainSet,
				double dLearn, double dMomentum, double dTargetError, int iMaxRepeats){

		this.oNetAdapter = oNeuralNetIOAdapter;
		//this.oTrainSet   = oTrainSet;
    this.SetTrainSet(oTrainSet);
		this.oCurTrainSetItem = null;

		this.dLearn = dLearn;                 // Learning rate - correction amount (LAMBDA) 
		this.dMomentum = dMomentum;           // Momentum - net's momentum (setrva�nost)    		
		this.dTargetError = dTargetError;     // Target error - stop training when reached ?
		this.iMaxRepeats  = iMaxRepeats;      // Maximum mumber of repeats of training step 


		this.iTurns = 0;                      // Number of network computations        
		this.iCorrections = 0;                // Number of backpropagation corrections 
		this.dLastErrorSum = 0.0;             // Sum of errors on all output neurons   
		this.dLastErrorLevel = 0.0;           // Average error on output neurons (error sum / # of output neurons)
		//this.adErrorLevels = [1.0];
		//this.oAvgErrorLevels = new cAverage(); this.oAvgErrorLevels.AddSample(this.adErrorLevels[0]);
		this.adErrorLevels = new ArrayList();
		this.oAvgErrorLevels = new cAverage();
		
		this.aodLearnRateIntervals = null;

		this.oAvgCorrectionTime = new cAverage();
		this.iLastTimeMs = 0;
	}

  /** Vr�t� p�idru�enou s� p�idru�en�ho NN adapt�ru. */
	public cNeuralNet GetNet()   { return this.oNetAdapter.oNeuralNet; }
  /** Vr�t� posledn� sou�et chyb. */
	public double GetErrorSum()  { return this.dLastErrorSum; }
  /** Vr�t� posledn� �rove� chyby. */
	public double GetErrorLevel(){ return this.dLastErrorLevel; }

  /** Vr�t� po�et cykl� v�po�tu (vybr�n� vstupu a v�po�et). */
	public int GetTurnsCount(){ return this.iTurns; }
  /** Vr�t� po�et oprav. */
	public int GetCorrectionsCount(){ return this.iCorrections; }
  /** Vynuluje po��tadla cyklu u�en� a cyklu oprav. */
	public void ResetCounters(){ this.iTurns  = 0; this.iCorrections = 0; }
  
  /** P�i�ad� novou tr�novac� mno�inu. */
  public void SetTrainSet(cNeuralTrainSet oTrainSet){ this.oTrainSet = oTrainSet; }

	/** Jedno kolo v�po�tu - vybr�n� vstupu a v�po�et.  */
	public void Turn(){
		this.iTurns++;
		this.oCurTrainSetItem = this.oTrainSet.GetRandom();
    if(null == this.oCurTrainSetItem){
      Debug.Write(Debug.E_ERROR, "cNeuralNetTeacher::Turn(): this.oCurTrainSetItem == null!!");
      return;
    }
		//this.oCurTrainSetItem = this.oTrainSet.GetAt(2);
		Debug.Write(Debug.E_NOTICE, 2351, "Vstupn� hodnoty: [" + this.oCurTrainSetItem.adI + "]"); ///
		Debug.Write(Debug.E_NOTICE, 2352, "Cht�n�  hodnoty: [" + this.oCurTrainSetItem.adO + "]"); ///

		this.oNetAdapter.SetInputValues(this.oCurTrainSetItem.adI);
		this.oNetAdapter.oNeuralNet.Compute();
	}
	

	
	/*********************************************************************************
	  cNeuralNetTeacher::PerformCorrection()                                          
		P�izp�soben� s�t�: Porovn�n� rozd�lu a oprava vah. 
		
		Koncept proch�zen� s�t�:
		
		- Jsou dv� mno�iny:              (lib.cSet.js)
		  - setDoneNeurons - uchov�v� neurony se spo�ten�m errorem 
		  - setNextNeurons - obsahuje kandid�ty na v�po�et v dal��m kole (while)
		- V ka�d�m kole se projdou kandid�ti a zjist� se, jestli v�echny jejich 
		  odchoz� synapse vedou do ji� spo�ten�ch neuron� (setDoneNeurons.has(...)).
		  - Pokud ne, neuron se ponech� mezi kandid�ty.
		  - Pokud ano, neuron se spo�te (dError),
		    odstran� se z kandid�t� (setNextNeurons.remove(...)),
		    vlo�� se do spo�ten�ch (setDoneNeurons.put()),
		    a neurony do n�j vch�zej�c� se p�idaj� do kandid�t� (setNextNeurons.put()).
		- Tento algoritmus nefunguje, pokud s� obsahuje smy�ky.
		- Pl�nuju algoritmus d�t p��mo do cNeuralNetwork, kde by m�l za �kol rozhodnout
		  o tom, jestli s� obsahuje smy�ky, a pokud ne, sestavit po�ad� v�po�tu.
		
	*********************************************************************************/
	public boolean PerformCorrection(){
		this.iCorrections++;
		//var _dw = null;
		
		Date oTimeStart = new Date();
		double dErrorSum = 0.0;	
		cNeuralNet oNeuralNet = this.oNetAdapter.oNeuralNet;
		
		// Z�sk�n� hodnot 
		double[] adVystupyReal = this.oNetAdapter.GetOutputValues();
		double[] adVystupyWant = this.oCurTrainSetItem.adO;
		if(adVystupyWant.length < adVystupyReal.length)
			return false;
			
		//String s = ArrayMap( adVystupyReal, function(d){ return cRound.Round(d,4); } );
		Debug.Write(Debug.E_NOTICE, 2330, "V�stupn� hodnoty: [" + cRound.implode(adVystupyReal) + "]"); ///
    Debug.Write(Debug.E_NOTICE, 2330, "Cht�n�   hodnoty: [" + cRound.implode(adVystupyWant) + "]"); ///

		
		/*for( var i in adVystupyReal ){
			//dErrorSum += adVystupyDiff[i] = adVystupyWant[i] - adVystupyReal[i];
			//adWeightDeltas[i] = this.oNetAdapter.oNeuralNet.fFunc( adVystupyReal[i] ) * adVystupyDiff[i];
			// error = OutReal * (1 � OutReal) * (OutWant � OutReal)
		}/**/
			

		// Pracovn� prostor... 
		ArrayList<cNeuron> aoCurNeurons;
		HashSet setNextNeurons = new HashSet();
		HashSet setDoneNeurons = new HashSet();
		//cNeuron oCurNeuron;
		int _iRounds = 0;
		
		
		/* ----------------- V�stupn� vrstva ----------------- */
		
		Debug.Write(Debug.E_NOTHING, 2331, "."); ///
		Debug.Write(Debug.E_NOTICE, 2331, "Starting backprop round # -1  - output layer"); ///
			
		// Pro v�echny v�stupn� neurony s�t� - nastav�me jim Error. 
		int i = 0;
		for( Object o : oNeuralNet.aoOutputNeurons ){
			cNeuron oCurNeuron  = (cNeuron)o;
			  Debug.Write(Debug.E_NOTICE, 2332, "- Correcting "+(oCurNeuron.toStringFull())+""); ///
			setDoneNeurons.add(oCurNeuron);
			
			// -- http://www.tek271.com/articles/neuralNet/IntoToNeuralNets.html -- 
			        /* derivace Sigmoidy */          /* dDiff */
			// e =  (   z * (1 � z)       )     *     ( y � z );    z == dOutReal,  y == dOutWant 
			
			// Rozd�l mezi vstupem a v�stupem 
			double dOutReal = oCurNeuron.dValue;
			double dDiff = adVystupyWant[i] - dOutReal;
			// Chyba tohoto v�st. neur.
			oCurNeuron.dError = oCurNeuron.fFunc.derivation(dOutReal) * dDiff;
			  Debug.Write(Debug.E_NOTICE, 2333, "("+oCurNeuron.id+") diff: "+cRound.Round(dDiff, 5)+" err: "+cRound.Round(oCurNeuron.dError, 5)); ///
        Debug.Write(Debug.E_NOTICE, 2333, "("+oCurNeuron.id+") diff: "+(dDiff)+" err: "+(oCurNeuron.dError)); ///
			dErrorSum += Math.abs(oCurNeuron.dError);

			// Dq = e * lambda;
			double dPom = oCurNeuron.dError * this.dLearn;
			  Debug.Write(Debug.E_NOTICE, 2334, "("+oCurNeuron.id+") err * lambda: " +cRound.Round(dPom, 5)); ///
				
			oCurNeuron.dBias += dPom;
			
			for( Object oSyn : oCurNeuron.aRecep ){
				cSynapse oSynapseIn = (cSynapse)oSyn;
				// Dw[i] = Dq * vstup_neuronu[i]; 
				oSynapseIn.dWeight += dPom * oSynapseIn.GetInput(); /// D�no do neuronu 
				setNextNeurons.add(oSynapseIn.oFrom);
			}
			Debug.Write(Debug.E_NOTICE, 2335, "+ Corrected "+(oCurNeuron.toStringShort())+""); ///
			i++;
		}// for( Object o : oNeuralNet.aoOutputNeurons )
		aoCurNeurons = new ArrayList(setNextNeurons);
		//setNextNeurons.clear();     // Neurony se odstra?uj�, kdy� jsou spo�ten�. 



		// --- Zpracov�n� error sum --- //
		this.dLastErrorSum = dErrorSum;
		this.dLastErrorLevel = dErrorSum / oNeuralNet.aoOutputNeurons.size();
  		Debug.Write(Debug.E_NOTICE, 2336, "Error Sum: " +cRound.Round(dErrorSum, 5)); ///
		this.adErrorLevels.add(this.dLastErrorLevel);
		if(this.dLastErrorLevel < this.dTargetError)
			; // N�co ud�lat. 
			
		
		// Pokud nen� je�t� nalezeno po�ad� v�po�tu neuron�, vypo��t�me ho te�.
    if(null == this.oNetAdapter.oNeuralNet.aoNeuronsOrder)
      this.oNetAdapter.oNeuralNet.FindComputingOrder();
    
		aoCurNeurons = this.oNetAdapter.oNeuralNet.aoNeuronsOrder;
		// Neurony z v�stupn� vrstvy u� po��tat nebudeme. 
		ArrayList<cNeuron> aoCurNeurons2 = new ArrayList();
		for( cNeuron oN : aoCurNeurons ){
			if( !setDoneNeurons.contains(oN) )
				aoCurNeurons2.add( oN );
		}/**/
		aoCurNeurons = aoCurNeurons2;
		
		

		/* ----------------- Zbyl� vrstvy... ----------------- */

		// Dokud jsou ve front� na v�po�et n�jak� neurony... 
		while(aoCurNeurons.size() > 0) {
			Debug.Write(Debug.E_NOTHING, 2331, "."); ///
			Debug.Write(Debug.E_NOTICE, 2331, "Starting backprop round #"+(_iRounds++)+""); ///

			try{
			// Pro v�echny neurony ve front� na v�po�et v tomto kole... 
			for_aoCurNeurons:
			for( cNeuron oCurNeuron : aoCurNeurons ){
				//oCurNeuron = aoCurNeurons[i];
          Debug.Write(Debug.E_NOTICE, 2332, "- Correcting "+(oCurNeuron.toStringShort())+""); ///
					
				// Pokud u� je neuron hotov�, vynd�me ho z fronty a p�esko��me.
				// T�k� se v�stupn� vrstvy - po�ad� v�po�tu je vypo�ten� p�edem. 
				// if( !setDoneNeurons.has(oCurNeuron) ) continue;
				// Tak nakonec ne - vyfiltruju si to u� p�ed cyklem.
				
				// Se�teme errory z navazuj�c�ch neuron�, vyn�soben� vahami synaps� do nich  [ g = SUM( m[i] * e[i] ) ]
				dErrorSum = 0.0;
				for( Object oSynOut : oCurNeuron.aTrans ){
					cSynapse oSynapseOut = (cSynapse)oSynOut;
					dErrorSum += oSynapseOut.oTo.dError * oSynapseOut.dWeight;
				}
				
				// Ulo�en� chyby tohoto v�st. neur.
				oCurNeuron.dError = dErrorSum * oCurNeuron.fFunc.derivation(oCurNeuron.dValue);
					//Debug.Write("("+oCurNeuron.id+")  err: "+Round(oCurNeuron.dError, 5)); ///

				double dPom  = oCurNeuron.dError * this.dLearn;

				oCurNeuron.dBias += dPom;

					//Debug.Write("- Following: [ "+(oCurNeuron.aRecep)+" ]"); ///
				// Pro v�echny p�edch�zej�c� neurony... 
				for( Object oSynIn : oCurNeuron.aRecep ){
					cSynapse oSynapseIn = (cSynapse)oSynIn;
					cNeuron oFromNeuron = oSynapseIn.oFrom;
					if( oFromNeuron == null )  continue;
					// uprav�me v�hy synaps� vedouc�ch z n�j sem, 
					oSynapseIn.dWeight += oFromNeuron.dValue * dPom;
				}
				
				Debug.Write(Debug.E_NOTICE, 2335, "+ Corrected "+(oCurNeuron.toStringShort())+""); ///
				
			}// for( var i in aoCurNeurons )			
			}catch(Exception e){ Debug.Write(Debug.E_ERROR, 2336, "... Exception " + e); }
			
			// V setNextNeurons m�me mno�inu neuron� na dal�� kolo backpropagation. 
			//aoCurNeurons = setNextNeurons.getMembers();
			break;

		}// while()
		
		
		this.iLastTimeMs = (int)( (new Date()).getTime() - oTimeStart.getTime() );
		this.oAvgCorrectionTime.AddSample( this.iLastTimeMs );
		this.oAvgErrorLevels.AddSample( this.dLastErrorLevel );
		if( this.iCorrections >= 20 )
			this.oAvgErrorLevels.RemSample(  (Double)this.adErrorLevels.get(this.adErrorLevels.size()-20) );
		
		
		
		Debug.Write(Debug.E_NOTHING, 2339, "."); ///
		Debug.Write(Debug.E_NOTICE, 2339, "Correcting finished. Time: "+this.iLastTimeMs+" ms; Overall avg time: "+this.oAvgCorrectionTime+" ms"); ///
		
		return true;

	} // cNeuralNetTeacher.prototype.PerformCorrection() 
	
	
	
	
	/** Vrac� pr�m�r z posledn�ch iCorrections opravov�n�. */
	public double GetErrorLevelsAvg(int iCorrections, int iBackOffset){
		if(iCorrections == 0){
			return this.oAvgErrorLevels.GetAverage();
		}
	
		//if(iBackOffset == 0) iBackOffset = 0;
		int iIndex1 = Math.max(0, this.adErrorLevels.size() - iCorrections - iBackOffset);
		int iIndex2 = Math.max(0, this.adErrorLevels.size() - 1 - iBackOffset);
		
		double dAvg = 0.0;
		for( int i = iIndex1; i < iIndex2; i++ ){
			dAvg += (Double)this.adErrorLevels.get(i);
		}
		return dAvg / (iIndex2 - iIndex1 + 1);
	}
	
	
	/** Sets the [error <-> learn rate ] correlation intervals */
	public void SetLearnRateIntervals(cLearnRateInterval[] aodLearnRateIntervals){
		this.aodLearnRateIntervals = aodLearnRateIntervals;
		/*this.aodLearnRateIntervals = [
			{dError: 1.0, dLearnRate: 0.7},
			{dError: 0.8, dLearnRate: 0.5},
			{dError: 0.3, dLearnRate: 0.3},
			{dError: 0.1, dLearnRate: 0.1}
		];*/
	}
	
	/** Adjusts Learn Rate (LAMBDA) according to current average error sum */
	public boolean AdjustLearnRate(){
		if(null == this.aodLearnRateIntervals) return false;
		
		double dErrorLevelAvg = this.GetErrorLevelsAvg(0, 60);
		for( int i = this.aodLearnRateIntervals.length-1;  i >= 0;  i-- ){
			if( dErrorLevelAvg <= this.aodLearnRateIntervals[i].dError ){
				this.dLearn = this.aodLearnRateIntervals[i].dLearnRate;
				break;
			}
		}
		return true;
	}
	
}// class cNeuralNetTeacher






/*
	oVzor = oTrainSet.GetRandom();
	oVzor = aoadVzory[2];
	
	_dw.Write("Vstupn� hodnoty: [" + oVzor.adI + "]"); ///

	oNetAdapter.SetInputValues(oVzor.adI);
	oNetAdapter.oNeuralNet.Compute();

	var adVystupyReal = oNetAdapter.GetOutputValues();
	var dError = oNetAdapter.GetError();

	var s = ArrayMap( adVystupyReal,(d){ return RoundPrec(d, 100); } );
	_dw.Write("V�stupn� hodnoty: " + s); ///
	
	for( var i = 0; i < 10; i++){
		Debug.Write("--- oNetTeacher.Turn(); ---"); ///
		oNetTeacher.Turn();
		Debug.Write("--- oNetTeacher.PerformCorrection(); ---"); ///
		oNetTeacher.PerformCorrection();
	}
*/