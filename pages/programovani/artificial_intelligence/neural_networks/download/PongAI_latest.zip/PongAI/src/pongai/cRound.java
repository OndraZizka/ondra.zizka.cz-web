package pongai;

import java.util.ArrayList;

/** Matematicke pomucky
 *  @author Ondra �i�ka
 */
public class cRound {

  /** Zaokrouhl� dan� ��slo na dan� po�et desetinn�ch m�st. */
  public static int Round(double d, int iDecimals){ return (int)( (Math.round(d * iDecimals)) / (double)iDecimals ); }
  
  
  public static final double LAMBDA = 1.0;
  public static double Normalize(double dX){
    // 1 / ( 1 + exp(-x) )
    //var dOutput = 1 + Math.pow(Math.E, (-1) * arguments.callee.LAMBDA * dX);
    double dOutput = 1 + Math.exp( -dX * LAMBDA);
    return (1 / dOutput) - 0.5;
  }
  
  
  /** Vybere n�hodn� ��slo s danou pravd�podobnost�.
   *  Nap�. p�i zadan�ch pravd�podobnostech {0.1, 0.1, 0.4}
   *  s p��slu�nou pravd�podobnost� vrac�  ��sla 0, 1, 2 .
   */
  public static int GetWeightedRandom(double[] adIntervals){
    int i = 0;
    double dSum = 0;
    
    for( i = 0; i < adIntervals.length; i++ )
      dSum += adIntervals[i];
       
    double dRand = Math.random() * dSum;
    
    dSum = 0;
    for( i = 0; i < adIntervals.length; i++ ){
      dSum += adIntervals[i];
      if(dSum > dRand){ break; }
    }
    
    return i;    
  }
  
  /** Vybere n�hodn� ��slo s danou pravd�podobnost�.
   *  Obdoba verze s "double" intervaly, tak�e asi rychlej��.
   */
  public static int GetWeightedRandom(int[] aiIntervals){
    int i = 0;
    int iSum = 0;
    
    for( i = 0; i < aiIntervals.length; i++ )
      iSum += aiIntervals[i];
       
    int iRand = (int)( Math.random() * iSum );
    
    iSum = 0;
    for( i = 0; i < aiIntervals.length; i++ ){
      iSum += aiIntervals[i];
      if(iSum > iRand){ break; }
    }
    
    return i;    
  }
  
  
  /** Spoj� ��rkami dohromady partu intu */
  public static String implode(int[] ai){
    StringBuffer s = new StringBuffer();
    int i;
    for(i = 0; i < ai.length; i++){
      s.append(ai[i]);
      s.append(",");
    }
    // Odeberem carku 
    if(i > 0)
      s.deleteCharAt(s.length()-1);

    return s.toString();
  }
  
  /** Spoj� ��rkami dohromady partu doublu */
  public static String implode(double[] ad){
    StringBuffer s = new StringBuffer();
    int i;
    for(i = 0; i < ad.length; i++){
      s.append(ad[i]);
      s.append(",");
    }
    // Odeberem carku 
    if(i > 0)
      s.deleteCharAt(s.length()-1);

    return s.toString();
  }
  
  
  
  /** --- Test --- */
  public static void xmain(String[] args){
    double[] adIntervals = {0.1, 0.1, 0.4};
    int[]    aiHits      = {0, 0, 0};
    int iRand;
    for( int i = 0; i < 6000; i++ ){
      iRand = cRound.GetWeightedRandom(adIntervals);
      aiHits[iRand]++;
      //System.out.println(iRand);
    }
    for(int i : aiHits)
      System.out.print(i + " ");
    // 936 1027 4037  => OK
  }

}// public class cRound
