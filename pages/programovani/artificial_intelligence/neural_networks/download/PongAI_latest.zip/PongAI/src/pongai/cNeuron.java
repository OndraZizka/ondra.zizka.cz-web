package pongai;
import java.util.ArrayList;
import java.util.Iterator;

/* cNeuron.java */

interface iNeuronFunction {
  //public static String ID = "";
  public String getID(); 
  public double Compute(double dInput);
  public double derivation(double dX);
}

/**************************************************************
  Trida pro neuron                                             
 *  @author Ondra �i�ka
**************************************************************/
public class cNeuron {
  
  int id;
  double dValue;
  double dBias;
	double dError; // Je potreba na uceni. Mozna dat do zdedene tridy?
  iNeuronFunction fFunc;
  
  ArrayList aRecep;
  ArrayList aTrans;

  private static int iNextID = 0;
  /** Vrac� ��seln� ID unik�tn� pro tuto s�. */
  public static int GetUniqueID(){ return ++iNextID; }
  public static void IncrementUniqueID(int iID){ iNextID = Math.max(iNextID, iID + 1); }
   
  
  /** Creates a new instance of cNeuron */
  public cNeuron(){ this.Init(cNeuron.GetUniqueID(), 0.0, Math.random(), cNeuron.afFuncs[0]); }
  public cNeuron(int iID){ this.Init(iID, 0.0, Math.random(), cNeuron.afFuncs[0]); }
  public cNeuron(int iID, double dValue){ this.Init(iID, dValue, Math.random(), cNeuron.afFuncs[0]); }
  public cNeuron(int iID, double dValue, double dBias){ this.Init(iID, dValue, dBias, cNeuron.afFuncs[0]); }
  public cNeuron(int iID, double dValue, double dBias, iNeuronFunction fFunc){ this.Init(iID, dValue, dBias, fFunc); }
  
  /** Nastav� hodnoty neuronu. */
  public void Init(int iID, double dValue, double dBias, iNeuronFunction fFunc){
		if(iID == 0) iID = cNeuron.GetUniqueID();
    //else cNeuron.IncrementUniqueID(iID); // Stejne to nezajisti konzistenci. Tu je treba hlidat na vyssi urovni.
    this.id = iID;          /// for debug info 
    this.dValue = dValue;   // Vypo�ten� hodnota - pro Compute()
    this.dBias = dBias;     // P?�davek ke vstup?m - Bias neboli Treshold neboli x0 neboli ...
    this.fFunc = fFunc;     // Defaultn� sigmoida 

    this.aRecep = new ArrayList();        // receptors    
    this.aTrans = new ArrayList();        // transmitters 
  }

  /** @return Popis neuronu ve form�tu "cNeuron { id: id, v:dValue, b:dBias, recep: [aRecep], trans: [aTrans] }" */
  public String toStringFull(){ return "cNeuron { id: "+this.id+", v:"+cRound.Round(this.dValue,2)+", b:"+cRound.Round(this.dBias,2)+", recep: "+this.aRecep+", trans: "+this.aTrans+" }"; }
  /** @return Popis neuronu ve form�tu "cNeuron #id, v:dValue, b:dBias, R[aRecep.size], T[aTrans.size] }" */
  public String toStringShort(){ return "cNeuron #"+this.id+", v:"+cRound.Round(this.dValue,2)+" { b:"+cRound.Round(this.dBias,2)+", R["+this.aRecep.size()+"], T["+this.aTrans.size()+"] }"; }
  /** @return Popis neuronu ve form�tu "cNeuron #id" */
  public String toStringTiny(){ return "cNeuron #"+this.id; }
  /** @return Popis neuronu ve form�tu "(id)" */
  public String toStringAtom(){ return "("+this.id+")"; }
  /** @return to sam� jako #toStringShort(). */
  public String toString(){ return this.toStringShort(); }
 
  /** P�id� na vstup danou synapsi. */
  public void AddRecep(cSynapse oFromSynapse){
     this.aRecep.add(oFromSynapse);
  }
  /** P�id� na v�stup danou synapsi. */
  public void AddTrans(cSynapse oToSynapse){
     this.aTrans.add(oToSynapse);
  }
  
  /** Spo�ten� v�stupu neuronu. Se�te vstupy ze synaps�
   *  (vyn�soben� jejich vahami) a pro�ene funkc�. */
  public double Compute(){
    //var _s = "- Sum: "; ///

    double dSum = this.dBias;
      //_s += "b:"+ cRound.Round(-this.dBias, 2); ///

    // Pro ka�dou p?�choz� synapsi...
    Iterator i = this.aRecep.iterator();
    //for(int i; i < this.aRecep; i++){
    while(i.hasNext()) {
      cSynapse oSynapse = (cSynapse)i.next();
      // ...z n� vyt�hnem hodnotu a p�i�tem. 
      dSum += oSynapse.GetValue();
      //_s += ", "
      //  + (this.aRecep[i].oFrom ? this.aRecep[i].oFrom.id : "null")
      //	+ ": " + cRound.Round(this.aRecep[i].GetInput(), 2)
      //	+ "*"  + cRound.Round(this.aRecep[i].dWeight, 2); ///
    }


      //_s += " => "+ cRound.Round(dSum, 2); ///

    double dOutput = this.fFunc.Compute(dSum);
      //_s += " => "+ cRound.Round(dOutput, 2); ///
      //if(_dw) _dw.Write(_s);

    // Hodnotu ukl�d�me do neuronu, synapse si to bere z n?j 
    this.dValue = dOutput;

    return dOutput;
  }// cNeuron::Compute()
  
  

  // --- Funkce --- //
  public static iNeuronFunction[] afFuncs = null;
  
  static{
    afFuncs = new iNeuronFunction[1];
    afFuncs[0] = new cSigmoid();
  }
  
}// class cNeuron



/** Logick� sigmoida. */
class cSigmoid implements iNeuronFunction {
  
  private static cSigmoid oInstance = null;
  public static cSigmoid GetInstance(){
    if(null == oInstance)
      oInstance = new cSigmoid();
    return oInstance;
  }
  public static String ID = "sig";
  public String getID(){ return ID; }
  public String toString(){ return ID; }
  // Obr�cen� parabola s vrcholem vpravo dole od [0,0] Viz GNUplot > plot x * (1 - x)
  public double derivation(double x){ return x * (1 - x); };
      
  // Strmost Sigmoidy; viz GNUplot > plot 1 / ( 1 + exp(- x * 5 ) )
  public static double LAMBDA = 1;

  /** V�po�et sigmoidy.  1 / ( 1 + exp(-x  * LAMBDA) ) */
  public double Compute(double dX){
    // 1 / ( 1 + exp(-x) )
    //var dOutput = 1 + Math.pow(Math.E, (-1) * arguments.callee.LAMBDA * dX);
    double dOutput = 1 + Math.exp( -dX * LAMBDA);
    return 1 / dOutput;
  }
}

/** Generic Singleton2 class */
/*class Singleton2<E extends Object>{
  private static E oInstance;
  public static E GetInstance(){ return oInstance; }
  private Singleton2(){ oInstance = this; }
}/**/

/** Generic Singleton class */
class Singleton{
  private static Singleton oInstance;
  public static Singleton GetInstance(){ return oInstance; }
  private Singleton(){ oInstance = this; }
}



/** Schodov� funkce */
class Step implements iNeuronFunction {
  public double Compute(double dX){ return dX < 0 ? -1 : 1; }
  public double derivation(double dX){ return 0.0; }
  public static String ID = "step";
  public String getID(){ return ID; }
  public String toString(){ return ID; }
  //public static afFuncs[public static Step.ID] = public static Step;
}


