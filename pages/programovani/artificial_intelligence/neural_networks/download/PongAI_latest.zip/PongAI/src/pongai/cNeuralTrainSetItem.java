/*
 * cNeuralTrainSet.java
 *
 * Created on 4. leden 2006, 23:36
 */

package pongai;

/**  class cNeuralTrainSetItem 
  @author Ondra �i�ka 
**/
public class cNeuralTrainSetItem{
	public double[] adI;
	public double[] adO;
	
  /** Vytvo�� vzorek do tr�novac� mno�iny. */
	public cNeuralTrainSetItem(double[] adInputValues, double[] adOutputValuesWanted){
		this.adI = adInputValues;
		this.adO = adOutputValuesWanted;
	}
  /** Vr�t� sou�et chyby v�sledk� v�po�tu oproti po�adovan�mu v�sledku.
   @param adOutputValuesReal  Skute�n� v�sledky v�po�tu. */
	public double GetDifference(double[] adOutputValuesReal){
		double dSumReal = 0;
		for( double dVal : adOutputValuesReal )
			dSumReal += dVal;
		return dSumReal;
	}
}
