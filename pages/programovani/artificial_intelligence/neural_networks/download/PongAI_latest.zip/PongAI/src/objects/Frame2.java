package objects;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.Component;
import java.awt.*;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.JFileChooser;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author Tom� B�trla, Zden�k Roule
 */
public class Frame2 extends JFrame{
    JPanel contentPane;
    JScrollPane jScrollPane1 = new JScrollPane();
    GameManager gm;
    int prepni=1;
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenu1 = new JMenu();
    JMenuItem jMenuItem1 = new JMenuItem();
    JMenuItem jMenuItem2 = new JMenuItem();
    JMenu jMenu2 = new JMenu();
    JRadioButtonMenuItem jRadioButtonMenuItem1 = new JRadioButtonMenuItem("Prezentace",true);
    JRadioButtonMenuItem jRadioButtonMenuItem2 = new JRadioButtonMenuItem("U�en�",false);
    JMenu jMenu3 = new JMenu();
    JMenu jMenu4 = new JMenu();
    JMenuItem jMenuItem3 = new JMenuItem();
    JMenuItem jMenuItem5 = new JMenuItem();
    JMenu jMenu5 = new JMenu();
    JMenuItem jMenuItem4 = new JMenuItem();
    JMenuItem jMenuItem6 = new JMenuItem();
    JFileChooser filechooser =new JFileChooser();

    public Frame2() {
        try { setDefaultCloseOperation(EXIT_ON_CLOSE); jbInit(); }
        catch (Exception exception) { exception.printStackTrace(); }
    }

    /** Component initialization.
     * @throws java.lang.Exception
     */
    private void jbInit() throws Exception {
        gm = new GameManager();
         gm.start();
        contentPane = (JPanel)getContentPane();
        contentPane.setLayout(null);
        this.setJMenuBar(jMenuBar1);
        this.setResizable(false);
        this.setSize(new Dimension(657, 622));
        this.setTitle("Pong - Prezentace");
        jScrollPane1.getViewport().setBackground(Color.gray);
        jScrollPane1.setBounds(new Rectangle(61, 23, 524, 526));
        gm.setBackground(Color.lightGray);
        jMenu1.setText("Program");
        jMenuItem1.setText("Zobrazit informace");
        jMenuItem1.addActionListener(new Frame2_jMenuItem1_actionAdapter(this));
        jMenuItem2.setText("Konec");
        jMenuItem2.addActionListener(new Frame2_jMenuItem2_actionAdapter(this));
        jMenu2.setText("P�epnut� m�du");
        jRadioButtonMenuItem1.addActionListener(new
                Frame2_jRadioButtonMenuItem1_actionAdapter(this));
       jRadioButtonMenuItem2.addActionListener(new
                Frame2_jRadioButtonMenuItem2_actionAdapter(this));
        jMenu3.setText("Spr�va agent�");
        jMenu4.setText("Agent 1");
        jMenuItem3.setText("Na�ten� agenta");
        jMenuItem3.addActionListener(new Frame2_jMenuItem3_actionAdapter(this));
        jMenuItem5.setText("Ulo�en� agenta");
        jMenuItem5.addActionListener(new Frame2_jMenuItem5_actionAdapter(this));
        jMenu5.setText("Agent 2");
        jMenuItem4.setText("Na�ten� agenta");
        jMenuItem4.addActionListener(new Frame2_jMenuItem4_actionAdapter(this));
        jMenuItem6.setText("Ulo�en� agenta");
        jMenuItem6.addActionListener(new Frame2_jMenuItem6_actionAdapter(this));
        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);
        jMenuBar1.add(jMenu3);
        jMenu1.add(jMenuItem1);
        jMenu1.addSeparator();
        jMenu1.add(jMenuItem2);
        jMenu2.add(jRadioButtonMenuItem1);
        jMenu2.add(jRadioButtonMenuItem2);
        ButtonGroup bg=new ButtonGroup();
        bg.add(this.jRadioButtonMenuItem1);
        bg.add(this.jRadioButtonMenuItem2);
        contentPane.add(jScrollPane1, null);
        jScrollPane1.getViewport().add(gm);
        jMenu3.add(jMenu4);
        jMenu3.add(jMenu5);
        jMenu4.add(jMenuItem3);
        jMenu4.add(jMenuItem5);
        jMenu5.add(jMenuItem4);
        jMenu5.add(jMenuItem6);
    }

    public void jMenuItem2_actionPerformed(ActionEvent e) {
        System.exit(0);
    }

    public void jMenuItem1_zobrazstatistiku(ActionEvent e) {
        Statist st=new Statist();
        st.show();
    }

    public void jRadioButtonUceni_actionPerformed(ActionEvent e) {
       gm.SetMode(1);
       this.setTitle("Pong - Prezentace");
   }

    public void jRadioButtonPrezentace_actionPerformed(ActionEvent e) {
       gm.SetMode(2);
       this.setTitle("Pong - U�en�");
    }

    public void jMenuItem3_nacteniagenta1(ActionEvent e) {
       this.filechooser.showOpenDialog(this);
       File fi=filechooser.getSelectedFile();
       String text=predejtext(fi);
       gm.nauc_agenta(text, 0);
               
    }

    public void jMenuItem5_ulozeniagenta1(ActionEvent e) {
        this.filechooser.showSaveDialog(this);
        File f=filechooser.getSelectedFile();
        try{
        this.ulozAgenta(f.getAbsolutePath(), 0);
        }
         catch(Exception exception)
      { exception.printStackTrace();
      }
        
    }

    public void jMenuItem4_nacteniagenta2(ActionEvent e) {
      this.filechooser.showOpenDialog(this);
      File fi=filechooser.getSelectedFile();
      String text=predejtext(fi);
      gm.nauc_agenta(text,1);
      
    }

    public void jMenuItem6_ulozeniagenta2(ActionEvent e) {
        this.filechooser.showSaveDialog(this);
         File f=filechooser.getSelectedFile();
         try{
        this.ulozAgenta(f.getAbsolutePath(), 1);
         }
          catch(Exception exception)
      { exception.printStackTrace();
      }
    }
    
    public String predejtext(File f)
    {
        String line;
        String text="";
    try
        {      
            BufferedReader in = new BufferedReader( new FileReader(f));
            line = in.readLine();
            text=line;
             while ( line != null )  // continue until end of file
            {
                line=in.readLine();
                text=text+line;
            }
              in.close();
             }
        catch ( IOException iox )
             {
                System.out.println("Problem reading " + f);
             }
        return text;
    }
    
    public void ulozAgenta(String path,int cislo) throws FileNotFoundException, IOException
    {
        FileWriter fw=new FileWriter(path);
        fw.write(gm.agents[cislo].oNetTeacher.GetNet().Serialize());
        fw.close();       
    }
       
   
}


class Frame2_jMenuItem6_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem6_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem6_ulozeniagenta2(e);
    }
}


class Frame2_jMenuItem5_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem5_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem5_ulozeniagenta1(e);
    }
}


class Frame2_jMenuItem4_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem4_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem4_nacteniagenta2(e);
    }
}


class Frame2_jMenuItem3_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem3_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem3_nacteniagenta1(e);
    }
}


class Frame2_jRadioButtonMenuItem2_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jRadioButtonMenuItem2_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButtonPrezentace_actionPerformed(e);
    }
}


class Frame2_jMenuItem2_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem2_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem2_actionPerformed(e);
    }
}


class Frame2_jMenuItem1_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jMenuItem1_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem1_zobrazstatistiku(e);
    }
}


class Frame2_jRadioButtonMenuItem1_actionAdapter implements ActionListener {
    private Frame2 adaptee;
    Frame2_jRadioButtonMenuItem1_actionAdapter(Frame2 adaptee) {
        this.adaptee = adaptee;



    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jRadioButtonUceni_actionPerformed(e);
    }
}
