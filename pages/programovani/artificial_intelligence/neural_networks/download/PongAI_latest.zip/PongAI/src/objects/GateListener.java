package objects;

/**
 * <p>Title: </p>
 * 
 * <p>Description: Implements method for listeners, which is called by Gate when goalMade occurs.</p>
 * 
 * <p>Copyright: Copyright (c) 2005</p>
 * 
 * <p>Company: </p>
 * 
 * 
 * 
 * 
 * @author not attributable
 * @version 1.0
 */
public interface GateListener {
     /**
     * this method is called by registered Gate if agent makes a goal.
     */
    public void goalMade();
    
    /**
     *this method is called by registered Gate if agent recevies a goal
     */
    public void goalReceived();       
}
