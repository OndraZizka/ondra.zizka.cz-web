/*
 * Debug.java
 */

package pongai;

import objects.Statist;

/** Class for debugging purposes.
  @author Ondra �i�ka */
public class Debug {
	
	/** Whether the debugging is on or off. */
	private static boolean bDebug = true;
  /** Turns debugging on. */
	public static void DebugOn(){ bDebug = true; }
  /** Turns debugging off. */
	public static void DebugOff(){ bDebug = false; }
  /** Turns debugging on or off. */
	public static void DebugOnOff(boolean bOn){ bDebug = bOn; }
  /** Turns debugging on or off, with an int param (for convenience). */
	public static void DebugOnOff(int iOn){ bDebug = iOn == 0 ? false : true; }
  
    
  /** What kind of messages to echo. */
   private static int iLevel;
  /** Don't echo anything. */
  public static final int E_NOTHING = 0;
  /** Echo errors only. */
  public static final int E_ERROR = 1;
  /** Echo errors and warnings. */
  public static final int E_WARNING = 2;
  /** Echo everything. */
  public static final int E_NOTICE = 3;
  /** What kind of messages to.
   @param iLevel Use #Debug.E_NOTHING, #Debug.E_ERROR, #Debug.E_WARNING or #Debug.E_NOTICE. */
  public static void SetLevel(int iLevel){ Debug.iLevel = iLevel; }
  
  /** The number of keys the class can remember to mute. */
  public static final int KEYS = 10000;
  /** An array that holds bool info about keys to mute. */
  private static boolean[] abKeys;
  
  static{
    iLevel = Debug.E_NOTICE;
    abKeys = new boolean[Debug.KEYS];
    for(int i = 0; i < Debug.KEYS; i++)
      abKeys[i] = true;
  }
  
  /** Turns specified key on or off. 
   @param iKey Specifies the key.
   @param bOn  Turns the key on or off.  */
  public static void ToggleKey(int iKey, boolean bOn){
    if(iKey >= Debug.KEYS) return;
    Debug.abKeys[iKey] = bOn;
  }
	
	/** Echoes the string #s using #System.out.println(). */
	public static void Write(String s){
		if(!bDebug) return;
		//System.out.println(s);
    Statist.textArea1.append(s+"\n");
	}
  
  /** Echoes the string #s using #System.out.println()
    only if the echo level is #iLevel or higher. 
   @see #SetLevel(int) */
  public static void Write(int iLevel, String s){
		if(!bDebug) return;
    if(Debug.iLevel < iLevel) return;
		//System.out.println(s);
    Statist.textArea1.append(s+"\n");
	}
  
  /** Echoes the string #s using #System.out.println()
   * only if the echo level is #iLevel or higher
   * and the specified key is not muted.
   @see #SetLevel(int)
   @see #ToggleKey(int iKey, boolean bOn)
   */
  public static void Write(int iLevel, int iKey, String s){
		if(!bDebug) return;
    if(Debug.iLevel < iLevel) return;
    if(iKey >= Debug.KEYS || !Debug.abKeys[iKey]) return;
		//System.out.println(s);  
    Statist.textArea1.append(s+"\n");
	}
	
}// class Debug
