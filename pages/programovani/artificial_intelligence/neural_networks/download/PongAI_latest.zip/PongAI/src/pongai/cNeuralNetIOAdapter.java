/*
 * cNeuralNetIOAdapter.java
 */

package pongai;

import java.util.ArrayList;


/**************************************************************
  T��da pro adaptaci vstup�                                    
	- aby nebylo nutn� hrabat se p��mo v s�ti                    
 *  @author Ondra �i�ka
**************************************************************/
public class cNeuralNetIOAdapter {
	
  /** Vstupn� synapse s�t�  */
	public ArrayList aoInputSynapses;
  /** V�stupn� synapse s�t�  */
	public ArrayList aoOutputSynapses;
  /** P�idru�en� s�  */
	public cNeuralNet oNeuralNet;
  /** Vrac� p�idru�enou s�  */
  public cNeuralNet GetNet(){ return this.oNeuralNet; }
	
	/** Creates a new instance of cNeuralNetIOAdapter with the specified neural net attached. 
   * @param oNeuralNet  Attached neural network.
   */
	public cNeuralNetIOAdapter(cNeuralNet oNeuralNet) {
		this.aoInputSynapses  = new ArrayList(/*oNeuralNet.aoInputNeurons.length*/);
		this.aoOutputSynapses = new ArrayList(/*oNeuralNet.aoOutputNeurons.length*/);
		this.oNeuralNet       = oNeuralNet;
		
		// Pro v�echny vstupn� neurony s�t�... 
		for( Object oCurNeuron : oNeuralNet.aoInputNeurons ){
			// ...vytvo��me pseudosynapse, 
			cSynapse oNewPseudoSynapse = new cSynapse(new cNeuron(0, 1.0)/*null*/, (cNeuron)oCurNeuron, 1.0);
			// nav�eme je na neurony, 
			((cNeuron)oCurNeuron).AddRecep(oNewPseudoSynapse);
			// a p�id�me je do pole v tomto adapt�ru. 
			this.aoInputSynapses.add(oNewPseudoSynapse);
		}

		// Pro v�echny v�stupn� neurony s�t�... 
		for( Object oCurNeuron : oNeuralNet.aoOutputNeurons ){
			// ...vytvo��me pseudosynapse, 
			cSynapse oNewPseudoSynapse = new cSynapse((cNeuron)oCurNeuron, null);
			// nav�eme je na neurony, 
			((cNeuron)oCurNeuron).AddTrans(oNewPseudoSynapse);
			// a p�id�me je do pole v tomto adapt�ru. 
			this.aoOutputSynapses.add(oNewPseudoSynapse);
		}
		//alert("Out Neu: "+oNeuralNet.aoOutputNeurons); ///
		//alert("Out Syn: "+this.aoOutputSynapses); ///
		
	}// public cNeuralNetIOAdapter(cNeuralNet oNeuralNet) {
	



	/** Nastav� vstupn�m synaps�m hodnoty.
    @param adValues  Vstupn� hodnoty pro s�.
    @return False if the array doesn't have enough elements. True if everything ok. */
	public boolean SetInputValues(double[] adValues){
		if(adValues.length < this.aoInputSynapses.size())
			return false;

		int i = 0;
		for( Object oSynapse : this.aoInputSynapses ){
			// Synapse vych�z� z neuronu s hodnotou 1.0. Vstup upravujeme zm�nou v�hy!!
			((cSynapse)oSynapse).SetWeight(adValues[i++]);
		}
		return true;
	}

	/** P�e�teme hodnoty na v�stupn�ch synaps�ch. 
   @return Array with output values. */
  public double[] GetOutputValues(){
		//double[] adValues = new ArrayList(this.aoOutputSynapses.size());
		double[] adValues = new double[this.aoOutputSynapses.size()];

		int i = 0;
		for( Object oSynapse : this.aoOutputSynapses ){
			adValues[i++] = ((cSynapse)oSynapse).GetInput();
		}
		return adValues;
	}

	/** Se�teme hodnoty na v�stupu - pro ohodnocen� chyby. 
   @return Sou�et v�stup� na v�stupn�ch synaps�ch. */
	public double GetOutputSum(){
		double dSum = 0.0;
		for( Object oSynapse : this.aoOutputSynapses ){
			dSum += ((cSynapse)oSynapse).GetInput();
		}
		return dSum;
	}


	
}// class cNeuralNetIOAdapter




/*var iNeurons = 100000;
	window.status = "Generating net with "+iNeurons+" neurons...";
	net = new cNeuralNet(iNeurons);
	window.status = "Done";*/