-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.51a-community-nt-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema neural_network
--

CREATE DATABASE IF NOT EXISTS neural_network;
USE neural_network;

--
-- Definition of table `lib_logg`
--

DROP TABLE IF EXISTS `lib_logg`;
CREATE TABLE `lib_logg` (
  `whn` datetime NOT NULL,
  `thread` int(10) unsigned NOT NULL,
  `level` enum('info','warn','error','enter','leave') NOT NULL default 'info',
  `str` varchar(512) default NULL,
  `rout` varchar(255) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lib_logg`
--

/*!40000 ALTER TABLE `lib_logg` DISABLE KEYS */;
/*!40000 ALTER TABLE `lib_logg` ENABLE KEYS */;


--
-- Definition of table `nn_net_neurons`
--

DROP TABLE IF EXISTS `nn_net_neurons`;
CREATE TABLE `nn_net_neurons` (
  `id_net` int(10) unsigned NOT NULL,
  `id_neuron` int(10) unsigned NOT NULL auto_increment,
  `bias` double NOT NULL,
  PRIMARY KEY  (`id_neuron`),
  KEY `id_net` (`id_net`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Neural net neurons';

--
-- Dumping data for table `nn_net_neurons`
--

/*!40000 ALTER TABLE `nn_net_neurons` DISABLE KEYS */;
/*!40000 ALTER TABLE `nn_net_neurons` ENABLE KEYS */;


--
-- Definition of table `nn_net_synapses`
--

DROP TABLE IF EXISTS `nn_net_synapses`;
CREATE TABLE `nn_net_synapses` (
  `id_from` int(10) unsigned default '0',
  `id_to` int(10) unsigned default '0',
  `weight` double NOT NULL,
  UNIQUE KEY `from_to` (`id_from`,`id_to`),
  KEY `id_to` (`id_to`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Connections between neurons';

--
-- Dumping data for table `nn_net_synapses`
--

/*!40000 ALTER TABLE `nn_net_synapses` DISABLE KEYS */;
/*!40000 ALTER TABLE `nn_net_synapses` ENABLE KEYS */;


--
-- Definition of table `nn_networks`
--

DROP TABLE IF EXISTS `nn_networks`;
CREATE TABLE `nn_networks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `inputs` int(10) unsigned NOT NULL default '0',
  `outputs` int(10) unsigned NOT NULL default '0',
  `architecture` enum('perceptron') NOT NULL default 'perceptron',
  `definition` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Neural networks';

--
-- Dumping data for table `nn_networks`
--

/*!40000 ALTER TABLE `nn_networks` DISABLE KEYS */;
/*!40000 ALTER TABLE `nn_networks` ENABLE KEYS */;


--
-- Definition of table `nn_trainsets`
--

DROP TABLE IF EXISTS `nn_trainsets`;
CREATE TABLE `nn_trainsets` (
  `id_set` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `input_count` int(10) unsigned NOT NULL,
  `output_count` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id_set`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 PACK_KEYS=1 ROW_FORMAT=FIXED;

--
-- Dumping data for table `nn_trainsets`
--

/*!40000 ALTER TABLE `nn_trainsets` DISABLE KEYS */;
INSERT INTO `nn_trainsets` (`id_set`,`name`,`input_count`,`output_count`) VALUES 
 (1,'XOR train set',2,1);
/*!40000 ALTER TABLE `nn_trainsets` ENABLE KEYS */;


--
-- Definition of table `nn_trainsets_cases`
--

DROP TABLE IF EXISTS `nn_trainsets_cases`;
CREATE TABLE `nn_trainsets_cases` (
  `id_case` int(10) unsigned NOT NULL auto_increment,
  `id_set` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id_case`),
  KEY `id_set` USING BTREE (`id_set`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nn_trainsets_cases`
--

/*!40000 ALTER TABLE `nn_trainsets_cases` DISABLE KEYS */;
INSERT INTO `nn_trainsets_cases` (`id_case`,`id_set`) VALUES 
 (1,1),
 (2,1),
 (3,1),
 (4,1);
/*!40000 ALTER TABLE `nn_trainsets_cases` ENABLE KEYS */;


--
-- Definition of table `nn_trainsets_input`
--

DROP TABLE IF EXISTS `nn_trainsets_input`;
CREATE TABLE `nn_trainsets_input` (
  `id_case` int(10) unsigned NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `val` double NOT NULL,
  PRIMARY KEY  USING BTREE (`pos`,`id_case`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nn_trainsets_input`
--

/*!40000 ALTER TABLE `nn_trainsets_input` DISABLE KEYS */;
INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES 
 (1,1,-1),
 (1,2,-1),
 (2,1,-1),
 (2,2,1),
 (3,1,1),
 (3,2,-1),
 (4,1,1),
 (4,2,1);
/*!40000 ALTER TABLE `nn_trainsets_input` ENABLE KEYS */;


--
-- Definition of table `nn_trainsets_output`
--

DROP TABLE IF EXISTS `nn_trainsets_output`;
CREATE TABLE `nn_trainsets_output` (
  `id_case` int(10) unsigned NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `val` double NOT NULL,
  PRIMARY KEY  USING BTREE (`id_case`,`pos`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nn_trainsets_output`
--

/*!40000 ALTER TABLE `nn_trainsets_output` DISABLE KEYS */;
INSERT INTO `nn_trainsets_output` (`id_case`,`pos`,`val`) VALUES 
 (1,1,0),
 (2,1,1),
 (3,1,1),
 (4,1,0);
/*!40000 ALTER TABLE `nn_trainsets_output` ENABLE KEYS */;


--
-- Definition of table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` int(6) NOT NULL default '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `test`
--

/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` (`id`) VALUES 
 (999999),
 (830217);
/*!40000 ALTER TABLE `test` ENABLE KEYS */;


--
-- Definition of function `F1`
--

DROP FUNCTION IF EXISTS `F1`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F1`( sFormat TEXT, sPar1 TEXT ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE(sFormat, '%s', sPar1);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `F2`
--

DROP FUNCTION IF EXISTS `F2`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F2`( sFormat TEXT, sPar1 TEXT, sPar2 TEXT ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE( REPLACE(sFormat, '{1}', sPar1) , '{2}', sPar2);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `F3`
--

DROP FUNCTION IF EXISTS `F3`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F3`( sFormat TEXT, sPar1 TEXT, sPar2 TEXT, sPar3 TEXT ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE( REPLACE( REPLACE(sFormat, '{3}', sPar3), '{1}', sPar1), '{2}', sPar2);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `F4`
--

DROP FUNCTION IF EXISTS `F4`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F4`( sFormat TEXT, sPar1 TEXT, sPar2 TEXT, sPar3 TEXT,
       sPar4 TEXT ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE( REPLACE( REPLACE( REPLACE( sFormat,
    '{1}', sPar1), '{2}', sPar2), '{3}', sPar3), '{4}', sPar4);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `F5`
--

DROP FUNCTION IF EXISTS `F5`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F5`( sFormat TEXT, sPar1 TEXT, sPar2 TEXT,  sPar3 TEXT,
       sPar4 TEXT, sPar5 TEXT  ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE( REPLACE( REPLACE( REPLACE( REPLACE( sFormat,
    '{1}', sPar1), '{2}', sPar2), '{3}', sPar3), '{4}', sPar4), '{5}', sPar5);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `F6`
--

DROP FUNCTION IF EXISTS `F6`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `F6`( sFormat TEXT, sPar1 TEXT, sPar2 TEXT,  sPar3 TEXT,
       sPar4 TEXT, sPar5 TEXT, sPar6 TEXT  ) RETURNS text CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN REPLACE( REPLACE( REPLACE( REPLACE( REPLACE( REPLACE( sFormat,
    '{1}', sPar1), '{2}', sPar2), '{3}', sPar3), '{4}', sPar4), '{5}', sPar5), '{6}', sPar6);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `lib_GenerateSequenceB_insert`
--

DROP FUNCTION IF EXISTS `lib_GenerateSequenceB_insert`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `lib_GenerateSequenceB_insert`() RETURNS int(11)
BEGIN

  INSERT INTO lib_GenerateTimes SET i = NULL;
  RETURN 0;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `lib_TemporaryTableExists`
--

DROP FUNCTION IF EXISTS `lib_TemporaryTableExists`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `lib_TemporaryTableExists`(sTable VARCHAR(255)) RETURNS tinyint(1)
BEGIN

  ## This does not work: Dynamic SQL is not allowed in stored function or trigger.

  # Table 'x' already exists
  DECLARE EXIT HANDLER FOR 1050 RETURN TRUE;

  # Table 'neural_network.x' doesn't exist
  DECLARE EXIT HANDLER FOR 1146 RETURN FALSE;

  CALL ExecuteQuery(F1('CREATE TEMPORARY TABLE %s SELECT 1 FROM DUAL',sTable));
  CALL ExecuteQuery(F1('DROP TEMPORARY TABLE %s',sTable));
  RETURN FALSE;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `NS`
--

DROP FUNCTION IF EXISTS `NS`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `NS`(s VARCHAR(255)) RETURNS varchar(255) CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  #RETURN IF( s IS NULL, 'NULL', CONCAT('"',s,'"') );
  RETURN IF( s IS NULL, 'NULL', s );
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `NSB`
--

DROP FUNCTION IF EXISTS `NSB`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `NSB`(b BOOLEAN) RETURNS char(5) CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN IF( b IS NULL, 'NULL', IF(b,'TRUE','FALSE') );
  ## SELECT NSB(1);
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `NSQ`
--

DROP FUNCTION IF EXISTS `NSQ`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `NSQ`(s VARCHAR(255)) RETURNS varchar(255) CHARSET utf8
    NO SQL
    DETERMINISTIC
BEGIN
  RETURN IF( s IS NULL, 'NULL', CONCAT('"',s,'"') );
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of function `SIGMOID`
--

DROP FUNCTION IF EXISTS `SIGMOID`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `SIGMOID`( x DOUBLE ) RETURNS double
    NO SQL
    DETERMINISTIC
BEGIN

RETURN 1 / (1 + EXP(-x));

/*
START TRANSACTION;
CALL lib_GenerateSequence(-30000,30000,1);

SELECT 1 / (1 + EXP(-i)) FROM lib_GenerateSequence;   ## 0,033 s
SELECT SIGMOID(i) FROM lib_GenerateSequence;          ## 0,130 s
*/

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `ClearLog`
--

DROP PROCEDURE IF EXISTS `ClearLog`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ClearLog`()
    COMMENT 'Clears the lib_Logg table.'
BEGIN
  TRUNCATE lib_logg;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `ExecuteQuery`
--

DROP PROCEDURE IF EXISTS `ExecuteQuery`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ExecuteQuery`( sSQL TEXT )
BEGIN

  SET @sSQL = sSQL;
  PREPARE stmt_name FROM @sSQL;
  EXECUTE stmt_name;
  DEALLOCATE PREPARE stmt_name;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `lib_Explode`
--

DROP PROCEDURE IF EXISTS `lib_Explode`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `lib_Explode`(sSepar VARCHAR(255), saVal TEXT)
body:
BEGIN

  #CALL Logg(CONCAT('lib_Explode( ', NS(sSepar), ', ',NS(saVal),' )'));

  DROP TEMPORARY TABLE IF EXISTS lib_Explode;
  CREATE TEMPORARY TABLE lib_Explode(
    `pos` int unsigned NOT NULL auto_increment,
    `val` VARCHAR(255) NOT NULL,
    PRIMARY KEY  (`pos`)
  ) ENGINE=Memory COMMENT='Explode() results.';

  IF sSepar IS NULL OR saVal IS NULL THEN LEAVE body; END IF;

  SET @saTail = saVal;
  SET @iSeparLen = LENGTH( sSepar );

  create_layers:
  WHILE @saTail != '' DO

    # Get the next value
    SET @sHead = SUBSTRING_INDEX(@saTail, sSepar, 1);
    #CALL Logg(CONCAT( 'Head: ', @sHead ));
    SET @saTail = SUBSTRING( @saTail, LENGTH(@sHead)+1+@iSeparLen );
    #CALL Logg(CONCAT( 'Tail: ', @saTail ));

    INSERT INTO lib_Explode SET val = @sHead;

  END WHILE;


  #SELECT * FROM lib_Explode; -- DEBUG


END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `lib_GenerateSequence`
--

DROP PROCEDURE IF EXISTS `lib_GenerateSequence`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `lib_GenerateSequence`(iFrom INTEGER, iTo INTEGER, iStep INTEGER)
body:
BEGIN

  #CALL LoggP('lib_GenerateSequence', CONCAT('lib_GenerateSequence(', IFNULL(iFrom,'NULL'),',',
  #                    IFNULL(iTo,'NULL'),',', IFNULL(iStep,'NULL'), ')' ));
  DROP TEMPORARY TABLE IF EXISTS lib_GenerateSequence;
  CREATE TEMPORARY TABLE lib_GenerateSequence (
    i INTEGER NOT NULL,
    PRIMARY KEY USING HASH (i)
  ) ENGINE = Memory;

  ##  Exit if one of arguments is NULL.
  IF iFrom IS NULL OR iTo IS NULL OR iStep IS NULL
    THEN LEAVE body; END IF;


  SET @iMin = iFrom;
  SET @iMax = iTo;

  InsertLoop: LOOP
    -- CALL Logg(CONCAT('@iMin: ', IFNULL(@iMin,'NULL') ));
    IF @iMin > @iMax THEN LEAVE InsertLoop; END IF;
    INSERT INTO lib_GenerateSequence SET i = @iMin;
    SET @iMin = @iMin + iStep;
  END LOOP;

  #CALL LoggP('lib_GenerateSequence', CONCAT('lib_GenerateSequence() end.' ));

  #SELECT * FROM lib_GenerateTimes; -- DEBUG


END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `lib_GenerateSequenceBench`
--

DROP PROCEDURE IF EXISTS `lib_GenerateSequenceBench`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `lib_GenerateSequenceBench`(iFrom INTEGER, iTo INTEGER, iStep INTEGER)
BEGIN

  # BENCHMARK is not real function. This procedure should work as of MySQL 5.1.

  CALL Logg( CONCAT('lib_GenerateSequenceB("', iFrom,'","', iTo,'","', iStep, '")') );


  SET @oldInc = @@session.auto_increment_increment, @oldOff = @@session.auto_increment_offset;
  SET @@session.auto_increment_increment = 1, @@session.auto_increment_offset = 1;

  DROP TEMPORARY TABLE IF EXISTS lib_GenerateSequence;
  CREATE TEMPORARY TABLE lib_GenerateSequence (
    i INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT
  ) AUTO_INCREMENT=0;

    SET @iRuns = (iTo - iFrom) / iStep;
  #BENCHMARK( @iRuns, 'INSERT INTO lib_GenerateTimes SET i = NULL' );
  #SELECT BENCHMARK( @iRuns, lib_GenerateSequenceB_insert() );
  IF iStep != 1 THEN UPDATE lib_GenerateTimes SET i = i * iStep; END IF;
  IF iFrom != 0 THEN UPDATE lib_GenerateTimes SET i = i + iFrom; END IF;

  #SELECT * FROM lib_GenerateTimes; ## Just for testing

  SET @@session.auto_increment_increment = @oldInc, @@session.auto_increment_offset = @oldOff;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `lib_TemporaryTableExists`
--

DROP PROCEDURE IF EXISTS `lib_TemporaryTableExists`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `lib_TemporaryTableExists`(sTable VARCHAR(255), OUT bExists BOOLEAN)
BEGIN

  ####  Usage:  ####
  # CALL lib_TemporaryTableExists('x', @bExists);
  # SELECT @bExists;

  # Table 'x' already exists
  DECLARE EXIT HANDLER FOR 1050 SET bExists = TRUE;

  # Table 'neural_network.x' doesn't exist
  # Should not ever happen.
  #DECLARE EXIT HANDLER FOR 1146 SET bExists = FALSE;

  # If the table does not exist, 1050 error is raised.
  CALL ExecuteQuery(F1('CREATE TEMPORARY TABLE %s SELECT 1 FROM DUAL',sTable));
  # If the table did not exist, we created it; so now drop it to get to previous state.
  CALL ExecuteQuery(F1('DROP TEMPORARY TABLE %s',sTable));
  SET bExists = FALSE;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `lib_TemporaryTableHasColumns`
--

DROP PROCEDURE IF EXISTS `lib_TemporaryTableHasColumns`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `lib_TemporaryTableHasColumns`(
  IN sTable VARCHAR(255), IN saColumns VARCHAR(255), OUT bHas BOOLEAN)
BEGIN

  /* ####  Usage:  ####
  CALL lib_TemporaryTableHasColumns('table', 'col1,col2,col3', @bHas);
  SELECT @bHas;
  /**/

  # Unknown column 'col1' in 'where clause'
  DECLARE EXIT HANDLER FOR 1054 SET bHas = FALSE;

  # Table 'table' doesn't exist
  DECLARE EXIT HANDLER FOR 1146 SET bHas = FALSE;

  # You have an error in your SQL syntax;  ')' at line 1
  # Happens when the columns definition is wrong (e.g. "a,b,")
  -- With this, we could have nice message:
  -- "Unknown column 'lib_TemporaryTableHasColumns(): Bad columns definition [a,b,].' in 'field list'."
  -- But it throws 1054 and is handled by previously declared handler -> no message.
  #DECLARE EXIT HANDLER FOR 1064 CALL ExecuteQuery(F1('SELECT 1+`lib_TemporaryTableHasColumns(): Bad columns definition [%s].` FROM (SELECT 1) AS x', saColumns));
  DECLARE EXIT HANDLER FOR 1064 BEGIN
    SET bHas = FALSE;  ## Known issue: Does not change the out value. (MySQL bug?)
    CALL ExecuteQuery(F1('SELECT 1 FROM `lib_TemporaryTableHasColumns(): Bad columns definition [%s].`', saColumns));
  END;



  #CALL ExecuteQuery(F2('SELECT TRUE INTO @lib_TTHasColumns_foo FROM {1} WHERE TRUE OR FALSE IN ({2}) LIMIT 1', sTable, saColumns));
  #SET @sSQL = F2('SELECT TRUE INTO @lib_TTHasColumns_foo FROM {1} WHERE TRUE OR FALSE IN ({2}) LIMIT 1', sTable, saColumns);
  SET @sSQL = F2('SELECT {2} FROM {1} LIMIT 0', sTable, saColumns);
  PREPARE stmt_name FROM @sSQL;
  DEALLOCATE PREPARE stmt_name;
  SET bHas = TRUE;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Logg`
--

DROP PROCEDURE IF EXISTS `Logg`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Logg`( sStr TEXT )
BEGIN
  INSERT INTO lib_logg SET str = sStr, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `LoggEnter`
--

DROP PROCEDURE IF EXISTS `LoggEnter`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `LoggEnter`(sRout VARCHAR(255))
BEGIN
 INSERT INTO lib_logg
   SET rout = SUBSTRING_INDEX(sRout,'(',1), level='enter', str = sRout, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `LoggLeave`
--

DROP PROCEDURE IF EXISTS `LoggLeave`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `LoggLeave`(sRout VARCHAR(255))
BEGIN
 INSERT INTO lib_logg SET rout = sRout, level='leave', str = NULL, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `LoggP`
--

DROP PROCEDURE IF EXISTS `LoggP`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `LoggP`( sRout VARCHAR(255), sStr TEXT )
BEGIN

  INSERT DELAYED INTO lib_logg SET rout = sRout, str = sStr, whn = NOW(), thread = CONNECTION_ID();
  ## DELAYED  increases performance - around 25 %.
  ## Disabling the INSERT, compared to DELAYED, does not increase performance much or at all %.

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `LoggP_error`
--

DROP PROCEDURE IF EXISTS `LoggP_error`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `LoggP_error`( sRout VARCHAR(255), sStr TEXT )
BEGIN
  INSERT INTO lib_logg SET level = 'error', rout = sRout, str = sStr, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Logg_error`
--

DROP PROCEDURE IF EXISTS `Logg_error`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Logg_error`( sStr TEXT )
BEGIN
  INSERT INTO lib_logg SET level = 'error', str = sStr, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `Logg_warn`
--

DROP PROCEDURE IF EXISTS `Logg_warn`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Logg_warn`( sStr TEXT )
BEGIN
  INSERT INTO lib_logg SET level = 'warn', str = sStr, whn = NOW(), thread = CONNECTION_ID();
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ClearTables`
--

DROP PROCEDURE IF EXISTS `nn_ClearTables`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ClearTables`()
BEGIN

  TRUNCATE lib_logg;
  TRUNCATE nn_net_synapses;
  TRUNCATE nn_net_neurons;
  TRUNCATE nn_networks;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ClearTablesFK`
--

DROP PROCEDURE IF EXISTS `nn_ClearTablesFK`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ClearTablesFK`()
BEGIN

  ##  Relying on FOREIGN KEYs is very bad idea.
  ##  Deleting from "leaves" is much faser.
  ##  Compare with nn_ClearTables().

  TRUNCATE lib_logg;
  TRUNCATE nn_networks;
  #TRUNCATE nn_net_neurons;
  #TRUNCATE nn_net_synapses;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ComputeNet`
--

DROP PROCEDURE IF EXISTS `nn_ComputeNet`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ComputeNet`(
  iNetId INTEGER, sadInput VARCHAR(255), bStoreInternalValues BOOLEAN)
body: BEGIN

  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet;
  CALL LoggP('nn_ComputeNet', F3('nn_ComputeNet( {1}, {2}, {3} );.', NS(iNetId), NSQ(sadInput), NSB(bStoreInternalValues) ));
  IF iNetId IS NULL OR sadInput IS NULL THEN LEAVE body; END IF;

  SET @bStoreInternalValues = IFNULL(bStoreInternalValues, FALSE);


  ##  Get a table with input values as rows.
  # pos, val
  CALL lib_Explode(',', sadInput);
  #SELECT * FROM lib_Explode; LEAVE body;            -- DEBUG

  # pos, id_neuron
  CALL nn_GetInputNeuronIDs( iNetId );
  #SELECT * FROM nn_GetInputNeuronIDs; LEAVE body;   -- DEBUG

  SET @iCntInputNeurons = (SELECT COUNT(*) FROM nn_GetInputNeuronIDs);
  SET @iCntInputValues  = (SELECT COUNT(*) FROM lib_Explode);
  IF @iCntInputNeurons != @iCntInputValues THEN
    CALL Logg_error(F2('Number of input neurons {1} and number of input values {2} differs.', @iCntInputNeurons, @iCntInputValues ));
    LEAVE body;
  END IF;


  ##  Create the work table and fill it with input neurons' IDs.
  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet_new_layer;
  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet_prev_layer;
  CREATE TEMPORARY TABLE nn_ComputeNet_prev_layer  (
    id_neuron INT UNSIGNED NOT NULL
    ,PRIMARY KEY USING HASH (id_neuron)
    ,val DOUBLE NOT NULL
  ) ENGINE = Memory  ROW_FORMAT = FIXED
  SELECT id_neuron, val
      FROM lib_Explode AS ex
      LEFT JOIN nn_GetInputNeuronIDs AS inp USING(pos);

  CALL LoggP('nn_ComputeNet', CONCAT('Input: ', (
    SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',val) SEPARATOR '; ') FROM nn_ComputeNet_prev_layer
  )));


  ##  If we were asked to store internal neurons' output values, do so.
  IF @bStoreInternalValues THEN
    DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet_InternalValues;
    CREATE TEMPORARY TABLE nn_ComputeNet_InternalValues (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
      SELECT * FROM nn_ComputeNet_prev_layer;
  END IF;

  -- CALL LoggP('nn_ComputeNet', CONCAT( 'The net has ', NS((SELECT COUNT(*) FROM nn_ComputeNet_prev_layer)),' input neurons.' ));
  -- SELECT * FROM nn_ComputeNet_prev_layer; LEAVE body;  -- DEBUG
  -- DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet_new_layer;

  -- SELECT COUNT(*) INTO @iInputNeurons FROM nn_ComputeNet_prev_layer;
  SET @iInputNeurons = (SELECT COUNT(*) FROM nn_ComputeNet_prev_layer);
  SET @iRound = 1;

  compute_layers:
  LOOP

    SET @iRound = @iRound +1;
    IF @iRound > 30 THEN CALL LoggP_error('nn_ComputeNet','Leaving loop - @iRound > 5'); LEAVE compute_layers; END IF; -- DEBUG
    CALL LoggP('nn_ComputeNet', F1('Computing next layer. %s neurons on input.', @iInputNeurons));  -- DEBUG

    ##  Compute the values for the next layer.
    CREATE TEMPORARY TABLE nn_ComputeNet_new_layer  (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
    SELECT neu.id_neuron,
      #SIGMOID(SUM(inp.val * syn.weight)+neu.bias) AS val -- Too slow :-/
      1 / (1 + EXP(- (SUM(inp.val * syn.weight)+neu.bias) ) ) AS val
      FROM nn_ComputeNet_prev_layer AS inp
      LEFT JOIN nn_net_synapses AS syn ON inp.id_neuron = syn.id_from
      LEFT JOIN nn_net_neurons  AS neu ON syn.id_to = neu.id_neuron
      WHERE neu.id_neuron IS NOT NULL
      GROUP BY(neu.id_neuron);
    CALL LoggP('nn_ComputeNet', 'Computed.');  -- DEBUG

    ##  Update the number of input neurons for next layer.
    SELECT COUNT(*) INTO @iInputNeurons FROM nn_ComputeNet_new_layer;
    ##  If no further neurons are left, quit the loop.
    IF 0 = @iInputNeurons THEN CALL LoggP('nn_ComputeNet','Leaving'); LEAVE compute_layers; END IF;

    ## -- DEBUG log --
    /*CALL LoggP('nn_ComputeNet', CONCAT('Neurons input: ',
      (SELECT GROUP_CONCAT(str SEPARATOR ' / ') FROM
      (SELECT CONCAT('[',NS(neu.id_neuron),']: ',
          GROUP_CONCAT( F3('({1}): {2}*{3} ',inp.id_neuron,ROUND(inp.val,4), ROUND(syn.weight,4)) SEPARATOR ' + '),
          ' + ', neu.bias
        ) AS str, neu.id_neuron
        FROM nn_ComputeNet_prev_layer AS inp
        LEFT JOIN nn_net_synapses AS syn ON inp.id_neuron = syn.id_from
        LEFT JOIN nn_net_neurons  AS neu ON syn.id_to = neu.id_neuron
        WHERE neu.id_neuron IS NOT NULL
      GROUP BY(neu.id_neuron)
      ) AS neurony # SELECT
      ) # SELECT
    ));/**/
    CALL LoggP('nn_ComputeNet', CONCAT('Output: ', (
      SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',ROUND(val,4)) SEPARATOR '; ') FROM nn_ComputeNet_new_layer
    )));


    ##  Switch  ##
    DROP TEMPORARY TABLE IF EXISTS nn_ComputeNet_prev_layer;
    ALTER TABLE nn_ComputeNet_new_layer RENAME TO nn_ComputeNet_prev_layer;

    ##  If we were asked to store internal neurons' output values, do so.
    ##  This can be after the Switch - we do NOT want to duplicate output values.
    IF @bStoreInternalValues THEN
      INSERT INTO nn_ComputeNet_InternalValues SELECT * FROM nn_ComputeNet_prev_layer;
    END IF;

  END LOOP;

  ALTER TABLE nn_ComputeNet_prev_layer RENAME TO nn_ComputeNet;

  #CALL LoggLeave('nn_ComputeNet');


  #SELECT * FROM nn_ComputeNet;  -- DEBUG

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ComputeNets`
--

DROP PROCEDURE IF EXISTS `nn_ComputeNets`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ComputeNets`(
  sadInput VARCHAR(255), bStoreInternalValues BOOLEAN )
body: BEGIN

  #######   nn_ComputeNets   ##############
  ##
  ##  Procedure expects a table 'nn_ComputeNets_NetIDs(id_net INT PRIMARY KEY)',
  ##  which holds the IDs of the networks to compute.
  ##
  ##  Then it looks for a table 'nn_ComputeNets_InputIDs( pos INT, id_neuron INT )',
  ##  which holds the positions and IDs of input neurons of that networks.
  ##

  CALL LoggP('nn_ComputeNets', F2('nn_ComputeNets( {1}, {2} );.', NSQ(sadInput), NSB(bStoreInternalValues) ));

  SET @bStoreInternalValues = IFNULL(bStoreInternalValues, FALSE);


  ##  Check the inputs.
  IF sadInput IS NULL THEN LEAVE body; END IF;

  ##  Get a table with input values as rows.
  # pos, val
  CALL lib_Explode(',', sadInput);
  #SELECT * FROM lib_Explode; LEAVE body;            -- DEBUG




  ####   If we do not have a table with input neurons' IDs yet, create it now.
  ##
  CALL lib_TemporaryTableHasColumns('nn_ComputeNets_InputIDs', 'id_neuron', @bHas);
  IF NOT @bHas THEN
    CALL LoggP('nn_ComputeNets','Table nn_ComputeNets_InputIDs not found, creating...');

    ##  Check the existence of the input table with Network IDs.
    CALL lib_TemporaryTableHasColumns('nn_ComputeNets_NetIDs', 'id_net', @bHas);
    IF NOT @bHas THEN CALL LoggP_error('nn_ComputeNets',
      'Input table nn_ComputeNets_NetIDs must be (id_net INT UNSIGNED PRIMARY KEY)'); END IF;

    ##  Acquire the input neuron IDs from the Network IDs.
    DROP TABLE IF EXISTS nn_GetInputNeuronIDsMultiNet_NetIDs;
    ALTER TABLE nn_ComputeNets_NetIDs RENAME TO nn_GetInputNeuronIDsMultiNet_NetIDs;   # Push...
    # pos, id_neuron
    CALL nn_GetInputNeuronIDsMultiNet();
    #SELECT * FROM nn_GetInputNeuronIDs; LEAVE body;   -- DEBUG
    ALTER TABLE nn_GetInputNeuronIDsMultiNet RENAME TO nn_ComputeNets_InputIDs;        # The name we will use.
    ALTER TABLE nn_GetInputNeuronIDsMultiNet_NetIDs RENAME TO nn_ComputeNets_NetIDs;   # Pop the net IDs table back.

    ##  All positions should have equal number of neurons.
    SELECT COUNT(*) INTO @iShouldBeOne FROM
      ##  How many neurons are attached to some position. Should be the same for all.
      (SELECT COUNT(*) AS cnt FROM nn_ComputeNets_InputIDs GROUP BY pos) AS pos_count
    GROUP BY cnt;
    IF @iShouldBeOne != 1 THEN
      CALL LoggP_error('nn_ComputeNets', 'Inequal number of input neurons for the given networks.');
      LEAVE body;
    END IF;

  END IF;  ##  Done creating table with input neurons' IDs.



  SET @iCntInputNeurons = (SELECT COUNT( DISTINCT pos) FROM nn_ComputeNets_InputIDs);
  SET @iCntInputValues  = (SELECT COUNT(*) FROM lib_Explode);
  IF @iCntInputNeurons != @iCntInputValues THEN
    CALL Logg_error(F2('Number of input neurons {1} and number of input values {2} differs.',
      @iCntInputNeurons, @iCntInputValues ));
    LEAVE body;
  END IF;



  ##  Create the work table and fill it with input neurons' IDs.
  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets_new_layer;
  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets_prev_layer;
  CREATE TEMPORARY TABLE nn_ComputeNets_prev_layer  (
    id_neuron INT UNSIGNED NOT NULL
    ,PRIMARY KEY USING HASH (id_neuron)
    ,val DOUBLE NOT NULL
  ) ENGINE = Memory  ROW_FORMAT = FIXED
  SELECT id_neuron, ex.val
      FROM nn_ComputeNets_InputIDs AS inp
      LEFT JOIN lib_Explode AS ex USING(pos);

  CALL LoggP('nn_ComputeNets', CONCAT('Input: ', (
    SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',val) SEPARATOR '; ') FROM nn_ComputeNets_prev_layer
  )));


  ##  If we were asked to store internal neurons' output values, do so.
  IF @bStoreInternalValues THEN
    DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets_InternalValues;
    CREATE TEMPORARY TABLE nn_ComputeNets_InternalValues (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
      SELECT * FROM nn_ComputeNets_prev_layer;
  END IF;

  -- CALL LoggP('nn_ComputeNets', CONCAT( 'The net has ', NS((SELECT COUNT(*) FROM nn_ComputeNets_prev_layer)),' input neurons.' ));
  -- SELECT * FROM nn_ComputeNets_prev_layer; LEAVE body;  -- DEBUG
  -- DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets_new_layer;

  -- SELECT COUNT(*) INTO @iInputNeurons FROM nn_ComputeNets_prev_layer;
  SET @iInputNeurons = (SELECT COUNT(*) FROM nn_ComputeNets_prev_layer);
  SET @iRound = 1;

  compute_layers:
  LOOP

    SET @iRound = @iRound +1;
    IF @iRound > 5 THEN LEAVE compute_layers; END IF; -- DEBUG
    #CALL LoggP('nn_ComputeNets', F1('Computing next layer. %s neurons on input.', @iInputNeurons));  -- DEBUG

    ##  Compute the values for the next layer.
    CREATE TEMPORARY TABLE nn_ComputeNets_new_layer  (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
    SELECT neu.id_neuron,
      #SIGMOID(SUM(inp.val * syn.weight)+neu.bias) AS val -- Too slow :-/
      1 / (1 + EXP(- (SUM(inp.val * syn.weight)+neu.bias) ) ) AS val
      FROM nn_ComputeNets_prev_layer AS inp
      LEFT JOIN nn_net_synapses AS syn ON inp.id_neuron = syn.id_from
      LEFT JOIN nn_net_neurons  AS neu ON syn.id_to = neu.id_neuron
      WHERE neu.id_neuron IS NOT NULL
      GROUP BY(neu.id_neuron);
    #CALL LoggP('nn_ComputeNets', 'Computed.');  -- DEBUG

    ##  Update the number of input neurons for next layer.
    SELECT COUNT(*) INTO @iInputNeurons FROM nn_ComputeNets_new_layer;
    ##  If no further neurons are left, quit the loop.
    IF 0 = @iInputNeurons THEN LEAVE compute_layers; END IF;

    ##  Switch  ##
    DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets_prev_layer;
    ALTER TABLE nn_ComputeNets_new_layer RENAME TO nn_ComputeNets_prev_layer;

    ##  If we were asked to store internal neurons' output values, do so.
    ##  This can be after the Switch - we do NOT want to duplicate output values.
    IF @bStoreInternalValues THEN
      INSERT INTO nn_ComputeNets_InternalValues SELECT * FROM nn_ComputeNets_prev_layer;
    END IF;

  END LOOP;

  ##  Return the result...
  DROP TEMPORARY TABLE IF EXISTS nn_ComputeNets;
  ALTER TABLE nn_ComputeNets_prev_layer RENAME TO nn_ComputeNets;

  #CALL LoggLeave('nn_ComputeNets');


  #SELECT * FROM nn_ComputeNets;  -- DEBUG

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_CorrectWeights`
--

DROP PROCEDURE IF EXISTS `nn_CorrectWeights`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_CorrectWeights`(
  id_net INTEGER, sadValuesWanted VARCHAR(255), dLearn DOUBLE, OUT out_dErrorSum DOUBLE
)
BEGIN body: BEGIN

  CALL LoggP('nn_CorrectWeights', F2('nn_CorrectWeights( {1}, {2} )', NS(id_net), NSQ(sadValuesWanted) ));
  IF id_net IS NULL OR sadValuesWanted IS NULL THEN LEAVE body; END IF;




  ###  Check the output neurons table for existence and structure.  ###
  CALL lib_TemporaryTableHasColumns('nn_CorrectWeights', 'id_neuron,val', @iInputExists);
  IF NOT @iInputExists THEN
    CALL Logg_error('nn_CorrectWeights input table must be: (id_neuron INTEGER UNSIGNED NOT NULL, val DOUBLE NOT NULL).'); LEAVE body;
  END IF;
  #CALL LoggP('nn_CorrectWeights', 'nn_CorrectWeights input table OK');

  CALL lib_TemporaryTableHasColumns('nn_CorrectWeights_InternalValues', 'id_neuron,val', @iInputExists);
  IF NOT @iInputExists THEN
    CALL Logg_error('... nn_CorrectWeights_InternalValues input table must be: (id_neuron INTEGER UNSIGNED NOT NULL, val DOUBLE NOT NULL).'); LEAVE body;
  END IF;
  #CALL LoggP('nn_CorrectWeights', '... nn_CorrectWeights_InternalValues input table OK');




  ###  Create the list of wanted neuron network output values  from the string param.
  ###  Result: TEMPORARY TABLE nn_CorrectWeights_Wanted( id_neuron INT PK,  val DOUBLE ).
  CALL lib_TemporaryTableHasColumns('nn_CorrectWeights_Wanted', 'id_neuron, val', @bHas);
  IF NOT @bHas THEN

    CALL lib_Explode(',', sadValuesWanted);
    DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_Wanted;
    ALTER TABLE lib_Explode RENAME TO nn_CorrectWeights_Wanted;     # TODO: Feature request - RENAME OVERWRITE TO...
    #CALL LoggP('nn_CorrectWeights', '... exploded the wanted values');



    ###  Get the output neurons and check if their count also matches.
    CALL lib_TemporaryTableHasColumns('nn_GetOutputNeuronIDs', 'pos, id_neuron', @bHas);
    IF NOT @bHas THEN
      CALL nn_GetOutputNeuronIDs( id_net );
    END IF;


    ###  Mint wanted values' positions into neurons ID.
	  #CALL LoggP('nn_CorrectWeights', '... converting wanted values\' position into output neuron\'s ID.');

    /* This way is unsafe (? - PK collision), but fast. But DROP PRIMARY KEY is available only for MyISAM.
	  ALTER TABLE nn_CorrectWeights_Wanted DROP PRIMARY KEY;   -- Does this prevent PK collision? I think so.
	  UPDATE nn_CorrectWeights_Wanted AS want LEFT JOIN nn_GetOutputNeuronIDs AS out_neu USING(pos)
	    SET want.pos = out_neu.id_neuron;
	  ALTER TABLE nn_CorrectWeights_Wanted MODIFY COLUMN pos id_neuron INT UNSIGNED NOT NULL PRIMARY KEY; */

    #   This way is safe.
	  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_Wanted_pos;
	  ALTER TABLE nn_CorrectWeights_Wanted RENAME TO nn_CorrectWeights_Wanted_pos;
	  CREATE TEMPORARY TABLE nn_CorrectWeights_Wanted (
	    id_neuron INT UNSIGNED NOT NULL PRIMARY KEY,
	    val       DOUBLE NOT NULL
	  ) ENGINE = Memory
	  SELECT out_neu.id_neuron, want.val
	    FROM nn_CorrectWeights_Wanted_pos AS want
	    LEFT JOIN nn_GetOutputNeuronIDs AS out_neu USING(pos);
	  DROP TEMPORARY TABLE nn_CorrectWeights_Wanted_pos;

	  CALL LoggP('nn_CorrectWeights', CONCAT('Wanted values: ', (
	    SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',val) SEPARATOR '; ') FROM nn_CorrectWeights_Wanted
	  )));

  END IF;




  ###  Check if the counts of wanted values and actual output values are equal.
  SELECT COUNT(*) INTO @iCntWanted FROM nn_CorrectWeights_Wanted;
  SELECT COUNT(*) INTO @iCntComputed FROM nn_CorrectWeights;
  IF @iCntWanted != @iCntComputed THEN
    CALL LoggP_error('nn_CorrectWeights', 'Counts of wanted and computed values differs.'); LEAVE body;
  END IF;
  #CALL LoggP('nn_CorrectWeights', '... counts OK');

  SELECT COUNT(*) INTO @iCntOutputNeurons FROM nn_GetOutputNeuronIDs;
  IF @iCntWanted != @iCntOutputNeurons THEN
    CALL LoggP_error('nn_CorrectWeights', 'Counts of wanted values and output neurons differs.'); LEAVE body;
  END IF;
  #CALL LoggP('nn_CorrectWeights', '... count in iCntOutputNeurons OK');



  ###  Rename the input table to nn_CorrectWeights_Computed.
  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_Computed;
  ALTER TABLE nn_CorrectWeights RENAME TO nn_CorrectWeights_Computed;







  #####################################################################
  ###  Enough of checking; Now the weights correction really begins.
  /*
     We have:
      nn_GetOutputNeuronIDs       (pos, id_neuron)
      nn_CorrectWeights_Computed  (id_neuron, val)
      nn_CorrectWeights_Wanted    (id_neuron, val)
      nn_CorrectWeights_InternalValues (id_neuron, val)
  */



  ###  Create the table for data of the "current layer" - id_neuron and difference.
  #CALL LoggP('nn_CorrectWeights', 'Creating table nn_CorrectWeights_cur_layer.');
  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_prev_layer;
  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_cur_layer;
  CREATE TEMPORARY TABLE nn_CorrectWeights_cur_layer (
    id_neuron INTEGER UNSIGNED NOT NULL PRIMARY KEY
    ,error DOUBLE NOT NULL DEFAULT 0.0
  ) ENGINE Memory   ROW_FORMAT = FIXED
  SELECT comp.id_neuron
    ,(want.val - comp.val)   *   comp.val * (1-comp.val) AS error
    FROM nn_CorrectWeights_Computed AS comp
    LEFT JOIN nn_CorrectWeights_Wanted AS want USING(id_neuron);

  -- SELECT * FROM nn_CorrectWeights_cur_layer; LEAVE body; -- DEBUG

  ###  Total error of the output layer.  Not used yet - later for teaching cycle control.
  SELECT SUM(ABS(error)) INTO out_dErrorSum FROM nn_CorrectWeights_cur_layer;

   -- DEBUG:
  #CREATE TABLE IF NOT EXISTS foo (id_neuron INT, error DOUBLE);
  #INSERT INTO foo SELECT 11111, 0.666666666666;
  #INSERT INTO foo SELECT * FROM nn_CorrectWeights_cur_layer;

  SET @iLayers = 0;
  layers: LOOP

    SET @iLayers = @iLayers + 1;
    CALL LoggP('nn_CorrectWeights', F2('Correcting {1} th layer. IDs: {2}', @iLayers,
      NS(  (SELECT GROUP_CONCAT( CONCAT(id_neuron,' / err: ', ROUND(error,5) ) SEPARATOR ',  ')
            FROM nn_CorrectWeights_cur_layer AS cur)  )));




    ###  Create table for previous layer.
	  #    Computes their diff and runs their output thru current neuron's function derivation.
	  CREATE TEMPORARY TABLE nn_CorrectWeights_prev_layer (
	    id_neuron INTEGER UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
	    ,error     DOUBLE NOT NULL
	  ) ENGINE = Memory  ROW_FORMAT = FIXED
	  SELECT upstream.id_neuron,
        SUM( cur.error * syn.weight )  *  upstream.val * (1-upstream.val)   AS error
	    FROM nn_CorrectWeights_cur_layer           AS cur
	    LEFT JOIN nn_net_synapses                  AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_CorrectWeights_InternalValues AS upstream  ON syn.id_from = upstream.id_neuron
      WHERE upstream.id_neuron != 0  #IS NOT NULL
	  GROUP BY upstream.id_neuron;

    -- ##  ROW_COUNT() always returns -1. Is it a BUG??
    -- CALL Logg(CONCAT('RC: ',ROW_COUNT()));

    ###  If there are no more upstream neurons, quit the loop.
    IF 0 = (SELECT COUNT(*) FROM nn_CorrectWeights_prev_layer) THEN LEAVE layers; END IF;
    IF @iLayers > 20 THEN CALL Logg('bye >'); LEAVE layers;  END IF; -- DEBUG - prevent infinite loop.


    CALL LoggP('nn_CorrectWeights',
      (SELECT GROUP_CONCAT( F6('{1}(err:{2}) --(w:{3})--> {4}(val:{5}) => delta:{6}',
              NS(id_to), ROUND(cur.error,3),    NS(ROUND(syn.weight,3)),   NS(id_from),  NS(ROUND(iv.val,3)),
              NS(ROUND(dLearn * cur.error * iv.val, 3)) ) SEPARATOR ' ;  ')
            FROM nn_CorrectWeights_cur_layer       AS cur
	          LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	          LEFT JOIN nn_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
      )
    );




	  ###  Update the BIAS of the neurons of the current layer.
	  UPDATE nn_CorrectWeights_cur_layer AS cur
	    LEFT JOIN nn_net_neurons AS neu USING(id_neuron)
	    SET neu.bias = neu.bias + dLearn * cur.error;
    CALL LoggP('nn_CorrectWeights', F1('Updated %s biases.', ROW_COUNT())); -- DEBUG

    /*
    SELECT neu.bias, dLearn, cur.diff, (0.19661193324148), neu.bias + dLearn * cur.diff * (0.19661193324148)
      FROM nn_CorrectWeights_cur_layer AS cur LEFT JOIN nn_net_neurons AS neu USING(id_neuron);
    LEAVE body;
    /**/




    ###  Update the WEIGHTS of synapses to previous layer's neurons
	  UPDATE nn_CorrectWeights_cur_layer       AS cur
	    LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
    SET syn.weight = syn.weight + dLearn * cur.error * iv.val;

    CALL LoggP('nn_CorrectWeights', F1('Updated %s weights.', ROW_COUNT())); -- DEBUG
	  /*SELECT syn.weight, dLearn, cur.error, iv.val, syn.weight + dLearn * cur.error * iv.val
      FROM nn_CorrectWeights_cur_layer       AS cur
	    LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
    -- LEAVE body;
    /**/






	  ###  Switch  ###
	  DROP TEMPORARY TABLE nn_CorrectWeights_cur_layer;
	  ALTER TABLE nn_CorrectWeights_prev_layer RENAME TO nn_CorrectWeights_cur_layer;

    #INSERT INTO foo SELECT 111 AS id_neuron, 0.666 AS diff;                  -- DEBUG
    #INSERT INTO foo SELECT id_neuron, diff FROM nn_CorrectWeights_cur_layer; -- DEBUG


  END LOOP layers;

  #CALL LoggP('nn_CorrectWeights', 'All layers done, all weights updated.');

END body;
  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_Wanted;
  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights_Computed;
  #DROP TEMPORARY TABLE IF EXISTS nn_GetOutputNeuronIDs;
  # CALL LoggLeave('nn_CorrectWeights');
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_CreatePerceptron`
--

DROP PROCEDURE IF EXISTS `nn_CreatePerceptron`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_CreatePerceptron`(
  sLayers VARCHAR(255), sName VARCHAR(255),
  dWeightsRange DOUBLE, dBiasRange DOUBLE,
  out_iNetId INT UNSIGNED)
BEGIN

  /*
   *  Creates a network with perceptron architecture.
   *  INSERTs into nn_network, nn_net_neurons and nn_net_synapses.
   *  @returns: The ID of the network created  into  out_iNetId
   *      -- The ID of the network created can be retrieved with LAST_INSERT_ID().
   */

  ##  Log
  CALL Logg(CONCAT( 'nn_CreatePerceptron( sLayers: ', NSQ(sLayers), ', sName: ', NSQ(sName), ' )' ));

  ##  Generate the perceptron to temp table.
  CALL nn_GeneratePerceptron(sLayers, dWeightsRange, dBiasRange);


  ##  Create the new network record and get it's new ID.
  INSERT INTO nn_networks SET name = sName, architecture = 'perceptron', definition = sLayers,
   inputs = sLayers, outputs = SUBSTRING_INDEX(sLayers, ',', -1);
  SELECT LAST_INSERT_ID() INTO out_iNetId;

  ##  Get last neuron's ID.
  SELECT IFNULL(MAX(id_neuron)+1,0) INTO @iLastNeuronId FROM nn_net_neurons;

  CALL Logg(CONCAT( 'Created network #',out_iNetId,' and neurons with ID #',@iLastNeuronId,' and up.' ));


  INSERT INTO nn_net_neurons
    SELECT out_iNetId AS id_net, id_neuron + @iLastNeuronId, bias
      FROM nn_GeneratePerceptron_neurons;
  CALL Logg(CONCAT( 'Created neurons for nn #',out_iNetId,'' ));

    /*SELECT IF( 0 = id_from, NULL, CAST( id_from + @iLastNeuronId AS UNSIGNED ) ) AS id_from,
           IF( 0 = id_to,   NULL, CAST( id_to   + @iLastNeuronId AS UNSIGNED ) ) AS id_to,
           weight
      FROM nn_GeneratePerceptron_synapses;*/

  INSERT INTO nn_net_synapses
    SELECT IF( 0 = id_from, NULL, CAST( id_from + @iLastNeuronId AS UNSIGNED ) ) AS id_from,
           IF( 0 = id_to,   NULL, CAST( id_to   + @iLastNeuronId AS UNSIGNED ) ) AS id_to,
           weight
      FROM nn_GeneratePerceptron_synapses;
  CALL Logg(CONCAT( 'Created synapses for nn #',out_iNetId,'' ));


  -- RETURN out_iNetId;
  -- SELECT LAST_INSERT_ID( out_iNetId ) INTO @dev_null;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_GeneratePerceptron`
--

DROP PROCEDURE IF EXISTS `nn_GeneratePerceptron`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_GeneratePerceptron`(
  sLayers VARCHAR(255), dWeightsRange DOUBLE, dBiasRange DOUBLE
)
body: BEGIN

  ##  Push old auto-increment settings and set to 1,1.
  SET @oldInc = @@session.auto_increment_increment, @oldOff = @@session.auto_increment_offset;
  SET @@session.auto_increment_increment = 1, @@session.auto_increment_offset = 1;


  SET @sLayers = sLayers;

  CALL Logg(CONCAT('nn_GeneratePerceptron( ', @sLayers, ' )'));

  ##  Create tables for the result. ##
  DROP TEMPORARY TABLE IF EXISTS nn_GeneratePerceptron_neurons;
  DROP TEMPORARY TABLE IF EXISTS nn_GeneratePerceptron_synapses;

  CREATE TEMPORARY TABLE nn_GeneratePerceptron_neurons(
    `id_neuron` int unsigned NOT NULL auto_increment,
    `bias` double NOT NULL
    , PRIMARY KEY  (`id_neuron`)
  ) ENGINE=Memory COMMENT='Neural net neurons';

  CREATE TEMPORARY TABLE nn_GeneratePerceptron_synapses(
    `id_from` int unsigned,
    `id_to` int unsigned,
    `weight` double NOT NULL,
    UNIQUE KEY  (`id_from`,`id_to`)
  ) ENGINE=Memory COMMENT='Connections between neurons';


  DROP TEMPORARY TABLE IF EXISTS nn_GeneratePerceptron_tmp;
  CREATE TEMPORARY TABLE nn_GeneratePerceptron_tmp(
    `id_neuron` int unsigned NOT NULL auto_increment,
    `bias` double NOT NULL,
    PRIMARY KEY  (`id_neuron`)
  ) ENGINE=Memory COMMENT='New layer neurons';

  DROP TEMPORARY TABLE IF EXISTS nn_GeneratePerceptron_prev_layer;
  CREATE TEMPORARY TABLE nn_GeneratePerceptron_prev_layer(
    `id_neuron` int unsigned #NOT NULL
    #, PRIMARY KEY  (`id_neuron`)
    , UNIQUE KEY  (`id_neuron`)
  ) ENGINE=Memory COMMENT='IDs of previous layer neurons.';



  ##  Create pseudo-synapses for the input layer.
  SET @iNeurons = CAST( @sLayers AS UNSIGNED );
  CALL lib_GenerateSequence(1, @iNeurons, 1);
  /*INSERT INTO nn_GeneratePerceptron_synapses
    SELECT 0 AS id_from, i AS id_to  FROM lib_GenerateSequence;
  /**/
  ##  Instead, create virtual layer, to which the WHILE loop will create synapses.
  INSERT INTO nn_GeneratePerceptron_prev_layer
    -- SELECT /*-i*/ NULL AS id_neuron  FROM lib_GenerateSequence;
   VALUES (NULL); -- Only one pseudo-synapse per input neuron.
  /**/


  SET @iLayer = 0;

  create_layers:
  WHILE @sLayers != '' DO

    # Get the next layer's volume
    SET @sHead = SUBSTRING_INDEX(@sLayers, ',', 1);
    #CALL Logg(CONCAT( 'Head: ', @sHead ));
    SET @sLayers = SUBSTRING( @sLayers, LENGTH(@sHead)+2 );  -- +2 - SUBSTRING() is 1-based.
    #CALL Logg(CONCAT( 'Tail: ', @sLayers ));

    SET @iNeurons = CAST( @sHead AS UNSIGNED );
    IF NOT @iNeurons THEN ITERATE create_layers; END IF;
    SET @iLayer = @iLayer + 1;

    ##  Create the layer. ##

    CALL Logg(CONCAT('Generating layer ', @iLayer, ' with ', @iNeurons, ' neurons.'));

    # Last inserted id.
    SELECT IFNULL(MAX(id_neuron),0) INTO @iLastId FROM nn_GeneratePerceptron_neurons;
    # Create new neurons IDs.
    CALL lib_GenerateSequence(@iLastId+1, @iLastId + @iNeurons, 1);
    # Insert neurons with corresponding IDs.
    INSERT INTO nn_GeneratePerceptron_neurons
      SELECT NULL AS id_neuron,
        -- 0.0 AS bias
        -- (RAND()-0.5)*1.6 AS bias  # <-0.8, 0.8)
        (RAND()-0.5)*2*dBiasRange AS bias
        FROM lib_GenerateSequence;
    CALL Logg('...neurons generated.');


/*      SELECT * FROM nn_GeneratePerceptron_prev_layer;
      LEAVE body;
      SELECT
        nn_GeneratePerceptron_prev_layer.id_neuron AS id_from,
        lib_GenerateSequence.i AS id_to,
        RAND() AS weight
      FROM nn_GeneratePerceptron_prev_layer CROSS JOIN lib_GenerateSequence;
      LEAVE body;*/

    # Connect this new layer with previous layer.
    INSERT INTO nn_GeneratePerceptron_synapses
      SELECT
        nn_GeneratePerceptron_prev_layer.id_neuron AS id_from,
        lib_GenerateSequence.i AS id_to,
        -- 0.0            AS weight     -- some FIXED value?
        -- (RAND()-0.5)*0.1 AS weight  -- or some SMALL RAND value <-0.05, 0.05)?
        -- (RAND()-0.5)/2    AS weight -- or some normal RAND value <-0.25, 0.25)?
        (RAND()-0.5)*2*dWeightsRange AS weight
      FROM nn_GeneratePerceptron_prev_layer CROSS JOIN lib_GenerateSequence;
    CALL Logg('...synapses generated.');

    # Make this layer the "previous" for next turn
    TRUNCATE nn_GeneratePerceptron_prev_layer;
    INSERT INTO nn_GeneratePerceptron_prev_layer
      SELECT i AS id_neuron FROM lib_GenerateSequence;

    ##  Final Report of this layer creation round.
    SELECT COUNT(*) INTO @iNeuronsTotal FROM nn_GeneratePerceptron_neurons;
    SELECT COUNT(*) INTO @iSynapsesTotal FROM nn_GeneratePerceptron_synapses;
    CALL Logg(CONCAT('Generated layer', NS(@iLayer), '. The net has now ',
                NS(@iNeuronsTotal), ' neurons and ',
                NS(@iSynapsesTotal),' synapses.'));


  END WHILE;


  ##  Create pseudo-synapses for the output layer.
  INSERT INTO nn_GeneratePerceptron_synapses
    SELECT id_neuron AS id_from, NULL AS id_to, 1.0 AS weight   FROM nn_GeneratePerceptron_prev_layer;
  ##  Reset input pseudo-synapses weights.
  UPDATE nn_GeneratePerceptron_synapses SET weight = 1.0 WHERE id_from IS NULL;
  ##  Reset input neurons' biases to zero.
  UPDATE nn_GeneratePerceptron_neurons AS neu
    LEFT JOIN nn_GeneratePerceptron_synapses AS syn ON neu.id_neuron = syn.id_to
    SET bias   = 0.0 WHERE syn.id_from IS NULL;


  ##  Restore original auto-increment settings.
  SET @@session.auto_increment_increment = @oldInc, @@session.auto_increment_offset = @oldOff;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_GetInputNeuronIDs`
--

DROP PROCEDURE IF EXISTS `nn_GetInputNeuronIDs`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_GetInputNeuronIDs`(iNetID INTEGER)
    COMMENT 'Returns tmp.t. (pos, id_neuron) with given net''s input neurons.'
body:
BEGIN

  #CALL LoggP('nn_GetInputNeuronIDs', CONCAT('nn_GetInputNeuronIDs( ',NS(iNetID),' )'));

  DROP TEMPORARY TABLE IF EXISTS nn_GetInputNeuronIDs;
  CREATE TEMPORARY TABLE nn_GetInputNeuronIDs (
    `pos` int unsigned NOT NULL auto_increment,
    `id_neuron` INTEGER UNSIGNED NOT NULL,
    PRIMARY KEY USING HASH (`pos`)
  ) ENGINE=Memory ROW_FORMAT=FIXED COMMENT='Input neuron IDs indexed by position.';

  IF iNetID IS NULL THEN LEAVE body; END IF;

  INSERT INTO nn_GetInputNeuronIDs
  -- SELECT syn.id_to FROM nn_net_synapses AS syn WHERE syn.id_from = 0;
  SELECT NULL AS pos, id_to AS id_neuron
    FROM nn_net_synapses AS syn
    LEFT JOIN nn_net_neurons AS neu ON neu.id_net = iNetID AND syn.id_to = neu.id_neuron
    WHERE id_net = iNetID AND syn.id_from IS NULL
    ORDER BY id_to;

  #SELECT * FROM nn_GetInputNeuronIDs; -- DEBUG

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_GetOutputNeuronIDs`
--

DROP PROCEDURE IF EXISTS `nn_GetOutputNeuronIDs`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_GetOutputNeuronIDs`(iNetID INTEGER)
    COMMENT 'Returns tmp.t. (pos, id_neuron) with given net''s output neurons.'
body:
BEGIN

  CALL LoggP('nn_GetOutputNeuronIDs', CONCAT('nn_GetOutputNeuronIDs( ', NS(iNetID), ' )'));

  DROP TEMPORARY TABLE IF EXISTS nn_GetOutputNeuronIDs;
  CREATE TEMPORARY TABLE nn_GetOutputNeuronIDs (
    `pos` int unsigned NOT NULL auto_increment,
    `id_neuron` INTEGER UNSIGNED NOT NULL,
    PRIMARY KEY USING HASH (`pos`)
  ) ENGINE=Memory ROW_FORMAT=FIXED COMMENT='Output neuron IDs indexed by position.';

  IF iNetID IS NULL THEN LEAVE body; END IF;

  INSERT INTO nn_GetOutputNeuronIDs
  -- SELECT syn.id_to FROM nn_net_synapses AS syn WHERE syn.id_from = 0;
  SELECT NULL AS pos, id_from AS id_neuron
    FROM nn_net_synapses AS syn
    LEFT JOIN nn_net_neurons AS neu ON neu.id_net = iNetID AND syn.id_from = neu.id_neuron
    WHERE id_net = iNetID AND  syn.id_to IS NULL
    ORDER BY id_from;

  #SELECT * FROM nn_GetInputNeuronIDs; -- DEBUG

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_TeachLogic`
--

DROP PROCEDURE IF EXISTS `nn_TeachLogic`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_TeachLogic`(
  iNetID INT UNSIGNED, iRounds INT UNSIGNED, dLearn DOUBLE
)
body: BEGIN

  -- DECLARE dLearn DOUBLE DEFAULT 0.1;
  CALL LoggEnter(F3('nn_TeachLogic( iNetID: {1}, iRounds: {2}, dLearn: {3});', iNetID, iRounds, dLearn));

  #CALL nn_GetOutputNeuronIDs(1);

  rounds: WHILE iRounds > 0 DO
    SET iRounds = iRounds -1;

    # OR AND XOR EQ

    CASE FLOOR(RAND()*4)
      WHEN 0 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,0);');
			  CALL nn_ComputeNet(iNetID, '-1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( -1,1) #{1} computed: {2};', iNetID, (SELECT GROUP_CONCAT(ROUND(val,3)) FROM nn_ComputeNet) ));

        #CALL nn_ComputeError('1, -1', @out_dError);

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1,0,1,0', dLearn);
      WHEN 1 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,1);');
			  CALL nn_ComputeNet(iNetID, '1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1,-1) #{1} computed: {2};', iNetID, (SELECT GROUP_CONCAT(ROUND(val,3)) FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1,0,1,0', dLearn);
      WHEN 2 THEN
		    #CALL LoggP('nn_TeachXOR', 'computing XOR(0,1);');
			  CALL nn_ComputeNet(iNetID, '1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1,1) #{1} computed: {2};', iNetID, (SELECT GROUP_CONCAT(ROUND(val,3)) FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1,1,0,1', dLearn);
      WHEN 3 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(0,0);');
			  CALL nn_ComputeNet(iNetID, '-1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( -1,-1) #{1} computed: {2};', iNetID, (SELECT GROUP_CONCAT(ROUND(val,3)) FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '0,0,0,1', dLearn);
    END CASE;


  END WHILE;

  #CALL LoggLeave('nn_TeachXOR');

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_TeachXOR`
--

DROP PROCEDURE IF EXISTS `nn_TeachXOR`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_TeachXOR`(
  iNetID INT UNSIGNED, iRounds INT UNSIGNED, dLearn DOUBLE
)
body: BEGIN

  -- DECLARE dLearn DOUBLE DEFAULT 0.1;
  CALL LoggEnter(F3('nn_TeachXOR( iNetID: {1}, iRounds: {2}, dLearn: {3});', iNetID, iRounds, dLearn));

  #CALL nn_GetOutputNeuronIDs(1);

  rounds: WHILE iRounds > 0 DO
    SET iRounds = iRounds -1;


    CASE FLOOR(RAND()*4)
      WHEN 0 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,0);');
			  CALL nn_ComputeNet(iNetID, '1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1,-1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1', dLearn, @out_dErrorSum);
      WHEN 1 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,1);');
			  CALL nn_ComputeNet(iNetID, '1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1, 1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '0', dLearn, @out_dErrorSum);
      WHEN 2 THEN
		    #CALL LoggP('nn_TeachXOR', 'computing XOR(0,1);');
			  CALL nn_ComputeNet(iNetID, '-1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR(-1, 1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1', dLearn, @out_dErrorSum);
      WHEN 3 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(0,0);');
			  CALL nn_ComputeNet(iNetID, '-1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR(-1,-1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '0', dLearn, @out_dErrorSum);
    END CASE;

    CALL LoggP('nn_TeachXOR',CONCAT('Error: ', ROUND(@out_dErrorSum,4)));


  END WHILE;

  #CALL LoggLeave('nn_TeachXOR');

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_TeachXOR_Dynamic`
--

DROP PROCEDURE IF EXISTS `nn_TeachXOR_Dynamic`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_TeachXOR_Dynamic`(
  iNetID INT UNSIGNED, dTargetError DOUBLE, iMaxRounds INT UNSIGNED
)
body: BEGIN

  -- DECLARE dLearn DOUBLE DEFAULT 0.1;
  CALL LoggEnter(F3('nn_TeachXOR( iNetID: {1}, dTargetError: {2}, iMaxRounds: {3});', iNetID, dTargetError, iMaxRounds));

  #CALL nn_GetOutputNeuronIDs(1);

  rounds: WHILE iMaxRounds > 0 DO
    SET iMaxRounds = iMaxRounds -1;

    SET @dLearn = 1.0;

    CASE FLOOR(RAND()*4)
      WHEN 0 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,0);');
			  CALL nn_ComputeNet(iNetID, '1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1,-1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

        #CALL nn_ComputeError('1, -1', @out_dError);

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1', @dLearn, @out_dErrorSum);
      WHEN 1 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(1,1);');
			  CALL nn_ComputeNet(iNetID, '1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR( 1, 1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '0', @dLearn, @out_dErrorSum);
      WHEN 2 THEN
		    #CALL LoggP('nn_TeachXOR', 'computing XOR(0,1);');
			  CALL nn_ComputeNet(iNetID, '-1, 1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR(-1, 1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '1', @dLearn, @out_dErrorSum);
      WHEN 3 THEN
			  #CALL LoggP('nn_TeachXOR', 'computing XOR(0,0);');
			  CALL nn_ComputeNet(iNetID, '-1, -1', TRUE);
			  CALL LoggP('nn_TeachXOR', F2('XOR(-1,-1) #{1} computed: {2};', iNetID, (SELECT val FROM nn_ComputeNet) ));

			  DROP TEMPORARY TABLE IF EXISTS nn_CorrectWeights, nn_CorrectWeights_InternalValues;
			  ALTER TABLE nn_ComputeNet RENAME TO nn_CorrectWeights;
			  ALTER TABLE nn_ComputeNet_InternalValues RENAME TO nn_CorrectWeights_InternalValues;
			  CALL nn_CorrectWeights(iNetID, '0', @dLearn, @out_dErrorSum);
    END CASE;

    SET @dLearn = INTERVAL(@out_dErrorSum,        0.0005,     0.005,    0.1,      0.3,      0.8,      1.0     );
    SET @dLearn =  ELT(@dLearn+1,          0.035,        0.05,     0.1,      0.3,      0.5,      0.7,     1.0 );

    CALL LoggP('nn_TeachXOR',F2(  'Error: {1};   Next dLearn: {2}', ROUND(@out_dErrorSum,4), @dLearn ));
    IF @out_dErrorSum <= dTargetError THEN LEAVE rounds; END IF;


  END WHILE;

  #CALL LoggLeave('nn_TeachXOR');

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ts_ComputeNet`
--

DROP PROCEDURE IF EXISTS `nn_ts_ComputeNet`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ts_ComputeNet`(
  iNetID INTEGER, bStoreInternalValues BOOLEAN)
body: BEGIN

  /*
   *   PROCEDURE nn_ts_ComputeNet( iNetID, bStoreInternalValues )
   *
   *   Computes a network's output value.
   *   Expects the following input tables:
   *
   *   nn_ts_ComputeNet_Input ( id_neuron INT UNSIGNED, val DOUBLE )
   */

  DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet;
  CALL LoggP('nn_ts_ComputeNet', F2('nn_ts_ComputeNet( {1}, {2} );.', NS(iNetID), NSB(bStoreInternalValues) ));
  IF iNetID IS NULL THEN LEAVE body; END IF;

  SET @bStoreInternalValues = IFNULL(bStoreInternalValues, FALSE);


  ##  We already have a table with input values as rows:
  # nn_ts_ComputeNet_Input( id_neuron, val )




  ##  Create the work table and fill it with input neurons' IDs.
  DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_new_layer;
  DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_prev_layer;
  CREATE TEMPORARY TABLE nn_ts_ComputeNet_prev_layer  (
    id_neuron INT UNSIGNED NOT NULL
    ,PRIMARY KEY USING HASH (id_neuron)
    ,val DOUBLE NOT NULL
  ) ENGINE = Memory  ROW_FORMAT = FIXED
  SELECT id_neuron, val
      FROM nn_ts_ComputeNet_Input AS in_vals;

  /*CALL LoggP('nn_ts_ComputeNet', CONCAT('Input: ', (
    SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',val) SEPARATOR '; ') FROM nn_ts_ComputeNet_prev_layer
  )));/**/


  ##  If we were asked to store internal neurons' output values, do so.
  IF @bStoreInternalValues THEN
    DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_InternalValues;
    CREATE TEMPORARY TABLE nn_ts_ComputeNet_InternalValues (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
      SELECT * FROM nn_ts_ComputeNet_prev_layer;
  END IF;

  -- CALL LoggP('nn_ts_ComputeNet', CONCAT( 'The net has ', NS((SELECT COUNT(*) FROM nn_ComputeNet_prev_layer)),' input neurons.' ));
  -- SELECT * FROM nn_ts_ComputeNet_prev_layer; LEAVE body;  -- DEBUG
  -- DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_new_layer;

  -- SELECT COUNT(*) INTO @iInputNeurons FROM nn_ts_ComputeNet_prev_layer;
  SET @iInputNeurons = (SELECT COUNT(*) FROM nn_ts_ComputeNet_prev_layer);
  SET @iRound = 1;

  compute_layers:
  LOOP

    SET @iRound = @iRound +1;
    IF @iRound > 30 THEN CALL LoggP_error('nn_ts_ComputeNet','Leaving loop - @iRound > 5'); LEAVE compute_layers; END IF; -- DEBUG
    #CALL LoggP('nn_ComputeNet', F1('Computing next layer. %s neurons on input.', @iInputNeurons));  -- DEBUG

    ##  Compute the values for the next layer.
    CREATE TEMPORARY TABLE nn_ts_ComputeNet_new_layer  (
      id_neuron INT UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
      ,val DOUBLE NOT NULL
    ) ENGINE = Memory  ROW_FORMAT = FIXED
    SELECT neu.id_neuron,
      #SIGMOID(SUM(inp.val * syn.weight)+neu.bias) AS val -- Too slow :-/
      1 / (1 + EXP(- (SUM(inp.val * syn.weight)+neu.bias) ) ) AS val
      FROM nn_ts_ComputeNet_prev_layer AS inp
      LEFT JOIN nn_net_synapses AS syn ON inp.id_neuron = syn.id_from
      LEFT JOIN nn_net_neurons  AS neu ON syn.id_to = neu.id_neuron
      WHERE neu.id_neuron IS NOT NULL
      GROUP BY(neu.id_neuron);
    #CALL LoggP('nn_ComputeNet', 'Computed.');  -- DEBUG

    ##  Update the number of input neurons for next layer.
    SELECT COUNT(*) INTO @iInputNeurons FROM nn_ts_ComputeNet_new_layer;
    ##  If no further neurons are left, quit the loop.
    IF 0 = @iInputNeurons THEN LEAVE compute_layers; END IF;

    ## -- DEBUG log --
    /*CALL LoggP('nn_ComputeNet', CONCAT('Neurons input: ',
      (SELECT GROUP_CONCAT(str SEPARATOR ' / ') FROM
      (SELECT CONCAT('[',NS(neu.id_neuron),']: ',
          GROUP_CONCAT( F3('({1}): {2}*{3} ',inp.id_neuron,ROUND(inp.val,4), ROUND(syn.weight,4)) SEPARATOR ' + '),
          ' + ', neu.bias
        ) AS str, neu.id_neuron
        FROM nn_ComputeNet_prev_layer AS inp
        LEFT JOIN nn_net_synapses AS syn ON inp.id_neuron = syn.id_from
        LEFT JOIN nn_net_neurons  AS neu ON syn.id_to = neu.id_neuron
        WHERE neu.id_neuron IS NOT NULL
      GROUP BY(neu.id_neuron)
      ) AS neurony # SELECT
      ) # SELECT
    ));/**/
    /*CALL LoggP('nn_ts_ComputeNet', CONCAT('Input: ', (
      SELECT GROUP_CONCAT( CONCAT(id_neuron,': ',val) SEPARATOR '; ') FROM nn_ts_ComputeNet_prev_layer
    )));/**/


    ##  Switch  ##
    DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_prev_layer;
    ALTER TABLE nn_ts_ComputeNet_new_layer RENAME TO nn_ts_ComputeNet_prev_layer;

    ##  If we were asked to store internal neurons' output values, do so.
    ##  This can be after the Switch - we do NOT want to duplicate output values.
    IF @bStoreInternalValues THEN
      INSERT INTO nn_ts_ComputeNet_InternalValues SELECT * FROM nn_ts_ComputeNet_prev_layer;
    END IF;

  END LOOP;

  ##  Return the result under the name of the procedure.
  ALTER TABLE nn_ts_ComputeNet_prev_layer RENAME TO nn_ts_ComputeNet;

  #CALL LoggLeave('nn_ts_ComputeNet');

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ts_CorrectWeights`
--

DROP PROCEDURE IF EXISTS `nn_ts_CorrectWeights`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ts_CorrectWeights`(
  iNetID INTEGER, dLearn DOUBLE, OUT out_dErrorSum DOUBLE
)
BEGIN body: BEGIN

  CALL LoggP('nn_ts_CorrectWeights', F3('nn_ts_CorrectWeights( {1}, {2}, [{3}] )', NS(iNetID), NS(dLearn),
    (SELECT GROUP_CONCAT(CONCAT(id_neuron,': ',val) SEPARATOR ', ') FROM nn_ts_CorrectWeights_Wanted)
  ));
  IF iNetID IS NULL THEN LEAVE body; END IF;

  /*
   *   PROCEDURE  nn_ts_CorrectWeights( id_net, dLearn, out_dErrorSum )
   *
   *   Corrects weights using the backprop algorithm.
   *   Expects the following input tables:
   *
   *   nn_ts_CorrectWeights_Computed ( id_neuron INT UNSIGNED, val DOUBLE ) - computed values on output neurons.
   *   nn_ts_CorrectWeights_InternalValues ( id_neuron INT UNSIGNED, val DOUBLE ) - computed values on hidden neurons.
   *   nn_ts_CorrectWeights_Wanted ( id_neuron INT UNSIGNED, val DOUBLE ) - desired output values.
   *
   */



  ###  Check the output neurons table for existence and structure.  ###
  CALL lib_TemporaryTableHasColumns('nn_ts_CorrectWeights_Computed', 'id_neuron,val', @iInputOK);
  IF NOT @iInputOK THEN
    CALL LoggP_error('nn_ts_CorrectWeights','nn_ts_CorrectWeights_Computed input table must be: (id_neuron INTEGER UNSIGNED, val DOUBLE).'); LEAVE body;
  END IF;

  CALL lib_TemporaryTableHasColumns('nn_ts_CorrectWeights_InternalValues', 'id_neuron,val', @iInputOK);
  IF NOT @iInputOK THEN
    CALL LoggP_error('nn_ts_CorrectWeights','nn_ts_CorrectWeights_InternalValues input table must be: (id_neuron INTEGER UNSIGNED, val DOUBLE).'); LEAVE body;
  END IF;

  CALL lib_TemporaryTableHasColumns('nn_ts_CorrectWeights_Wanted', 'id_neuron,val', @iInputOK);
  IF NOT @iInputOK THEN
    CALL LoggP_error('nn_ts_CorrectWeights','nn_ts_CorrectWeights_Wanted input table must be: (id_neuron INTEGER UNSIGNED, val DOUBLE).'); LEAVE body;
  END IF;




  ###  Check if the counts of wanted values and actual output values are equal.
  SELECT COUNT(*) INTO @iCntWanted FROM nn_ts_CorrectWeights_Wanted;
  SELECT COUNT(*) INTO @iCntComputed FROM nn_ts_CorrectWeights_Computed;
  IF @iCntWanted != @iCntComputed THEN
    CALL LoggP_error('nn_ts_CorrectWeights', 'Counts of wanted and computed values differs.'); LEAVE body;
  END IF;








  #####################################################################
  ###  Enough of checking; Now the weights correction really begins.
  /*
     We have:
      nn_GetOutputNeuronIDs       (pos, id_neuron)
      nn_ts_CorrectWeights_Computed  (id_neuron, val)
      nn_ts_CorrectWeights_Wanted    (id_neuron, val)
      nn_ts_CorrectWeights_InternalValues (id_neuron, val)
  */



  ###  Create the table for data of the "current layer" - id_neuron and difference.
  #CALL LoggP('nn_ts_CorrectWeights', 'Creating table nn_ts_CorrectWeights_cur_layer.');
  DROP TEMPORARY TABLE IF EXISTS nn_ts_CorrectWeights_prev_layer;
  DROP TEMPORARY TABLE IF EXISTS nn_ts_CorrectWeights_cur_layer;
  CREATE TEMPORARY TABLE nn_ts_CorrectWeights_cur_layer (
    id_neuron INTEGER UNSIGNED NOT NULL PRIMARY KEY
    ,error DOUBLE NOT NULL DEFAULT 0.0
  ) ENGINE Memory   ROW_FORMAT = FIXED
  SELECT comp.id_neuron
    ,(want.val - comp.val)   *   comp.val * (1-comp.val) AS error
    FROM nn_ts_CorrectWeights_Computed AS comp
    LEFT JOIN nn_ts_CorrectWeights_Wanted AS want USING(id_neuron);

  -- SELECT * FROM nn_ts_CorrectWeights_cur_layer; LEAVE body; -- DEBUG

  ###  Total error of the output layer.  Not used yet - later for teaching cycle control.
  SELECT SUM(ABS(error)) INTO out_dErrorSum FROM nn_ts_CorrectWeights_cur_layer;

   -- DEBUG:
  #CREATE TABLE IF NOT EXISTS foo (id_neuron INT, error DOUBLE);
  #INSERT INTO foo SELECT 11111, 0.666666666666;
  #INSERT INTO foo SELECT * FROM nn_ts_CorrectWeights_cur_layer;

  SET @iLayers = 0;
  layers: LOOP

    SET @iLayers = @iLayers + 1;
    /*CALL LoggP('nn_ts_CorrectWeights', F2('Correcting {1} th layer. IDs: {2}', @iLayers,
      NS(  (SELECT GROUP_CONCAT( CONCAT(id_neuron,' / err: ', ROUND(error,5) ) SEPARATOR ',  ')
            FROM nn_ts_CorrectWeights_cur_layer AS cur)  )));/**/




    ###  Create table for previous layer.
	  #    Computes their diff and runs their output thru current neuron's function derivation.
	  CREATE TEMPORARY TABLE nn_ts_CorrectWeights_prev_layer (
	    id_neuron INTEGER UNSIGNED NOT NULL
      ,PRIMARY KEY USING HASH (id_neuron)
	    ,error     DOUBLE NOT NULL
	  ) ENGINE = Memory  ROW_FORMAT = FIXED
	  SELECT upstream.id_neuron,
        SUM( cur.error * syn.weight )  *  upstream.val * (1-upstream.val)   AS error
	    FROM nn_ts_CorrectWeights_cur_layer           AS cur
	    LEFT JOIN nn_net_synapses                  AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_ts_CorrectWeights_InternalValues AS upstream  ON syn.id_from = upstream.id_neuron
      WHERE upstream.id_neuron != 0  #IS NOT NULL
	  GROUP BY upstream.id_neuron;

    -- ##  ROW_COUNT() always returns -1. Is it a BUG??
    -- CALL Logg(CONCAT('RC: ',ROW_COUNT()));

    ###  If there are no more upstream neurons, quit the loop.
    IF 0 = (SELECT COUNT(*) FROM nn_ts_CorrectWeights_prev_layer) THEN LEAVE layers; END IF;
    #IF @iLayers > 20 THEN CALL Logg('bye >'); LEAVE layers;  END IF; -- DEBUG - prevent infinite loop.


    /*CALL LoggP('nn_ts_CorrectWeights',
      (SELECT GROUP_CONCAT( F6('{1}(err:{2}) --(w:{3})--> {4}(val:{5}) => delta:{6}',
              NS(id_to), ROUND(cur.error,3),    NS(ROUND(syn.weight,3)),   NS(id_from),  NS(ROUND(iv.val,3)),
              NS(ROUND(dLearn * cur.error * iv.val, 3)) ) SEPARATOR ' ;  ')
            FROM nn_ts_CorrectWeights_cur_layer       AS cur
	          LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	          LEFT JOIN nn_ts_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
      )
    );*/




	  ###  Update the BIAS of the neurons of the current layer.
	  UPDATE nn_ts_CorrectWeights_cur_layer AS cur
	    LEFT JOIN nn_net_neurons AS neu USING(id_neuron)
	    SET neu.bias = neu.bias + dLearn * cur.error;
    #CALL LoggP('nn_ts_CorrectWeights', F1('Updated %s biases.', ROW_COUNT())); -- DEBUG

    /*
    SELECT neu.bias, dLearn, cur.diff, (0.19661193324148), neu.bias + dLearn * cur.diff * (0.19661193324148)
      FROM nn_ts_CorrectWeights_cur_layer AS cur LEFT JOIN nn_net_neurons AS neu USING(id_neuron);
    LEAVE body;
    /**/




    ###  Update the WEIGHTS of synapses to previous layer's neurons
	  UPDATE nn_ts_CorrectWeights_cur_layer       AS cur
	    LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_ts_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
    SET syn.weight = syn.weight + dLearn * cur.error * iv.val;

    #CALL LoggP('nn_ts_CorrectWeights', F1('Updated %s weights.', ROW_COUNT())); -- DEBUG
	  /*SELECT syn.weight, dLearn, cur.error, iv.val, syn.weight + dLearn * cur.error * iv.val
      FROM nn_ts_CorrectWeights_cur_layer       AS cur
	    LEFT JOIN nn_net_synapses              AS syn ON syn.id_to = cur.id_neuron
	    LEFT JOIN nn_ts_CorrectWeights_InternalValues AS iv  ON syn.id_from = iv.id_neuron
    -- LEAVE body;
    /**/






	  ###  Switch  ###
	  DROP TEMPORARY TABLE nn_ts_CorrectWeights_cur_layer;
	  ALTER TABLE nn_ts_CorrectWeights_prev_layer RENAME TO nn_ts_CorrectWeights_cur_layer;

    #INSERT INTO foo SELECT 111 AS id_neuron, 0.666 AS diff;                  -- DEBUG
    #INSERT INTO foo SELECT id_neuron, diff FROM nn_ts_CorrectWeights_cur_layer; -- DEBUG


  END LOOP layers;

  #CALL LoggP('nn_ts_CorrectWeights', 'All layers done, all weights updated.');

END body;
  DROP TEMPORARY TABLE IF EXISTS nn_ts_CorrectWeights_Wanted;
  DROP TEMPORARY TABLE IF EXISTS nn_ts_CorrectWeights_Computed;
  #DROP TEMPORARY TABLE IF EXISTS nn_GetOutputNeuronIDs;
  # CALL LoggLeave('nn_ts_CorrectWeights');
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ts_CreateXORTrainset`
--

DROP PROCEDURE IF EXISTS `nn_ts_CreateXORTrainset`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ts_CreateXORTrainset`()
BEGIN

  /*
   *   This is a debug / usage demonstration procedure.
   *   It creates a training set for XOR.
   */


  ###  Create a training set.
  INSERT INTO nn_trainsets (name, input_count, output_count) VALUES ('XOR train set', 2, 1);
  SELECT LAST_INSERT_ID() INTO @iTrainsetID;


  ###  Then create individual training set cases. XOR has four.

  INSERT INTO nn_trainsets_cases SET id_set = @iTrainsetID;
  SELECT LAST_INSERT_ID() INTO @iCaseID;
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','-1');
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'2','-1');
  INSERT INTO `nn_trainsets_output` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','0');

  INSERT INTO nn_trainsets_cases SET id_set = @iTrainsetID;
  SELECT LAST_INSERT_ID() INTO @iCaseID;
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','-1');
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'2','1');
  INSERT INTO `nn_trainsets_output` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','1');

  INSERT INTO nn_trainsets_cases SET id_set = @iTrainsetID;
  SELECT LAST_INSERT_ID() INTO @iCaseID;
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','1');
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'2','-1');
  INSERT INTO `nn_trainsets_output` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','1');

  INSERT INTO nn_trainsets_cases SET id_set = @iTrainsetID;
  SELECT LAST_INSERT_ID() INTO @iCaseID;
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','1');
  INSERT INTO `nn_trainsets_input` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'2','1');
  INSERT INTO `nn_trainsets_output` (`id_case`,`pos`,`val`) VALUES (@iCaseID,'1','0');

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ts_TeachTrainset`
--

DROP PROCEDURE IF EXISTS `nn_ts_TeachTrainset`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ts_TeachTrainset`(
  iNetID INT UNSIGNED, iTrainsetID INT UNSIGNED, dLearn DOUBLE, dTargetError DOUBLE, iMaxRounds INT UNSIGNED
)
body: BEGIN

  CALL LoggEnter(F4('nn_ts_TeachTrainset( iNetID: {1}, idTSet: {2}, dLearn: {3}, iMaxRounds: {4} );',
     iNetID, iTrainsetID, dLearn, iMaxRounds));

  /*
   *   Teaches the given network using the given trainset.
   *   Expects the following input tables:
   *
   *   `nn_trainsets_input` and `nn_trainsets_output` tables filled with the training data.
   */



  ###  Attach the neuron IDs of the given net to the train set, according to the positions.
  #    Result:  TEMP TABLE nn_ts_TeachTrainset_Output ( id_neuron, val )
  BEGIN

    #  Get the input and output neurons.
    CALL nn_GetInputNeuronIDs( iNetID );
    CALL nn_GetOutputNeuronIDs( iNetID );


    #  Attach neuron IDs to input values.
    DROP TEMPORARY TABLE IF EXISTS nn_ts_TeachTrainset_TSInput;
  	CREATE TEMPORARY TABLE `nn_ts_TeachTrainset_TSInput` (
      id_case   INT UNSIGNED NOT NULL,
  	  id_neuron INT UNSIGNED NOT NULL,
      PRIMARY KEY(id_case, id_neuron),
  	  val       DOUBLE NOT NULL
  	) ENGINE = Memory
  	SELECT ts_inp.id_case, in_neu.id_neuron, ts_inp.val
  	  FROM nn_trainsets_input AS ts_inp
  	  LEFT JOIN nn_GetInputNeuronIDs AS in_neu USING(pos);

    #  Attach neuron IDs to output values.
    DROP TEMPORARY TABLE IF EXISTS nn_ts_TeachTrainset_TSOutput;
  	CREATE TEMPORARY TABLE `nn_ts_TeachTrainset_TSOutput` (
      id_case   INT UNSIGNED NOT NULL,
  	  id_neuron INT UNSIGNED NOT NULL,
      PRIMARY KEY(id_case, id_neuron),
  	  val       DOUBLE NOT NULL
  	) ENGINE = Memory  /*/  LIKE nn_ts_TeachTrainset_TSInput/**/
  	SELECT ts_want.id_case, out_neu.id_neuron, ts_want.val
  	  FROM nn_trainsets_output AS ts_want
  	  LEFT JOIN nn_GetOutputNeuronIDs AS out_neu USING(pos);


    #  Check if counts of input values and input neurons equals.
    SET @iCntInputNeurons = (SELECT COUNT(*) FROM nn_GetInputNeuronIDs);
    SELECT COUNT(*), IF(COUNT(*), GROUP_CONCAT(id_case), '')
      INTO @iNotMatching, @iNotMatchingCases
    FROM (
        SELECT id_case, COUNT(*) AS cnt FROM nn_ts_TeachTrainset_TSInput GROUP BY id_case
        HAVING cnt != @iCntInputNeurons
    ) AS bad_cases;

    IF 0 != @iNotMatching THEN
      CALL LoggP_error(F2('nn_ts_ComputeNet','Training sets [{1}] have bad count of values, should have {2}.',
                          @iNotMatchingCases, @iCntInputNeurons ));
      LEAVE body;
    END IF;

  END;  # End of attaching.




  /*
   *   Now we have:
   *   nn_ts_TeachTrainset_TSInput  ( id_case, id_neuron, val )
   *   nn_ts_TeachTrainset_TSOutput ( id_case, id_neuron, val )
   *
   */




  ###  In each round, cycle through the trainset in random order, each case once.
  SET @iCases = 0;
  rounds: WHILE iMaxRounds > 0 DO
    SET iMaxRounds = iMaxRounds -1;

    ##  Create the order of cases:    order ( pos, id_case )
    DROP TEMPORARY TABLE IF EXISTS nn_ts_TeachTrainset_order;
    SET @a = 0;
    CREATE TEMPORARY TABLE nn_ts_TeachTrainset_order (pos INT UNSIGNED PRIMARY KEY, id_case INT UNSIGNED) ENGINE = Memory
    SELECT @a := @a+1 AS pos, cases.id_case FROM nn_trainsets_cases AS cases WHERE id_set = iTrainsetID ORDER BY RAND();


    cases: LOOP
      SET @iCases = @iCases+1;

      ##  Select the id_case to process now.
      ##  Maybe CURSOR would do this more effectively?  TODO:  Benchmark.
      SELECT id_case INTO @iCaseID FROM nn_ts_TeachTrainset_order ORDER BY pos LIMIT 1;
      DELETE FROM nn_ts_TeachTrainset_order WHERE id_case = @iCaseID;  -- Remove selected case from the queue.
      IF 0 = ROW_COUNT() THEN LEAVE cases; END IF;  -- Quit loop when no cases left.


      CALL LoggP('nn_ts_TeachTrainset',
        F4('Teaching net #{1} for trainset {2} case {3} ({4}th case}', iNetID, iTrainsetID, @iCaseID, @iCases));


      ###  Prepare the input and output. Parametrized views would do this more ellegantly.
      DROP TEMPORARY TABLE IF EXISTS nn_ts_ComputeNet_Input, nn_ts_CorrectWeights_Wanted;
      CREATE TEMPORARY TABLE nn_ts_ComputeNet_Input ENGINE = Memory
        SELECT id_neuron,val FROM nn_ts_TeachTrainset_TSInput WHERE id_case = @iCaseID;
      CREATE TEMPORARY TABLE nn_ts_CorrectWeights_Wanted ENGINE = Memory
        SELECT id_neuron,val FROM nn_ts_TeachTrainset_TSOutput WHERE id_case = @iCaseID;

      ###  Computing  ###
      CALL nn_ts_ComputeNet( iNetID, TRUE );
			CALL LoggP('nn_ts_TeachTrainset', F3(' #{1} ({2}) computed: [{3}];', iNetID,
        (SELECT GROUP_CONCAT(ROUND(val,5) ORDER BY id_neuron) FROM nn_ts_ComputeNet_Input),
        (SELECT GROUP_CONCAT(ROUND(val,5) ORDER BY id_neuron) FROM nn_ts_ComputeNet)
      ));

      ###  Teaching  ###
  	  DROP TEMPORARY TABLE IF EXISTS nn_ts_CorrectWeights_Computed, nn_ts_CorrectWeights_InternalValues;
		  ALTER TABLE nn_ts_ComputeNet RENAME TO nn_ts_CorrectWeights_Computed;
		  ALTER TABLE nn_ts_ComputeNet_InternalValues RENAME TO nn_ts_CorrectWeights_InternalValues;
		  CALL nn_ts_CorrectWeights( iNetID, dLearn, @out_dErrorSum );





      CALL LoggP('nn_ts_TeachTrainset',CONCAT('Error: ', NS(ROUND(@out_dErrorSum,4)) ));

    END LOOP cases;


  END WHILE;

  #CALL LoggLeave('nn_ts_TeachTrainset');




END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `nn_ts_VerifyTrainset`
--

DROP PROCEDURE IF EXISTS `nn_ts_VerifyTrainset`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `nn_ts_VerifyTrainset`( iTrainsetID INT )
BEGIN

  /*
   *  Verifies that the given train set has the same number
   *  of input and output values for all cases.
   *
   */

  /*
  ###  Counts of inputs and outputs for all cases of the given trainset.
  SELECT COUNT(DISTINCT i.pos) AS inputs, COUNT(DISTINCT o.pos) AS outputs
    FROM nn_trainset_cases AS cases
    LEFT JOIN nn_trainset_inputs  AS i USING( id_case )
    LEFT JOIN nn_trainset_outputs AS o USING( id_case )
  WHERE cases.id_set = iTrainsetID
  GROUP BY i.id_case, o.id_case;

  ### Only outputs - just one JOIN. Can perform better. TODO: Benchmark
  SELECT cases.id_set, cases.id_case, COUNT(o.id_case) AS outputs
    FROM nn_trainsets_cases AS cases
    LEFT JOIN nn_trainsets_output AS o USING( id_case )
  WHERE cases.id_set = 1
  GROUP BY o.id_case;

  /**/


  DROP TEMPORARY TABLE IF EXISTS nn_ts_VerifyTrainset;
  CREATE TEMPORARY TABLE nn_ts_VerifyTrainset

  SELECT cases.id_case, COUNT(DISTINCT i.pos) AS inputs, COUNT(DISTINCT o.pos) AS outputs
    FROM nn_trainset_cases AS cases
    LEFT JOIN nn_trainset_inputs  AS i USING( id_case )
    LEFT JOIN nn_trainset_outputs AS o USING( id_case )
  WHERE cases.id_set = iTrainsetID
  GROUP BY i.id_case, o.id_case
  # Filter only non-matching cases.
  HAVING inputs  != (SELECT input_count  FROM nn_trainsets WHERE id_set = iTrainsetID)
      OR outputs != (SELECT output_count FROM nn_trainsets WHERE id_set = iTrainsetID);


END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `ShowLog`
--

DROP PROCEDURE IF EXISTS `ShowLog`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ShowLog`()
BEGIN
  SELECT whn, thread, level, str, rout  FROM lib_logg;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
