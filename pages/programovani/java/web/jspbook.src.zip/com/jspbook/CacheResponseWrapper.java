/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpServletResponseWrapper;
/*    */ 
/*    */ public class CacheResponseWrapper extends HttpServletResponseWrapper
/*    */ {
/*  8 */   HttpServletResponse origResponse = null;
/*    */ 
/* 10 */   ServletOutputStream stream = null;
/*    */ 
/* 12 */   PrintWriter writer = null;
/*    */ 
/* 14 */   OutputStream cache = null;
/*    */ 
/*    */   public CacheResponseWrapper(HttpServletResponse response, OutputStream cache) {
/* 17 */     super(response);
/* 18 */     this.origResponse = response;
/* 19 */     this.cache = cache;
/*    */   }
/*    */ 
/*    */   public ServletOutputStream createOutputStream() throws IOException {
/* 23 */     return new CacheResponseStream(this.cache);
/*    */   }
/*    */ 
/*    */   public void flushBuffer() throws IOException {
/* 27 */     if (this.writer != null) {
/* 28 */       this.writer.flush();
/*    */     }
/* 30 */     this.stream.flush();
/* 31 */     this.cache.flush();
/*    */   }
/*    */ 
/*    */   public ServletOutputStream getOutputStream() throws IOException {
/* 35 */     if (this.writer != null) {
/* 36 */       throw new IllegalStateException(
/* 37 */         "getWriter() has already been called!");
/*    */     }
/*    */ 
/* 40 */     if (this.stream == null)
/* 41 */       this.stream = createOutputStream();
/* 42 */     return this.stream;
/*    */   }
/*    */ 
/*    */   public PrintWriter getWriter() throws IOException {
/* 46 */     if (this.writer != null) {
/* 47 */       return this.writer;
/*    */     }
/*    */ 
/* 50 */     if (this.stream != null) {
/* 51 */       throw new IllegalStateException(
/* 52 */         "getOutputStream() has already been called!");
/*    */     }
/*    */ 
/* 56 */     this.stream = createOutputStream();
/*    */ 
/* 59 */     this.writer = 
/* 60 */       new PrintWriter(new OutputStreamWriter(this.stream, 
/* 60 */       this.origResponse.getCharacterEncoding()));
/* 61 */     return this.writer;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CacheResponseWrapper
 * JD-Core Version:    0.5.4
 */