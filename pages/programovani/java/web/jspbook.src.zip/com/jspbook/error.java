/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class error
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 14 */     Logger logger = SiteLogger.getLogger();
/*    */ 
/* 16 */     Exception e = 
/* 17 */       (Exception)request.getAttribute("javax.servlet.jsp.jspException");
/*    */ 
/* 20 */     if (e != null) {
/* 21 */       StringWriter message = new StringWriter();
/* 22 */       e.printStackTrace(new PrintWriter(message));
/* 23 */       logger.severe(message.toString());
/*    */     }
/* 25 */     return true;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.error
 * JD-Core Version:    0.5.4
 */