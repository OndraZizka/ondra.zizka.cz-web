/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Calendar;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.fileupload.FileItem;
/*    */ import org.apache.commons.fileupload.FileUpload;
/*    */ 
/*    */ public class upload
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 17 */     long ts = Calendar.getInstance().getTimeInMillis();
/*    */ 
/* 19 */     ServletContext sc = request.getSession().getServletContext();
/* 20 */     String path = sc.getRealPath("/images");
/* 21 */     FileUpload fu = new FileUpload();
/*    */ 
/* 23 */     fu.setSizeMax(-1);
/* 24 */     fu.setRepositoryPath(path);
/*    */     try {
/* 26 */       List l = fu.parseRequest(request);
/* 27 */       Iterator i = l.iterator();
/* 28 */       while (i.hasNext()) {
/* 29 */         FileItem fi = (FileItem)i.next();
/* 30 */         String postFix = ".unknown";
/* 31 */         String name = fi.getName();
/* 32 */         int lastDot = name.lastIndexOf(".");
/* 33 */         if (lastDot != -1) {
/* 34 */           postFix = fi.getName().substring(lastDot, name.length());
/*    */         }
/* 36 */         fi.write(path + "/" + ts + postFix);
/*    */         try
/*    */         {
/* 40 */           InitialContext ctx = new InitialContext();
/* 41 */           DataSource ds = 
/* 42 */             (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 43 */           Connection conn = ds.getConnection();
/*    */           try {
/* 45 */             Statement statement = conn.createStatement();
/* 46 */             statement.executeQuery(
/* 47 */               "insert into images values('" + ts + postFix + "', 0)");
/*    */           } catch (Exception e) {
/* 49 */             throw new ServletException(e);
/*    */           } finally {
/* 51 */             conn.close();
/*    */           }
/*    */         } catch (SQLException e) {
/* 54 */           throw new ServletException(e);
/*    */         }
/*    */         catch (NamingException e) {
/* 57 */           throw new ServletException(e);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 61 */       throw new ServletException(e);
/*    */     }
/*    */ 
/* 64 */     response.sendRedirect("index.jsp");
/* 65 */     return false;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.upload
 * JD-Core Version:    0.5.4
 */