/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class InternationalizedHelloWorld extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 12 */     response.setContentType("text/html");
/* 13 */     PrintWriter out = response.getWriter();
/* 14 */     out.println("<html>");
/* 15 */     out.println("<head>");
/*    */ 
/* 17 */     String greeting = getServletConfig().getInitParameter("greeting");
/* 18 */     out.println("<title>" + greeting + "</title>");
/* 19 */     out.println("</head>");
/* 20 */     out.println("<body>");
/* 21 */     out.println("<h1>" + greeting + "</h1>");
/* 22 */     out.println("</body>");
/* 23 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.InternationalizedHelloWorld
 * JD-Core Version:    0.5.4
 */