/*    */ package com.jspbook;
/*    */ 
/*    */ import javax.servlet.http.HttpSessionEvent;
/*    */ import javax.servlet.http.HttpSessionListener;
/*    */ 
/*    */ public class ConcurrentUserTracker
/*    */   implements HttpSessionListener
/*    */ {
/*  7 */   static int users = 0;
/*    */ 
/*    */   public void sessionCreated(HttpSessionEvent e) {
/* 10 */     users += 1;
/*    */   }
/*    */   public void sessionDestroyed(HttpSessionEvent e) {
/* 13 */     users -= 1;
/*    */   }
/*    */   public static int getConcurrentUsers() {
/* 16 */     return users;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ConcurrentUserTracker
 * JD-Core Version:    0.5.4
 */