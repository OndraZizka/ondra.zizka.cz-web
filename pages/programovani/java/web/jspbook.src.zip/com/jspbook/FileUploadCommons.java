/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.fileupload.FileItem;
/*    */ import org.apache.commons.fileupload.FileUpload;
/*    */ 
/*    */ public class FileUploadCommons extends HttpServlet
/*    */ {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     response.setContentType("text/html");
/* 15 */     PrintWriter out = response.getWriter();
/*    */ 
/* 17 */     out.println("<html>");
/* 18 */     out.print("File upload success. <a href=\"/jspbook/files/");
/* 19 */     out.print("\">Click here to browse through all uploaded ");
/* 20 */     out.println("files.</a><br>");
/*    */ 
/* 22 */     ServletContext sc = getServletContext();
/* 23 */     String path = sc.getRealPath("/files");
/* 24 */     FileUpload fu = new FileUpload();
/*    */ 
/* 26 */     fu.setSizeMax(-1);
/* 27 */     fu.setRepositoryPath(path);
/*    */     try {
/* 29 */       List l = fu.parseRequest(request);
/* 30 */       Iterator i = l.iterator();
/* 31 */       while (i.hasNext()) {
/* 32 */         FileItem fi = (FileItem)i.next();
/*    */ 
/* 34 */         String filename = fi.getName();
/* 35 */         int slash = filename.lastIndexOf("\\");
/* 36 */         if (slash != -1) {
/* 37 */           filename = filename.substring(slash + 1);
/*    */         }
/*    */ 
/* 40 */         fi.write(path + "/" + filename);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 44 */       throw new ServletException(e);
/*    */     }
/*    */ 
/* 47 */     out.println("</html>");
/*    */   }
/*    */ 
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
/*    */   {
/* 52 */     doPost(request, response);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.FileUploadCommons
 * JD-Core Version:    0.5.4
 */