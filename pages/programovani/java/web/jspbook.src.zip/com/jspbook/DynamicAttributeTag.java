/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import javax.servlet.jsp.JspContext;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.tagext.DynamicAttributes;
/*    */ import javax.servlet.jsp.tagext.SimpleTagSupport;
/*    */ 
/*    */ public class DynamicAttributeTag extends SimpleTagSupport
/*    */   implements DynamicAttributes
/*    */ {
/* 10 */   protected Hashtable map = new Hashtable();
/*    */ 
/*    */   public void setDynamicAttribute(String uri, String name, Object value) throws JspException
/*    */   {
/* 14 */     this.map.put(name, value);
/*    */   }
/*    */ 
/*    */   public void doTag() throws JspException, IOException {
/* 18 */     JspWriter out = getJspContext().getOut();
/* 19 */     for (Enumeration keys = this.map.keys(); keys.hasMoreElements(); ) {
/* 20 */       Object key = keys.nextElement();
/* 21 */       Object value = this.map.get(key);
/* 22 */       out.print("<b>Attribute:</b><br>");
/* 23 */       out.print("name: " + key.toString() + "<br>");
/* 24 */       out.print("value: " + value.toString() + "<br>");
/*    */     }
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.DynamicAttributeTag
 * JD-Core Version:    0.5.4
 */