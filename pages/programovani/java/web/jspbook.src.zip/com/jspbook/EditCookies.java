/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.Cookie;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class EditCookies extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     response.setContentType("text/html");
/* 15 */     PrintWriter out = response.getWriter();
/* 16 */     Cookie[] cookies = request.getCookies();
/*    */ 
/* 19 */     String cookieName = request.getParameter("name");
/* 20 */     String cookieValue = request.getParameter("value");
/* 21 */     if ((cookieName != null) && (!cookieName.equals("")) && 
/* 22 */       (cookieValue != null) && (!cookieValue.equals(""))) {
/* 23 */       Cookie cookie = new Cookie(cookieName, cookieValue);
/* 24 */       response.addCookie(cookie);
/* 25 */       response.sendRedirect("/jspbook/EditCookies");
/*    */     }
/*    */ 
/* 29 */     String cookieToDelete = request.getParameter("deleteCookie");
/* 30 */     if ((cookieToDelete != null) && (!cookieToDelete.equals(""))) {
/* 31 */       for (int i = 0; i < cookies.length; ++i) {
/* 32 */         Cookie cookie = cookies[i];
/* 33 */         if (cookie.getName().equals(cookieToDelete)) {
/* 34 */           cookie.setMaxAge(0);
/* 35 */           response.addCookie(cookie);
/* 36 */           response.sendRedirect("/jspbook/EditCookies");
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 41 */     out.println("<html>");
/* 42 */     out.println("<head>");
/* 43 */     out.println("<title>Cookies sent by your client</title>");
/* 44 */     out.println("</head>");
/* 45 */     out.println("<body>");
/* 46 */     out.println("<p>The following cookies were sent:</p>");
/* 47 */     if (cookies == null) {
/* 48 */       out.println("No cookies were sent!<br>");
/*    */     }
/*    */     else
/*    */     {
/* 52 */       for (int i = 0; i < cookies.length; ++i) {
/* 53 */         Cookie cookie = cookies[i];
/* 54 */         out.println("<h3>Cookie #" + i + "</h3>");
/* 55 */         out.println("<form method=\"post\">");
/* 56 */         out.print("<b>Name</b>: <input name=\"name\" value=\"");
/* 57 */         out.println(cookie.getName() + "\"><br>");
/* 58 */         out.print("<b>Value</b>: <input name=\"value\"");
/* 59 */         out.println(" value=\"" + cookie.getValue() + "\"><br>");
/* 60 */         out.print("<input type=\"submit\"");
/* 61 */         out.println(" value=\"Update Cookie\"><br><br>");
/* 62 */         out.println("</form>");
/*    */       }
/*    */     }
/*    */ 
/* 66 */     out.println("<h3>Create a New Cookie</h3><br>");
/* 67 */     out.println("<form method=\"post\">");
/* 68 */     out.println("<b>Name</b>: <input name=\"name\"><br>");
/* 69 */     out.println("<b>Value</b>: <input name=\"value\"><br>");
/* 70 */     out.print("<input type=\"submit\"");
/* 71 */     out.println(" value=\"Add Cookie\"><br>");
/* 72 */     out.println("</form>");
/*    */ 
/* 75 */     if (cookies != null) {
/* 76 */       out.println("<h3>Delete a Cookie</h3>");
/* 77 */       out.println("<form method=\"post\">");
/* 78 */       out.println("<select name=\"deleteCookie\">");
/* 79 */       for (int i = 0; i < cookies.length; ++i) {
/* 80 */         Cookie cookie = cookies[i];
/* 81 */         out.print("<option value=\"" + cookie.getName() + "\">");
/* 82 */         out.println(cookie.getName() + "</option><br>");
/*    */       }
/* 84 */       out.println("</select>");
/* 85 */       out.print("<input type=\"submit\"");
/* 86 */       out.println("value=\"Delete Cookie\"><br>");
/* 87 */       out.println("</form>");
/*    */     }
/* 89 */     out.println("</body>");
/* 90 */     out.println("</html>");
/*    */   }
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 97 */     doGet(request, response);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.EditCookies
 * JD-Core Version:    0.5.4
 */