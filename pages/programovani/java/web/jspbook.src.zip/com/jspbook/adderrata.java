/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Calendar;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class adderrata
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 16 */     String errata = request.getParameter("errata");
/*    */ 
/* 18 */     if (errata == null) {
/* 19 */       return true;
/*    */     }
/*    */     try
/*    */     {
/* 23 */       InitialContext ctx = new InitialContext();
/* 24 */       DataSource ds = 
/* 25 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 26 */       Connection conn = ds.getConnection();
/*    */       try {
/* 28 */         Statement statement = conn.createStatement();
/*    */ 
/* 30 */         ServletContext sc = 
/* 31 */           request.getSession().getServletContext();
/* 32 */         String dir = sc.getRealPath("/WEB-INF/errata");
/* 33 */         new File(dir).mkdirs();
/* 34 */         long l = Calendar.getInstance().getTimeInMillis();
/*    */ 
/* 37 */         FileWriter fw = new FileWriter(dir + "/" + l + ".jsp");
/* 38 */         fw.write("<p class=\"title\">*Page*</p>");
/* 39 */         fw.write("<p class=\"news-content\">");
/* 40 */         fw.write(errata);
/* 41 */         fw.write("</p>");
/* 42 */         fw.flush();
/* 43 */         fw.close();
/*    */ 
/* 45 */         statement.executeQuery(
/* 46 */           "insert into errata values (" + l + ",0)");
/* 47 */         response.sendRedirect("index.jsp");
/*    */       } catch (Exception e) {
/* 49 */         throw new ServletException(e);
/*    */       } finally {
/* 51 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 54 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 57 */       throw new ServletException(e);
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.adderrata
 * JD-Core Version:    0.5.4
 */