/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class MockError extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 13 */     response.setContentType("text/html");
/* 14 */     PrintWriter out = response.getWriter();
/* 15 */     out.println("<html>");
/* 16 */     out.println("<head>");
/* 17 */     out.println("<title>An Error Has Occurred!</title>");
/* 18 */     out.println("</head>");
/* 19 */     out.println("<body>");
/* 20 */     ServletContext sc = getServletConfig().getServletContext();
/* 21 */     String adminEmail = sc.getInitParameter("admin email");
/* 22 */     out.println("<h1>Error Page</h1>");
/* 23 */     out.print("Sorry! An unexpected error has occurred.");
/* 24 */     out.print("Please send an error report to " + adminEmail + ".");
/* 25 */     out.println("</body>");
/* 26 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.MockError
 * JD-Core Version:    0.5.4
 */