/*    */ package com.jspbook;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ import javax.servlet.jsp.tagext.VariableInfo;
/*    */ 
/*    */ public class LinkIterationTEI extends TagExtraInfo
/*    */ {
/*    */   public VariableInfo[] getVariableInfo(TagData data)
/*    */   {
/*  8 */     VariableInfo info = new VariableInfo("link", 
/*  9 */       "String", 
/* 10 */       true, 
/* 11 */       0);
/* 12 */     VariableInfo[] vi = { info };
/* 13 */     return vi;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkIterationTEI
 * JD-Core Version:    0.5.4
 */