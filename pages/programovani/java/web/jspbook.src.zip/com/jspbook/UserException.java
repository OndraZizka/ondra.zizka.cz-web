/*   */ package com.jspbook;
/*   */ 
/*   */ public class UserException extends Exception
/*   */ {
/*   */   public UserException(String description)
/*   */   {
/* 7 */     super(description);
/*   */   }
/*   */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.UserException
 * JD-Core Version:    0.5.4
 */