/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ 
/*    */ public class FormattedDateTag extends TagSupport
/*    */ {
/*    */   private String format;
/*    */ 
/*    */   public void setFormat(String format)
/*    */   {
/* 13 */     this.format = format;
/*    */   }
/*    */ 
/*    */   public int doStartTag() throws JspException {
/* 17 */     JspWriter out = this.pageContext.getOut();
/*    */     try {
/* 19 */       if (this.format != null) {
/* 20 */         SimpleDateFormat sdf = new SimpleDateFormat(this.format);
/* 21 */         out.println(sdf.format(new Date()));
/*    */       }
/*    */       else {
/* 24 */         out.println(new Date().toString());
/*    */       }
/*    */     }
/*    */     catch (IOException e) {
/* 28 */       throw new JspException(e.getMessage());
/*    */     }
/*    */     finally {
/* 31 */       this.format = null;
/*    */     }
/*    */ 
/* 34 */     return 0;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.FormattedDateTag
 * JD-Core Version:    0.5.4
 */