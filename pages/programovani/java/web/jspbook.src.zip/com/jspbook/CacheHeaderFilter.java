/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CacheHeaderFilter
/*    */   implements Filter
/*    */ {
/*    */   ServletContext sc;
/*    */   FilterConfig fc;
/* 11 */   String cacheControl = null;
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 16 */     HttpServletRequest request = (HttpServletRequest)req;
/* 17 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */ 
/* 20 */     String r = this.sc.getRealPath("");
/* 21 */     String path = this.fc.getInitParameter(request.getRequestURI());
/* 22 */     if ((path != null) && (path.equals("nocache"))) {
/* 23 */       chain.doFilter(request, response);
/* 24 */       return;
/*    */     }
/* 26 */     path = r + path;
/*    */ 
/* 29 */     if (this.cacheControl != null) {
/* 30 */       response.addHeader("Cache-Control", this.cacheControl);
/*    */     }
/*    */ 
/* 34 */     chain.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig) {
/* 38 */     this.fc = filterConfig;
/*    */ 
/* 41 */     this.sc = filterConfig.getServletContext();
/*    */ 
/* 44 */     this.cacheControl = this.fc.getInitParameter("Cache-Control");
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 48 */     this.sc = null;
/* 49 */     this.fc = null;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CacheHeaderFilter
 * JD-Core Version:    0.5.4
 */