/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Calendar;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class addfaq
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 16 */     String question = request.getParameter("question");
/* 17 */     String answer = request.getParameter("answer");
/*    */ 
/* 19 */     if ((question == null) || (answer == null)) {
/* 20 */       return true;
/*    */     }
/*    */     try
/*    */     {
/* 24 */       InitialContext ctx = new InitialContext();
/* 25 */       DataSource ds = 
/* 26 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 27 */       Connection conn = ds.getConnection();
/*    */       try {
/* 29 */         Statement statement = conn.createStatement();
/*    */ 
/* 31 */         ServletContext sc = 
/* 32 */           request.getSession().getServletContext();
/* 33 */         String dir = sc.getRealPath("/WEB-INF/faq");
/* 34 */         new File(dir).mkdirs();
/* 35 */         long l = Calendar.getInstance().getTimeInMillis();
/*    */ 
/* 38 */         FileWriter fw = new FileWriter(dir + "/" + l + ".jsp");
/* 39 */         fw.write("<p class=\"title\">" + question + "</p>");
/* 40 */         fw.write("<p class=\"news-content\">");
/* 41 */         fw.write(answer);
/* 42 */         fw.write("</p>");
/* 43 */         fw.flush();
/* 44 */         fw.close();
/*    */ 
/* 46 */         statement.executeQuery(
/* 47 */           "insert into faq values (" + l + ",0)");
/* 48 */         response.sendRedirect("index.jsp");
/*    */       } catch (Exception e) {
/* 50 */         throw new ServletException(e);
/*    */       } finally {
/* 52 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 55 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 58 */       throw new ServletException(e);
/*    */     }
/* 60 */     return false;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.addfaq
 * JD-Core Version:    0.5.4
 */