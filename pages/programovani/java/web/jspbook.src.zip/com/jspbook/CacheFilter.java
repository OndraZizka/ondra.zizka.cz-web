/*     */ package com.jspbook;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class CacheFilter
/*     */   implements Filter
/*     */ {
/*     */   ServletContext sc;
/*     */   FilterConfig fc;
/*  13 */   long cacheTimeout = 30000L;
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException
/*     */   {
/*  17 */     HttpServletRequest request = (HttpServletRequest)req;
/*  18 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */ 
/*  21 */     String uri = request.getRequestURI();
/*  22 */     if ((uri == null) || (uri.equals("")) || (uri.equals("/"))) {
/*  23 */       chain.doFilter(request, response);
/*  24 */       return;
/*     */     }
/*     */ 
/*  28 */     String path = this.fc.getInitParameter(uri);
/*  29 */     if ((path != null) && (path.equals("nocache"))) {
/*  30 */       chain.doFilter(request, response);
/*  31 */       return;
/*     */     }
/*     */ 
/*  35 */     String id = uri;
/*  36 */     if (request.getQueryString() != null) {
/*  37 */       id = id + request.getQueryString();
/*     */     }
/*     */ 
/*  41 */     String localeSensitive = this.fc.getInitParameter("locale-sensitive");
/*  42 */     if ((localeSensitive != null) && (!localeSensitive.equals(""))) {
/*  43 */       StringWriter ldata = new StringWriter();
/*  44 */       Enumeration locales = request.getLocales();
/*  45 */       while (locales.hasMoreElements()) {
/*  46 */         Locale locale = (Locale)locales.nextElement();
/*  47 */         ldata.write(locale.getISO3Language());
/*     */       }
/*  49 */       id = id + ldata.toString();
/*     */     }
/*     */ 
/*  53 */     File tempDir = (File)this.sc.getAttribute("javax.servlet.context.tempdir");
/*     */ 
/*  56 */     String temp = tempDir.getAbsolutePath();
/*  57 */     File file = new File(temp + id);
/*     */ 
/*  60 */     path = this.sc.getRealPath(uri);
/*     */ 
/*  63 */     File current = new File(path);
/*     */     try
/*     */     {
/*  66 */       long now = System.currentTimeMillis();
/*     */ 
/*  68 */       if ((!file.exists()) || (
/*  69 */         (file.exists()) && (this.cacheTimeout < now - 
/*  70 */         file.lastModified()))) {
/*  71 */         String name = file.getAbsolutePath();
/*     */ 
/*  74 */         name = name.substring(0, 
/*  75 */           (name.lastIndexOf(File.separatorChar) == -1) ? 0 : 
/*  76 */           name.lastIndexOf(File.separatorChar));
/*  77 */         new File(name).mkdirs();
/*     */ 
/*  80 */         FileOutputStream fos = new FileOutputStream(file);
/*  81 */         CacheResponseWrapper wrappedResponse = new CacheResponseWrapper(
/*  82 */           response, fos);
/*  83 */         chain.doFilter(req, wrappedResponse);
/*     */ 
/*  86 */         wrappedResponse.flushBuffer();
/*  87 */         fos.flush();
/*  88 */         fos.close();
/*     */       }
/*     */     } catch (ServletException e) {
/*  91 */       if (!file.exists())
/*  92 */         throw new ServletException(e);
/*     */     }
/*     */     catch (IOException e) {
/*  95 */       if (!file.exists()) {
/*  96 */         throw e;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 101 */     FileInputStream fis = new FileInputStream(file);
/* 102 */     String mt = this.sc.getMimeType(request.getRequestURI());
/* 103 */     response.setContentType(mt);
/* 104 */     ServletOutputStream sos = res.getOutputStream();
/* 105 */     byte[] buffer = new byte[1024];
/* 106 */     for (int bytesRead = fis.read(buffer); bytesRead > 0; bytesRead = fis.read(buffer))
/* 107 */       sos.write(buffer, 0, bytesRead);
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */   {
/* 112 */     this.fc = filterConfig;
/*     */ 
/* 114 */     String ct = this.fc.getInitParameter("cacheTimeout");
/* 115 */     if (ct != null) {
/* 116 */       this.cacheTimeout = (60000L * Long.parseLong(ct));
/*     */     }
/*     */ 
/* 119 */     this.sc = filterConfig.getServletContext();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 123 */     this.sc = null;
/* 124 */     this.fc = null;
/*     */   }
/*     */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CacheFilter
 * JD-Core Version:    0.5.4
 */