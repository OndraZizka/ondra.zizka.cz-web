/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class I18nHelloWorld extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 12 */     response.setContentType("text/html; charset=UTF-8");
/* 13 */     ServletOutputStream sos = response.getOutputStream();
/* 14 */     PrintWriter out = 
/* 15 */       new PrintWriter(new OutputStreamWriter(sos, "UTF-8"), true);
/* 16 */     out.println("<html>");
/* 17 */     out.println("<head>");
/* 18 */     out.println("<title>i18n Hello World!</title>");
/* 19 */     out.println("</head>");
/* 20 */     out.println("<body>");
/* 21 */     out.println("<h1>你好世界!</h1>");
/* 22 */     out.println("<h1>Hello World!</h1>");
/* 23 */     out.println("<h1>Bonjour Monde!</h1>");
/* 24 */     out.println("<h1>Hallo Welt!</h1>");
/* 25 */     out.println("<h1>Ciao Mondo!</h1>");
/* 26 */     out.println("<h1>こんにちは世界!</h1>");
/* 27 */     out.println("<h1>여보세요 세계 !</h1>");
/* 28 */     out.println("<h1>¡Hola Mundo!</h1>");
/* 29 */     out.println("</body>");
/* 30 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.I18nHelloWorld
 * JD-Core Version:    0.5.4
 */