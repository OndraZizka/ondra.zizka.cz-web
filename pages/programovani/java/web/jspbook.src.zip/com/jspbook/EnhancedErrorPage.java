/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class EnhancedErrorPage extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 13 */     response.setContentType("text/html");
/* 14 */     PrintWriter out = response.getWriter();
/*    */ 
/* 17 */     ServletContext sc = getServletConfig().getServletContext();
/* 18 */     String adminEmail = sc.getInitParameter("admin email");
/*    */ 
/* 21 */     Exception e = (Exception)request.getAttribute("javax.servlet.jsp.jspException");
/*    */ 
/* 23 */     out.println("<html>");
/* 24 */     out.println("<head>");
/* 25 */     out.println("<title>An Error Has Occurred!</title>");
/* 26 */     out.println("</head>");
/* 27 */     out.println("<body>");
/* 28 */     out.println("<h3>An Error Has Occurred</h3>");
/* 29 */     out.println("Sorry, but this site is unavailable to render");
/* 30 */     out.println(" the service you requested. A bug in the");
/* 31 */     out.println("system has caused an error to occur. Please ");
/* 32 */     out.println("send a description of the problem to ");
/* 33 */     out.println(adminEmail + " with, \"" + e.getMessage() + "\", ");
/* 34 */     out.println(" listed as the cause of the error.");
/* 35 */     out.println("</body>");
/* 36 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.EnhancedErrorPage
 * JD-Core Version:    0.5.4
 */