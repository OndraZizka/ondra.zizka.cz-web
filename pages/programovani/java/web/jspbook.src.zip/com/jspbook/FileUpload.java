/*     */ package com.jspbook;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class FileUpload extends HttpServlet
/*     */ {
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/*  12 */     response.setContentType("text/html");
/*  13 */     PrintWriter out = response.getWriter();
/*     */ 
/*  15 */     out.println("<html>");
/*  16 */     out.print("File upload success. <a href=\"/jspbook/files/");
/*  17 */     out.print("\">Click here to browse through all uploaded ");
/*  18 */     out.println("files.</a><br>");
/*     */ 
/*  20 */     ServletInputStream sis = request.getInputStream();
/*  21 */     StringWriter sw = new StringWriter();
/*  22 */     int i = sis.read();
/*  23 */     for (; (i != -1) && (i != 13); i = sis.read()) {
/*  24 */       sw.write(i);
/*     */     }
/*  26 */     sis.read();
/*  27 */     String delimiter = sw.toString();
/*     */ 
/*  29 */     int count = 0;
/*     */     while (true) {
/*  31 */       StringWriter h = new StringWriter();
/*  32 */       int[] temp = new int[4];
/*  33 */       temp[0] = (byte)sis.read();
/*  34 */       temp[1] = (byte)sis.read();
/*  35 */       temp[2] = (byte)sis.read();
/*  36 */       h.write(temp[0]);
/*  37 */       h.write(temp[1]);
/*  38 */       h.write(temp[2]);
/*     */ 
/*  40 */       for (temp[3] = sis.read(); temp[3] != -1; temp[3] = sis.read()) {
/*  41 */         if ((temp[0] == 13) && 
/*  42 */           (temp[1] == 10) && 
/*  43 */           (temp[2] == 13) && 
/*  44 */           (temp[3] == 10)) {
/*     */           break;
/*     */         }
/*  47 */         h.write(temp[3]);
/*  48 */         temp[0] = temp[1];
/*  49 */         temp[1] = temp[2];
/*  50 */         temp[2] = temp[3];
/*     */       }
/*  52 */       String header = h.toString();
/*     */ 
/*  54 */       int startName = header.indexOf("name=\"");
/*  55 */       int endName = header.indexOf("\"", startName + 6);
/*  56 */       if (startName == -1) break; if (endName == -1) {
/*     */         break;
/*     */       }
/*  59 */       String name = header.substring(startName + 6, endName);
/*  60 */       if (name.equals("file")) {
/*  61 */         startName = header.indexOf("filename=\"");
/*  62 */         endName = header.indexOf("\"", startName + 10);
/*  63 */         String filename = header.substring(startName + 10, endName);
/*     */ 
/*  65 */         int slash = filename.lastIndexOf("\\");
/*  66 */         if (slash != -1) {
/*  67 */           filename = filename.substring(slash + 1);
/*     */         }
/*     */ 
/*  70 */         ServletContext sc = request.getSession().getServletContext();
/*     */ 
/*  72 */         File file = new File(sc.getRealPath("/files"));
/*  73 */         file.mkdirs();
/*  74 */         FileOutputStream fos = 
/*  75 */           new FileOutputStream(sc.getRealPath("/files") + "/" + filename);
/*     */ 
/*  78 */         int length = 0;
/*  79 */         delimiter = "\r\n" + delimiter;
/*  80 */         byte[] body = new byte[delimiter.length()];
/*  81 */         for (int j = 0; j < body.length; ++j) {
/*  82 */           body[j] = (byte)sis.read();
/*     */         }
/*     */ 
/*  85 */         if (!delimiter.equals(new String(body))) {
/*  86 */           int e = body.length - 1;
/*  87 */           i = sis.read();
/*  88 */           for (; i != -1; i = sis.read()) {
/*  89 */             fos.write(body[0]);
/*  90 */             for (int l = 0; l < body.length - 1; ++l) {
/*  91 */               body[l] = body[(l + 1)];
/*     */             }
/*  93 */             body[e] = (byte)i;
/*  94 */             if (delimiter.equals(new String(body))) {
/*     */               break;
/*     */             }
/*  97 */             ++length;
/*     */           }
/*     */         }
/*     */ 
/* 101 */         fos.flush();
/* 102 */         fos.close();
/*     */       }
/* 104 */       if ((sis.read() == 45) && (sis.read() == 45)) {
/*     */         break;
/*     */       }
/*     */     }
/* 108 */     out.println("</html>");
/*     */   }
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
/*     */   {
/* 113 */     doPost(request, response);
/*     */   }
/*     */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.FileUpload
 * JD-Core Version:    0.5.4
 */