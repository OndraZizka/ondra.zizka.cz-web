/*    */ package com.jspbook;
/*    */ 
/*    */ public class Welcome
/*    */ {
/*  4 */   protected String title = null;
/*  5 */   protected String welcome = null;
/*    */ 
/*    */   public String getTitle() {
/*  8 */     return this.title;
/*    */   }
/*    */   public void setTitle(String title) {
/* 11 */     this.title = title;
/*    */   }
/*    */ 
/*    */   public String getWelcome() {
/* 15 */     return this.welcome;
/*    */   }
/*    */   public void setWelcome(String welcome) {
/* 18 */     this.welcome = welcome;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.Welcome
 * JD-Core Version:    0.5.4
 */