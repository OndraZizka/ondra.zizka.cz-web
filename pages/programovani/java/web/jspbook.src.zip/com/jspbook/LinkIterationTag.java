/*    */ package com.jspbook;
/*    */ 
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ 
/*    */ public class LinkIterationTag extends TagSupport
/*    */ {
/*    */   String[] links;
/*    */   int count;
/*    */ 
/*    */   public int doStartTag()
/*    */     throws JspException
/*    */   {
/* 13 */     ServletRequest request = this.pageContext.getRequest();
/* 14 */     this.links = ((String[])request.getAttribute("links"));
/*    */ 
/* 16 */     this.count = 0;
/*    */ 
/* 19 */     this.pageContext.setAttribute("link", this.links[this.count]);
/* 20 */     this.count += 1;
/* 21 */     return 1;
/*    */   }
/*    */ 
/*    */   public int doAfterBody() throws JspException {
/* 25 */     if (this.count < this.links.length) {
/*    */       try {
/* 27 */         this.pageContext.setAttribute("link", this.links[this.count]);
/* 28 */         this.count += 1;
/*    */       }
/*    */       catch (Exception e) {
/* 31 */         throw new JspException();
/*    */       }
/* 33 */       return 2;
/*    */     }
/*    */ 
/* 36 */     return 0;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkIterationTag
 * JD-Core Version:    0.5.4
 */