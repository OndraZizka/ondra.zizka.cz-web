/*    */ package com.jspbook;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.logging.Formatter;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.LogRecord;
/*    */ 
/*    */ public class CustomFormatter extends Formatter
/*    */ {
/*    */   public String format(LogRecord log)
/*    */   {
/* 10 */     Date date = new Date(log.getMillis());
/* 11 */     String level = log.getLevel().getName();
/* 12 */     String string = "[" + level + " " + date.toString() + "]\n";
/* 13 */     string = string + log.getMessage() + "\n\n";
/* 14 */     Throwable thrown = log.getThrown();
/* 15 */     if (thrown != null) {
/* 16 */       string = string + thrown.toString();
/*    */     }
/* 18 */     return string;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CustomFormatter
 * JD-Core Version:    0.5.4
 */