/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.sql.Timestamp;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.LinkedList;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public abstract class AbstractContent
/*    */   implements Control
/*    */ {
/*    */   public abstract boolean doLogic(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws ServletException, IOException;
/*    */ 
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response, String table)
/*    */     throws ServletException, IOException
/*    */   {
/* 20 */     LinkedList content = new LinkedList();
/* 21 */     request.setAttribute(table, content);
/*    */     try
/*    */     {
/* 24 */       InitialContext ctx = new InitialContext();
/* 25 */       DataSource ds = 
/* 26 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 27 */       Connection conn = ds.getConnection();
/*    */       try {
/* 29 */         Statement statement = conn.createStatement();
/*    */ 
/* 31 */         ResultSet rs = 
/* 32 */           statement.executeQuery("select * from " + table + " where visible=true order by ts desc");
/* 33 */         ResultSetMetaData rsmd = rs.getMetaData();
/* 34 */         while (rs.next()) {
/* 35 */           long l = rs.getLong(1);
/* 36 */           Timestamp ts = new Timestamp(l);
/* 37 */           SimpleDateFormat sdf = 
/* 38 */             new SimpleDateFormat("EEE, MMM d, yyyy HH:mm:ss z");
/* 39 */           Date d = new Date(l);
/* 40 */           String con = 
/* 41 */             "<p class=\"date\"><a name=\"" + l + "\"></a>" + sdf.format(d) + "</p>";
/* 42 */           String u = 
/* 43 */             "/WEB-INF/" + table + "/" + new Long(l).toString() + ".jsp";
/*    */ 
/* 46 */           StringWriter sw = new StringWriter();
/* 47 */           String file = request.getSession().getServletContext()
/* 48 */             .getRealPath(SimpleI18nFilter.getLanguage(u, request));
/* 49 */           FileInputStream fis = new FileInputStream(file);
/* 50 */           int i = 0;
/* 51 */           while ((i = fis.read()) != -1) {
/* 52 */             sw.write(i);
/*    */           }
/*    */ 
/* 55 */           con = con + new String(sw.toString());
/* 56 */           content.add(con);
/*    */         }
/*    */       } catch (Exception e) {
/* 59 */         throw new ServletException(e);
/*    */       } finally {
/* 61 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 64 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 67 */       throw new ServletException(e);
/*    */     }
/* 69 */     return true;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.AbstractContent
 * JD-Core Version:    0.5.4
 */