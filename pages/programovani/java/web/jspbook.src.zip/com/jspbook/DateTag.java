/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Date;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ 
/*    */ public class DateTag extends TagSupport
/*    */ {
/*    */   public int doStartTag()
/*    */     throws JspException
/*    */   {
/* 12 */     JspWriter out = this.pageContext.getOut();
/*    */     try {
/* 14 */       Date date = new Date();
/* 15 */       out.println(date.toString());
/*    */     }
/*    */     catch (IOException e) {
/* 18 */       throw new JspException(e.getMessage());
/*    */     }
/*    */ 
/* 21 */     return 0;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.DateTag
 * JD-Core Version:    0.5.4
 */