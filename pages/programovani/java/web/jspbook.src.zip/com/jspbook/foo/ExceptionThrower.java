/*    */ package com.jspbook.foo;
/*    */ 
/*    */ public class ExceptionThrower
/*    */ {
/*    */   public static void throwException(String message)
/*    */     throws Exception
/*    */   {
/*  6 */     throw new Exception(message);
/*    */   }
/*    */ 
/*    */   public static void throwCustomException(String message) throws CustomException
/*    */   {
/* 11 */     throw new CustomException(message);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.foo.ExceptionThrower
 * JD-Core Version:    0.5.4
 */