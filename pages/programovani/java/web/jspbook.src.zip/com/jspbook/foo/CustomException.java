/*   */ package com.jspbook.foo;
/*   */ 
/*   */ public class CustomException extends Exception
/*   */ {
/*   */   public CustomException(String message)
/*   */   {
/* 6 */     super(message);
/*   */   }
/*   */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.foo.CustomException
 * JD-Core Version:    0.5.4
 */