/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ShowSource extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     PrintWriter out = response.getWriter();
/*    */ 
/* 17 */     ServletConfig config = getServletConfig();
/* 18 */     ServletContext sc = config.getServletContext();
/*    */ 
/* 21 */     String resource = request.getParameter("resource");
/* 22 */     if ((resource != null) && (!resource.equals("")))
/*    */     {
/* 25 */       InputStream is = sc.getResourceAsStream(resource);
/* 26 */       if (is != null) {
/* 27 */         response.setContentType("text/plain");
/* 28 */         StringWriter sw = new StringWriter();
/* 29 */         for (int c = is.read(); c != -1; c = is.read()) {
/* 30 */           sw.write(c);
/*    */         }
/* 32 */         out.print(sw.toString());
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 37 */       response.setContentType("text/html");
/* 38 */       out.println("<html>");
/* 39 */       out.println("<head>");
/* 40 */       out.println("<title>Source-Code Servlet</title>");
/* 41 */       out.println("</head>");
/* 42 */       out.println("<body>");
/* 43 */       out.println("<form>");
/* 44 */       out.println("Choose a resource to see the source.<br>");
/* 45 */       out.println("<select name=\"resource\">");
/*    */ 
/* 47 */       listFiles(sc, out, "/");
/* 48 */       out.println("</select><br>");
/* 49 */       out.print("<input type=\"submit\" ");
/* 50 */       out.println("value=\"Show Source\">");
/* 51 */       out.println("</body>");
/* 52 */       out.println("</html>");
/*    */     }
/*    */   }
/*    */ 
/*    */   void listFiles(ServletContext sc, PrintWriter out, String base)
/*    */   {
/* 58 */     Set set = sc.getResourcePaths(base);
/* 59 */     Iterator i = set.iterator();
/* 60 */     while (i.hasNext()) {
/* 61 */       String s = (String)i.next();
/* 62 */       if (s.endsWith("/")) {
/* 63 */         listFiles(sc, out, s);
/*    */       }
/*    */       else {
/* 66 */         out.print("<option value=\"" + s);
/* 67 */         out.println("\">" + s + "</option>");
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ShowSource
 * JD-Core Version:    0.5.4
 */