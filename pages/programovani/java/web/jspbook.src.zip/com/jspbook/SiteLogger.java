/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.logging.FileHandler;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ 
/*    */ public class SiteLogger
/*    */   implements ServletContextListener
/*    */ {
/*    */   private static Logger logger;
/*    */ 
/*    */   public static Logger getLogger()
/*    */     throws IOException
/*    */   {
/* 14 */     return logger;
/*    */   }
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent e) {
/* 18 */     ServletContext sc = e.getServletContext();
/*    */ 
/* 21 */     logger = Logger.getLogger("global");
/* 22 */     logger.setLevel(Level.INFO);
/*    */     try
/*    */     {
/* 25 */       FileHandler fh = null;
/* 26 */       String root = sc.getRealPath("/");
/* 27 */       fh = new FileHandler(root + "WEB-INF/log.txt");
/* 28 */       fh.setFormatter(new CustomFormatter());
/* 29 */       logger.addHandler(fh);
/*    */     } catch (IOException ee) {
/* 31 */       System.err.println("Can't load logger: " + ee.getMessage());
/*    */     }
/*    */ 
/* 34 */     sc.setAttribute("com.jspbook.SiteLogger", logger);
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent e) {
/* 38 */     ServletContext sc = e.getServletContext();
/* 39 */     sc.removeAttribute("com.jspbook.SiteLogger");
/* 40 */     logger = null;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.SiteLogger
 * JD-Core Version:    0.5.4
 */