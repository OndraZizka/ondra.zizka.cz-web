/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CompressionTest extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     response.setContentType("text/html");
/* 15 */     PrintWriter out = response.getWriter();
/* 16 */     out.println("<html>");
/* 17 */     out.println("<head>");
/* 18 */     out.println("<title>Compression Test</title>");
/* 19 */     out.println("</head>");
/* 20 */     out.println("<body>");
/* 21 */     out.println("<h1>Compression Test</h1>");
/* 22 */     out.println("<form>");
/* 23 */     String url = request.getParameter("url");
/* 24 */     if (url != null) {
/* 25 */       out.print("<input size=\"50\" name=\"url\" ");
/* 26 */       out.println("value=\"" + url + "\">");
/*    */     } else {
/* 28 */       out.println("<input size=\"50\" name=\"url\">");
/*    */     }
/* 30 */     out.print("<input type=\"submit\" value=\"Check\">");
/* 31 */     out.println("</form>");
/* 32 */     out.println("URL: " + url);
/* 33 */     if (url != null) {
/* 34 */       URL noCompress = new URL(url);
/* 35 */       HttpURLConnection huc = 
/* 36 */         (HttpURLConnection)noCompress.openConnection();
/* 37 */       huc.setRequestProperty("user-agent", "Mozilla(MSIE)");
/* 38 */       huc.connect();
/* 39 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 40 */       InputStream is = huc.getInputStream();
/* 41 */       while (is.read() != -1) {
/* 42 */         baos.write((byte)is.read());
/*    */       }
/* 44 */       byte[] b1 = baos.toByteArray();
/*    */ 
/* 46 */       URL compress = new URL(url);
/* 47 */       HttpURLConnection hucCompress = 
/* 48 */         (HttpURLConnection)noCompress.openConnection();
/* 49 */       hucCompress.setRequestProperty("accept-encoding", "gzip");
/* 50 */       hucCompress.setRequestProperty("user-agent", "Mozilla(MSIE)");
/* 51 */       hucCompress.connect();
/* 52 */       ByteArrayOutputStream baosCompress = 
/* 53 */         new ByteArrayOutputStream();
/* 54 */       InputStream isCompress = hucCompress.getInputStream();
/* 55 */       while (isCompress.read() != -1) {
/* 56 */         baosCompress.write((byte)isCompress.read());
/*    */       }
/* 58 */       byte[] b2 = baosCompress.toByteArray();
/*    */ 
/* 60 */       out.print("<pre>");
/* 61 */       out.println("Uncompressed: " + b1.length);
/* 62 */       out.println("Compressed: " + b2.length);
/* 63 */       out.print("Space saved: " + (b1.length - b2.length) + ", or ");
/* 64 */       out.println((b1.length - b2.length) * 100 / b1.length + "%");
/* 65 */       out.println("Downstream(2kbps)");
/* 66 */       out.println(" No GZIP: " + b1.length / 2000.0F + "seconds");
/* 67 */       out.println(" GZIP:    " + b2.length / 2000.0F + "seconds");
/* 68 */       out.println("Downstream(5kbps)");
/* 69 */       out.println(" No GZIP: " + b1.length / 5000.0F + "seconds");
/* 70 */       out.println(" GZIP:    " + b2.length / 5000.0F + "seconds");
/* 71 */       out.println("Downstream(10kbps)");
/* 72 */       out.println(" No GZIP: " + b1.length / 10000.0F + "seconds");
/* 73 */       out.println(" GZIP:    " + b2.length / 10000.0F + "seconds");
/* 74 */       out.println("</pre>");
/*    */     }
/* 76 */     out.println("</body>");
/* 77 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CompressionTest
 * JD-Core Version:    0.5.4
 */