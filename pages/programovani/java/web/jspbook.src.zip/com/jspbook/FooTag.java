/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ 
/*    */ public class FooTag extends TagSupport
/*    */ {
/*    */   public int doStartTag()
/*    */     throws JspException
/*    */   {
/* 11 */     JspWriter out = this.pageContext.getOut();
/*    */     try {
/* 13 */       out.println("foo");
/*    */     }
/*    */     catch (IOException e) {
/* 16 */       throw new JspException(e.getMessage());
/*    */     }
/*    */ 
/* 19 */     return 0;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.FooTag
 * JD-Core Version:    0.5.4
 */