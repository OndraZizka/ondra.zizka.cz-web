/*    */ package com.jspbook;
/*    */ 
/*    */ public class Link
/*    */ {
/*    */   protected int count;
/*    */   protected String url;
/*    */   protected long lastVisited;
/*    */ 
/*    */   public int getCount()
/*    */   {
/*  9 */     return this.count;
/*    */   }
/*    */   public String getUrl() {
/* 12 */     return this.url;
/*    */   }
/*    */   public long getLastVisited() {
/* 15 */     return this.lastVisited;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.Link
 * JD-Core Version:    0.5.4
 */