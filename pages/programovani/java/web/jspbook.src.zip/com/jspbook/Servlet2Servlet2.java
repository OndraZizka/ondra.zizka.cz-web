/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class Servlet2Servlet2 extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 12 */     response.setContentType("text/html");
/*    */ 
/* 14 */     PrintWriter out = response.getWriter();
/* 15 */     out.println("<html>");
/* 16 */     out.println("<head>");
/* 17 */     out.println("<title>Servlet #2</title>");
/* 18 */     out.println("</head>");
/* 19 */     out.println("<body>");
/* 20 */     out.println("<h1>Servlet #2</h1>");
/* 21 */     String value = (String)request.getAttribute("value");
/* 22 */     if ((value != null) && (!value.equals(""))) {
/* 23 */       out.print("Servlet #1 passed a String object via ");
/* 24 */       out.print("request scope. The value of the String is: ");
/* 25 */       out.println("<b>" + value + "</b>.");
/*    */     }
/*    */     else {
/* 28 */       out.println("No value passed!");
/*    */     }
/* 30 */     out.println("</body>");
/* 31 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.Servlet2Servlet2
 * JD-Core Version:    0.5.4
 */