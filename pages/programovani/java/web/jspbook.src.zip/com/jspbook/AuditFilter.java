/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class AuditFilter
/*    */   implements Filter
/*    */ {
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 12 */     Logger logger = SiteLogger.getLogger();
/* 13 */     AuditRequestWrapper wrappedRequest = 
/* 14 */       new AuditRequestWrapper(logger, (HttpServletRequest)req);
/* 15 */     chain.doFilter(wrappedRequest, res);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.AuditFilter
 * JD-Core Version:    0.5.4
 */