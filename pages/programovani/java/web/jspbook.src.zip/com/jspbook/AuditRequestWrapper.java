/*    */ package com.jspbook;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ 
/*    */ class AuditRequestWrapper extends HttpServletRequestWrapper
/*    */ {
/*    */   Logger logger;
/*    */ 
/*    */   public AuditRequestWrapper(Logger logger, HttpServletRequest request)
/*    */   {
/* 12 */     super(request);
/* 13 */     this.logger = logger;
/*    */   }
/*    */ 
/*    */   public String getContentType() {
/* 17 */     String contentType = super.getContentType();
/* 18 */     this.logger.fine("ContentType[ " + contentType + "]");
/* 19 */     return contentType;
/*    */   }
/*    */ 
/*    */   public int getContentLength() {
/* 23 */     int contentLength = super.getContentLength();
/* 24 */     this.logger.fine("getContentLength[" + contentLength + "]");
/* 25 */     return contentLength;
/*    */   }
/*    */ 
/*    */   public long getDateHeader(String s) {
/* 29 */     long date = super.getDateHeader(s);
/* 30 */     this.logger.fine("getDateHeader[" + s + ": " + date + "]");
/* 31 */     return date;
/*    */   }
/*    */ 
/*    */   public String getHeader(String s) {
/* 35 */     String header = super.getHeader(s);
/* 36 */     this.logger.fine("getHeader[" + s + ": " + header + "]");
/* 37 */     return header;
/*    */   }
/*    */ 
/*    */   public int getIntHeader(String s) {
/* 41 */     int header = super.getIntHeader(s);
/* 42 */     this.logger.fine("getIntHeader[" + s + ": " + header + "]");
/* 43 */     return header;
/*    */   }
/*    */ 
/*    */   public String getQueryString() {
/* 47 */     String queryString = super.getQueryString();
/* 48 */     this.logger.fine("getQueryString[" + queryString + "]");
/* 49 */     return queryString;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.AuditRequestWrapper
 * JD-Core Version:    0.5.4
 */