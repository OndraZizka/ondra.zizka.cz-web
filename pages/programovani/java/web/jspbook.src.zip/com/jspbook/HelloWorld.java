/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class HelloWorld extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 13 */     response.setContentType("text/html");
/* 14 */     PrintWriter out = response.getWriter();
/*    */ 
/* 16 */     out.println("<html>");
/* 17 */     out.println("<head>");
/* 18 */     out.println("<title>Hello World!</title>");
/* 19 */     out.println("</head>");
/* 20 */     out.println("<body>");
/* 21 */     out.println("<h1>Hello World!</h1>");
/* 22 */     out.println("</body>");
/* 23 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.HelloWorld
 * JD-Core Version:    0.5.4
 */