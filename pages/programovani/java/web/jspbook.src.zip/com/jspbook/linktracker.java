/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class linktracker
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 12 */     Link[] requests = LinkTrackerFilter.getRequests();
/* 13 */     request.setAttribute("requests", requests);
/* 14 */     Link[] responses = LinkTrackerFilter.getResponses();
/* 15 */     request.setAttribute("responses", responses);
/* 16 */     Link[] referers = LinkTrackerFilter.getReferers();
/* 17 */     request.setAttribute("referers", referers);
/*    */ 
/* 19 */     return true;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.linktracker
 * JD-Core Version:    0.5.4
 */