/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Calendar;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class addfeedback
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 16 */     String feedback = request.getParameter("feedback");
/* 17 */     String author = request.getParameter("author");
/* 18 */     String email = request.getParameter("email");
/*    */ 
/* 20 */     if (feedback == null) {
/* 21 */       return true;
/*    */     }
/*    */     try
/*    */     {
/* 25 */       InitialContext ctx = new InitialContext();
/* 26 */       DataSource ds = 
/* 27 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 28 */       Connection conn = ds.getConnection();
/*    */       try {
/* 30 */         Statement statement = conn.createStatement();
/*    */ 
/* 32 */         ServletContext sc = 
/* 33 */           request.getSession().getServletContext();
/* 34 */         String dir = sc.getRealPath("/WEB-INF/feedback");
/* 35 */         new File(dir).mkdirs();
/* 36 */         long l = Calendar.getInstance().getTimeInMillis();
/*    */ 
/* 39 */         FileWriter fw = new FileWriter(dir + "/" + l + ".jsp");
/* 40 */         fw.write("<p class=\"title\">" + author + " (" + email + ")</p>");
/* 41 */         fw.write("<p class=\"news-content\">");
/* 42 */         fw.write(feedback);
/* 43 */         fw.write("</p>");
/* 44 */         fw.flush();
/* 45 */         fw.close();
/*    */ 
/* 47 */         statement.executeQuery(
/* 48 */           "insert into feedback values (" + l + ",0)");
/* 49 */         response.sendRedirect("index.jsp");
/*    */       } catch (Exception e) {
/* 51 */         throw new ServletException(e);
/*    */       } finally {
/* 53 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 56 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 59 */       throw new ServletException(e);
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.addfeedback
 * JD-Core Version:    0.5.4
 */