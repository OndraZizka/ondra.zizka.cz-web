/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class update
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 18 */     String table = request.getParameter("table");
/* 19 */     if (table == null) {
/* 20 */       response.sendRedirect("index.jsp");
/*    */     }
/* 22 */     else if ((!table.equals("faq")) && (!table.equals("news")) && 
/* 23 */       (!table.equals("errata")) && (!table.equals("feedback"))) {
/* 24 */       response.sendRedirect("index.jsp");
/* 25 */       return false;
/*    */     }
/*    */     try
/*    */     {
/* 29 */       InitialContext ctx = new InitialContext();
/* 30 */       DataSource ds = 
/* 31 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 32 */       Connection conn = ds.getConnection();
/*    */       try {
/* 34 */         Statement statement = conn.createStatement();
/*    */ 
/* 37 */         for (int i = 0; request.getParameter("date" + i) != null; ++i)
/*    */         {
/* 39 */           String date = request.getParameter("date" + i);
/* 40 */           String text = request.getParameter("text" + i);
/* 41 */           String visible = request.getParameter("visible" + i);
/*    */ 
/* 44 */           String delete = request.getParameter("delete" + i);
/* 45 */           if ((delete != null) && (!delete.equals(""))) {
/* 46 */             ServletContext sc = 
/* 47 */               request.getSession().getServletContext();
/* 48 */             String f = 
/* 49 */               sc.getRealPath("/WEB-INF/news/" + date + ".jsp");
/* 50 */             new File(f).delete();
/* 51 */             statement.executeQuery(
/* 52 */               "delete from " + table + " where ts=" + date);
/*    */           }
/*    */           else
/*    */           {
/* 56 */             ServletContext sc = 
/* 57 */               request.getSession().getServletContext();
/* 58 */             String dir = sc.getRealPath("/WEB-INF/" + table);
/*    */ 
/* 61 */             FileWriter fw = new FileWriter(dir + "/" + date + ".jsp");
/* 62 */             fw.write(text);
/* 63 */             fw.flush();
/* 64 */             fw.close();
/*    */ 
/* 66 */             if ((visible != null) && (visible.equals("on")))
/* 67 */               visible = "1";
/*    */             else {
/* 69 */               visible = "0";
/*    */             }
/* 71 */             statement.executeQuery(
/* 72 */               "update " + table + " set visible=" + visible + " where ts=" + date);
/*    */           }
/*    */         }
/* 74 */         response.sendRedirect("index.jsp");
/*    */       } catch (Exception e) {
/* 76 */         throw new ServletException(e);
/*    */       } finally {
/* 78 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 81 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 84 */       throw new ServletException(e);
/*    */     }
/* 86 */     return false;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.update
 * JD-Core Version:    0.5.4
 */