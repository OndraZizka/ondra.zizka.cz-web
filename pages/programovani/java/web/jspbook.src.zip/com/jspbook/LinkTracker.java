/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Date;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class LinkTracker extends HttpServlet
/*    */ {
/*  9 */   private static Hashtable links = new Hashtable();
/*    */   String tstamp;
/*    */ 
/*    */   public LinkTracker()
/*    */   {
/* 13 */     this.tstamp = new Date().toString();
/*    */   }
/*    */ 
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 20 */     String link = request.getParameter("link");
/* 21 */     if ((link != null) && (!link.equals(""))) {
/* 22 */       synchronized (links) {
/* 23 */         Integer count = (Integer)links.get(link);
/* 24 */         if (count == null) {
/* 25 */           links.put(link, new Integer(1));
/*    */         }
/*    */         else {
/* 28 */           links.put(link, new Integer(1 + count.intValue()));
/*    */         }
/*    */       }
/* 31 */       response.sendRedirect(link);
/*    */     }
/*    */     else {
/* 34 */       response.setContentType("text/html");
/* 35 */       PrintWriter out = response.getWriter();
/* 36 */       request.getSession();
/* 37 */       out.println("<html>");
/* 38 */       out.println("<head>");
/* 39 */       out.println("<title>Links Tracker Servlet</title>");
/* 40 */       out.println("</head>");
/* 41 */       out.println("<body>");
/* 42 */       out.println("<p>Links Tracked Since");
/* 43 */       out.println(this.tstamp + ":</p>");
/* 44 */       if (links.size() != 0) {
/* 45 */         Enumeration enum = links.keys();
/* 46 */         while (enum.hasMoreElements()) {
/* 47 */           String key = (String)enum.nextElement();
/* 48 */           int count = ((Integer)links.get(key)).intValue();
/* 49 */           out.println(key + " : " + count + " visits<br>");
/*    */         }
/*    */       }
/*    */       else {
/* 53 */         out.println("No links have been tracked!<br>");
/*    */       }
/* 55 */       out.println("</body>");
/* 56 */       out.println("</html>");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
/*    */   {
/* 62 */     doGet(request, response);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkTracker
 * JD-Core Version:    0.5.4
 */