/*    */ package com.jspbook;
/*    */ 
/*    */ public class LinkBean
/*    */ {
/*  4 */   protected String title = null;
/*  5 */   protected String url = null;
/*  6 */   protected String desc = null;
/*    */ 
/*  8 */   public String getTitle() { return this.title; } 
/*  9 */   public void setTitle(String title) { this.title = title; } 
/*    */   public String getUrl() {
/* 11 */     return this.url; } 
/* 12 */   public void setUrl(String url) { this.url = url; } 
/*    */   public String getDescription() {
/* 14 */     return this.desc; } 
/* 15 */   public void setDescription(String desc) { this.desc = desc; }
/*    */ 
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkBean
 * JD-Core Version:    0.5.4
 */