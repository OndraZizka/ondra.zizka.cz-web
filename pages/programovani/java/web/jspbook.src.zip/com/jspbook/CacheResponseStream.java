/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ 
/*    */ public class CacheResponseStream extends ServletOutputStream
/*    */ {
/*  9 */   protected boolean closed = false;
/*    */ 
/* 11 */   protected ServletOutputStream output = null;
/*    */ 
/* 13 */   protected OutputStream cache = null;
/*    */ 
/*    */   public CacheResponseStream(OutputStream cache) throws IOException
/*    */   {
/* 17 */     this.closed = false;
/* 18 */     this.cache = cache;
/*    */   }
/*    */ 
/*    */   public void close() throws IOException {
/* 22 */     this.cache.close();
/* 23 */     this.closed = true;
/*    */   }
/*    */ 
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 30 */     this.cache.flush();
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException {
/* 34 */     if (this.closed) {
/* 35 */       throw new IOException("Cannot write to a closed output stream");
/*    */     }
/* 37 */     this.cache.write((byte)b);
/* 38 */     System.out.print((char)b);
/*    */   }
/*    */ 
/*    */   public void write(byte[] b) throws IOException {
/* 42 */     write(b, 0, b.length);
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 46 */     if (this.closed) {
/* 47 */       throw new IOException("Cannot write to a closed output stream");
/*    */     }
/* 49 */     this.cache.write(b, off, len);
/*    */   }
/*    */ 
/*    */   public void println(String s)
/*    */     throws IOException
/*    */   {
/* 58 */     write(s.getBytes());
/*    */   }
/*    */ 
/*    */   public void print(String s) throws IOException {
/* 62 */     write(s.getBytes());
/*    */   }
/*    */ 
/*    */   public boolean closed() {
/* 66 */     return this.closed;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.CacheResponseStream
 * JD-Core Version:    0.5.4
 */