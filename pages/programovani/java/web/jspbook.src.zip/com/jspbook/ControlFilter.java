/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ControlFilter
/*    */   implements Filter
/*    */ {
/* 13 */   protected FilterConfig config = null;
/*    */ 
/*    */   public void init(FilterConfig filterConfig) {
/* 16 */     this.config = filterConfig;
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException
/*    */   {
/* 21 */     if (!req instanceof HttpServletRequest) {
/* 22 */       throw new ServletException("Filter requires a HTTP request.");
/*    */     }
/*    */ 
/* 26 */     HttpServletRequest request = (HttpServletRequest)req;
/* 27 */     HttpServletResponse response = (HttpServletResponse)res;
/* 28 */     String uri = request.getRequestURI();
/*    */ 
/* 31 */     if ((uri == null) || (uri.equals("")) || (uri.equals("/"))) {
/* 32 */       response.sendRedirect("http://www.jspbook.com/index.jsp");
/* 33 */       return;
/*    */     }
/*    */ 
/* 36 */     int start = uri.lastIndexOf("/") + 1;
/* 37 */     int stop = uri.lastIndexOf(".");
/* 38 */     String name = "index";
/*    */ 
/* 40 */     if (start < stop) {
/* 41 */       name = uri.substring(start, stop);
/*    */     }
/* 43 */     boolean doFilter = true;
/*    */     try
/*    */     {
/* 47 */       Object o = Class.forName("com.jspbook." + name).newInstance();
/* 48 */       if (!o instanceof Control) {
/* 49 */         throw new ServletException("Class com.jspbook." + name + " does not implement com.jspbook.Control");
/*    */       }
/*    */ 
/* 52 */       Control control = (Control)o;
/* 53 */       doFilter = control.doLogic(request, response);
/*    */     }
/*    */     catch (ClassNotFoundException localClassNotFoundException)
/*    */     {
/*    */     }
/*    */     catch (InstantiationException e) {
/* 59 */       throw new ServletException(e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 62 */       throw new ServletException(e);
/*    */     }
/*    */ 
/* 66 */     if (doFilter)
/* 67 */       chain.doFilter(request, response);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ControlFilter
 * JD-Core Version:    0.5.4
 */