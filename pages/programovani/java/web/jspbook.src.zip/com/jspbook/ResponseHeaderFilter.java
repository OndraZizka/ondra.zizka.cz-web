/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ResponseHeaderFilter
/*    */   implements Filter
/*    */ {
/*    */   FilterConfig fc;
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */ 
/* 17 */     for (Enumeration e = this.fc.getInitParameterNames(); e.hasMoreElements(); ) {
/* 18 */       String headerName = (String)e.nextElement();
/* 19 */       response.addHeader(headerName, this.fc.getInitParameter(headerName));
/*    */     }
/*    */ 
/* 23 */     chain.doFilter(req, response);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig) {
/* 27 */     this.fc = filterConfig;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 31 */     this.fc = null;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ResponseHeaderFilter
 * JD-Core Version:    0.5.4
 */