/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import javax.servlet.jsp.JspContext;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.tagext.SimpleTagSupport;
/*    */ 
/*    */ public class FormatDateTag extends SimpleTagSupport
/*    */ {
/*    */   private String format;
/*    */ 
/*    */   public void setFormat(String format)
/*    */   {
/* 13 */     this.format = format;
/*    */   }
/*    */ 
/*    */   public void doTag() throws JspException, IOException {
/* 17 */     JspWriter out = getJspContext().getOut();
/* 18 */     if (this.format != null) {
/* 19 */       SimpleDateFormat sdf = new SimpleDateFormat(this.format);
/* 20 */       out.println(sdf.format(new Date()));
/*    */     }
/*    */     else {
/* 23 */       out.println(new Date().toString());
/*    */     }
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.FormatDateTag
 * JD-Core Version:    0.5.4
 */