/*   */ package com.jspbook;
/*   */ 
/*   */ public class AdminException extends RuntimeException
/*   */ {
/*   */   public AdminException(String description)
/*   */   {
/* 7 */     super(description);
/*   */   }
/*   */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.AdminException
 * JD-Core Version:    0.5.4
 */