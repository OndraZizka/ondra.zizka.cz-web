/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ShowParameters extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     response.setContentType("text/html");
/* 15 */     PrintWriter out = response.getWriter();
/* 16 */     out.println("<html>");
/* 17 */     out.println("<head>");
/* 18 */     out.println("<title>Request HTTP Parameters Sent</title>");
/* 19 */     out.println("</head>");
/* 20 */     out.println("<body>");
/* 21 */     out.println("<p>Parameters sent with request:</p>");
/* 22 */     Enumeration enum = request.getParameterNames();
/* 23 */     while (enum.hasMoreElements()) {
/* 24 */       String pName = (String)enum.nextElement();
/* 25 */       String[] pValues = request.getParameterValues(pName);
/* 26 */       out.print("<b>" + pName + "</b>: ");
/* 27 */       for (int i = 0; i < pValues.length; ++i) {
/* 28 */         out.print(pValues[i]);
/*    */       }
/* 30 */       out.print("<br>");
/*    */     }
/* 32 */     out.println("</body>");
/* 33 */     out.println("</html>");
/*    */   }
/*    */ 
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
/*    */   {
/* 38 */     doGet(request, response);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ShowParameters
 * JD-Core Version:    0.5.4
 */