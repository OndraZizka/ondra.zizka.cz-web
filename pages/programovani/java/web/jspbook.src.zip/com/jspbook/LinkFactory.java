/*    */ package com.jspbook;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import java.util.LinkedList;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class LinkFactory
/*    */ {
/*    */   public static void create(LinkBean[] links)
/*    */     throws Exception
/*    */   {
/* 10 */     InitialContext ctx = new InitialContext();
/* 11 */     DataSource ds = 
/* 12 */       (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook");
/* 13 */     Connection conn = ds.getConnection();
/* 14 */     Statement statement = conn.createStatement();
/*    */     try {
/* 16 */       for (int i = 0; i < links.length; ++i) {
/* 17 */         LinkBean link = links[i];
/* 18 */         if (link != null) {
/* 19 */           if (link.getUrl() == null) {
/* 20 */             throw new Exception("Link #" + i + " has null for url value!");
/*    */           }
/* 22 */           statement.executeQuery("INSERT INTO LINK VALUES('" + link.getUrl() + "', '" + link.getTitle() + "', '" + link.getDescription() + "')");
/*    */         }
/*    */       }
/*    */     } finally {
/* 26 */       statement.close();
/* 27 */       conn.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static LinkBean[] read(String index) throws Exception {
/* 32 */     String sql = "SELECT * FROM LINK";
/* 33 */     if (index != null) {
/* 34 */       sql = "SELECT l.url, l.title, l.description FROM LINK l, URI u WHERE l.url = u.url AND u.uri = '" + index + "'";
/*    */     }
/* 36 */     InitialContext ctx = new InitialContext();
/* 37 */     DataSource ds = 
/* 38 */       (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook");
/* 39 */     Connection conn = ds.getConnection();
/* 40 */     Statement statement = conn.createStatement();
/* 41 */     LinkedList ll = new LinkedList();
/*    */     try {
/* 43 */       ResultSet rs = statement.executeQuery(sql);
/* 44 */       while (rs.next()) {
/* 45 */         LinkBean link = new LinkBean();
/* 46 */         link.setUrl(rs.getString(1));
/* 47 */         link.setTitle(rs.getString(2));
/* 48 */         link.setDescription(rs.getString(3));
/* 49 */         ll.add(link);
/*    */       }
/* 51 */       LinkBean[] links = new LinkBean[ll.size()];
/* 52 */       for (int i = 0; ll.size() > 0; ++i) {
/* 53 */         links[i] = ((LinkBean)ll.remove(0));
/*    */       }
/* 55 */       return links;
/*    */     }
/*    */     finally {
/* 58 */       conn.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void update(LinkBean[] links) throws Exception
/*    */   {
/* 64 */     if ((links == null) || (links.length == 0)) return;
/* 65 */     InitialContext ctx = new InitialContext();
/* 66 */     DataSource ds = 
/* 67 */       (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook");
/* 68 */     Connection conn = ds.getConnection();
/* 69 */     Statement statement = conn.createStatement();
/* 70 */     LinkedList ll = new LinkedList();
/*    */     try {
/* 72 */       for (int i = 0; i < links.length; ++i) {
/* 73 */         LinkBean link = links[i];
/* 74 */         if (link.getUrl() != null)
/* 75 */           statement.executeQuery("UPDATE LINK SET title='" + link.getTitle() + "', description='" + link.getDescription() + "' WHERE url='" + link.getUrl() + "'");
/*    */       }
/*    */     }
/*    */     finally {
/* 79 */       conn.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void delete(LinkBean[] links) throws Exception
/*    */   {
/* 85 */     if ((links == null) || (links.length == 0)) return;
/* 86 */     InitialContext ctx = new InitialContext();
/* 87 */     DataSource ds = 
/* 88 */       (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook");
/* 89 */     Connection conn = ds.getConnection();
/* 90 */     Statement statement = conn.createStatement();
/* 91 */     LinkedList ll = new LinkedList();
/*    */     try {
/* 93 */       for (int i = 0; i < links.length; ++i) {
/* 94 */         LinkBean link = links[i];
/* 95 */         if (link.getUrl() != null)
/* 96 */           statement.executeQuery("DELETE FROM LINK WHERE url='" + link.getUrl() + "'");
/*    */       }
/*    */     }
/*    */     finally {
/* 100 */       conn.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkFactory
 * JD-Core Version:    0.5.4
 */