/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.jsp.JspContext;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspWriter;
/*    */ import javax.servlet.jsp.tagext.SimpleTagSupport;
/*    */ 
/*    */ public class HelloSimpleTag extends SimpleTagSupport
/*    */ {
/*    */   public void doTag()
/*    */     throws JspException, IOException
/*    */   {
/* 10 */     JspWriter out = getJspContext().getOut();
/* 11 */     out.println("Hello World!");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.HelloSimpleTag
 * JD-Core Version:    0.5.4
 */