/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class MCTemplateFilter
/*    */   implements Filter
/*    */ {
/*  9 */   FilterConfig fc = null;
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 14 */     HttpServletRequest request = (HttpServletRequest)req;
/* 15 */     String uri = request.getRequestURI();
/* 16 */     String client = "HTML";
/* 17 */     if (uri.endsWith("xhtml")) {
/* 18 */       client = "XHTML";
/*    */     }
/*    */ 
/* 22 */     HashMap user = new HashMap();
/* 23 */     user.put("name", "Bruce");
/* 24 */     request.setAttribute("user", user);
/*    */ 
/* 26 */     ServletContext sc = this.fc.getServletContext();
/* 27 */     sc.getRequestDispatcher("/mc/MCexample" + client + ".jsp").forward(request, res);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig filterConfig)
/*    */   {
/* 32 */     this.fc = filterConfig;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 36 */     this.fc = null;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.MCTemplateFilter
 * JD-Core Version:    0.5.4
 */