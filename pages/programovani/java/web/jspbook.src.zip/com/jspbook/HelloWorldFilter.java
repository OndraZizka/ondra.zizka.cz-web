/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class HelloWorldFilter
/*    */   implements Filter
/*    */ {
/*    */   public void init(FilterConfig config)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain filter)
/*    */     throws IOException, ServletException
/*    */   {
/* 18 */     HttpServletRequest request = (HttpServletRequest)req;
/* 19 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */ 
/* 21 */     response.setContentType("text/html");
/* 22 */     PrintWriter out = response.getWriter();
/* 23 */     out.println("<html>");
/* 24 */     out.println("<head>");
/* 25 */     out.println("<title>Hello World!</title>");
/* 26 */     out.println("</head>");
/* 27 */     out.println("<body>");
/* 28 */     out.println("<h1>Hello World!</h1>");
/* 29 */     out.println("</body>");
/* 30 */     out.println("</html>");
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.HelloWorldFilter
 * JD-Core Version:    0.5.4
 */