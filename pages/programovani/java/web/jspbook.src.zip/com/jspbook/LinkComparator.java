/*    */ package com.jspbook;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class LinkComparator
/*    */   implements Comparator
/*    */ {
/*    */   public int compare(Object o1, Object o2)
/*    */   {
/*  7 */     Link l1 = (Link)o1;
/*  8 */     Link l2 = (Link)o2;
/*  9 */     return l2.getCount() - l1.getCount();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o1, Object o2) {
/* 13 */     Link l1 = (Link)o1;
/* 14 */     Link l2 = (Link)o2;
/*    */ 
/* 16 */     return l2.getCount() == l1.getCount();
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkComparator
 * JD-Core Version:    0.5.4
 */