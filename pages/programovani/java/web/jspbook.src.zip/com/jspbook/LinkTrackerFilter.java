/*     */ package com.jspbook;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class LinkTrackerFilter
/*     */   implements Filter
/*     */ {
/*   9 */   long startDate = System.currentTimeMillis();
/*     */ 
/*  11 */   static int count = 0;
/*     */ 
/*  13 */   public static Hashtable requests = new Hashtable();
/*     */ 
/*  15 */   public static Hashtable responses = new Hashtable();
/*     */ 
/*  17 */   public static Hashtable referers = new Hashtable();
/*     */ 
/*  19 */   FilterConfig fc = null;
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException
/*     */   {
/*  23 */     HttpServletRequest request = (HttpServletRequest)req;
/*  24 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */ 
/*  26 */     String uri = request.getRequestURI();
/*  27 */     String path = request.getContextPath();
/*     */ 
/*  30 */     String turi = uri.substring(path.length(), uri.length());
/*     */ 
/*  33 */     if (turi.startsWith("/redirect")) {
/*  34 */       String url = request.getParameter("url");
/*     */ 
/*  36 */       if ((url == null) || (url.equals(""))) {
/*  37 */         response.sendRedirect(path);
/*  38 */         return;
/*     */       }
/*  40 */       Link l = new Link();
/*  41 */       l.url = url;
/*  42 */       l.count = 1;
/*  43 */       l.lastVisited = Calendar.getInstance().getTimeInMillis();
/*  44 */       if (responses.get(l.url) != null) {
/*  45 */         l = (Link)responses.get(l.url);
/*  46 */         l.count += 1;
/*     */       } else {
/*  48 */         responses.put(l.url, l);
/*     */       }
/*     */ 
/*  51 */       response.sendRedirect(url);
/*  52 */       return;
/*     */     }
/*     */ 
/*  56 */     if ((uri.endsWith(".js")) || (uri.endsWith(".css")) || (uri.endsWith(".gif")) || 
/*  57 */       (uri.endsWith(".png")) || (uri.endsWith(".jpg")) || 
/*  58 */       (uri.endsWith(".jpeg"))) {
/*  59 */       chain.doFilter(req, res);
/*  60 */       return;
/*     */     }
/*     */ 
/*  65 */     Link l = new Link();
/*  66 */     l.url = uri;
/*  67 */     l.count = 1;
/*  68 */     l.lastVisited = Calendar.getInstance().getTimeInMillis();
/*  69 */     if (requests.get(l.url) != null) {
/*  70 */       l = (Link)requests.get(l.url);
/*  71 */       l.count += 1;
/*     */     } else {
/*  73 */       requests.put(l.url, l);
/*     */     }
/*     */ 
/*  78 */     String referer = request.getHeader("referer");
/*  79 */     if ((referer != null) && (!referer.equals(""))) {
/*  80 */       Link l = new Link();
/*  81 */       l.url = referer;
/*  82 */       l.count = 1;
/*  83 */       l.lastVisited = Calendar.getInstance().getTimeInMillis();
/*  84 */       if (referers.get(l.url) != null) {
/*  85 */         l = (Link)referers.get(l.url);
/*  86 */         l.count += 1;
/*     */       } else {
/*  88 */         referers.put(l.url, l);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  93 */     count += 1;
/*  94 */     chain.doFilter(req, res);
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig filterConfig) {
/*  98 */     this.fc = filterConfig;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 102 */     this.fc = null;
/*     */   }
/*     */ 
/*     */   public int getCount()
/*     */   {
/* 107 */     return count;
/*     */   }
/*     */ 
/*     */   public static Link[] getRequests() {
/* 111 */     Collection c = requests.values();
/* 112 */     Vector v = new Vector(c);
/* 113 */     Collections.sort(v, new LinkComparator());
/* 114 */     return (Link[])v.toArray(new Link[0]);
/*     */   }
/*     */ 
/*     */   public static Link[] getResponses() {
/* 118 */     Collection c = responses.values();
/* 119 */     Vector v = new Vector(c);
/* 120 */     Collections.sort(v, new LinkComparator());
/* 121 */     return (Link[])v.toArray(new Link[0]);
/*     */   }
/*     */ 
/*     */   public static Link[] getReferers() {
/* 125 */     Collection c = referers.values();
/* 126 */     Vector v = new Vector(c);
/* 127 */     Collections.sort(v, new LinkComparator());
/* 128 */     return (Link[])v.toArray(new Link[0]);
/*     */   }
/*     */ 
/*     */   public long getDays() {
/* 132 */     long a = this.startDate;
/* 133 */     long b = System.currentTimeMillis();
/* 134 */     long between = b - a;
/*     */ 
/* 136 */     long days = between / 86400000L;
/* 137 */     if (days < 1L)
/* 138 */       days = 1L;
/* 139 */     return days;
/*     */   }
/*     */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.LinkTrackerFilter
 * JD-Core Version:    0.5.4
 */