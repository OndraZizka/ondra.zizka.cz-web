/*    */ package com.jspbook;
/*    */ 
/*    */ import com.sun.image.codec.jpeg.JPEGCodec;
/*    */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class DynamicImage extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 17 */     response.setContentType("image/jpeg");
/*    */ 
/* 20 */     int width = 200;
/* 21 */     int height = 30;
/* 22 */     BufferedImage image = new BufferedImage(
/* 23 */       width, height, 1);
/*    */ 
/* 26 */     Graphics2D g = (Graphics2D)image.getGraphics();
/*    */ 
/* 29 */     g.setColor(Color.gray);
/* 30 */     g.fillRect(0, 0, width, height);
/*    */ 
/* 33 */     g.setColor(Color.white);
/* 34 */     g.setFont(new Font("Dialog", 0, 14));
/* 35 */     g.drawString("http://www.jspbook.com", 10, height / 2 + 4);
/*    */ 
/* 38 */     g.setColor(Color.black);
/* 39 */     g.drawRect(0, 0, width - 1, height - 1);
/*    */ 
/* 42 */     g.dispose();
/*    */ 
/* 45 */     ServletOutputStream sos = response.getOutputStream();
/* 46 */     JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(sos);
/* 47 */     encoder.encode(image);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.DynamicImage
 * JD-Core Version:    0.5.4
 */