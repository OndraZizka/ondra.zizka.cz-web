/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.tagext.JspFragment;
/*    */ import javax.servlet.jsp.tagext.SimpleTagSupport;
/*    */ 
/*    */ public class BodySimpleTag extends SimpleTagSupport
/*    */ {
/*    */   public void doTag()
/*    */     throws JspException, IOException
/*    */   {
/* 11 */     getJspBody().invoke(null);
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.BodySimpleTag
 * JD-Core Version:    0.5.4
 */