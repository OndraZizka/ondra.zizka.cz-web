/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Locale;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class SimpleI18nFilter
/*    */   implements Filter
/*    */ {
/*  9 */   protected static FilterConfig config = null;
/*    */ 
/*    */   public void init(FilterConfig filterConfig) {
/* 12 */     config = filterConfig;
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 16 */     config = null;
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 23 */     if (res instanceof HttpServletResponse) {
/* 24 */       HttpServletRequest request = (HttpServletRequest)req;
/* 25 */       HttpServletResponse response = (HttpServletResponse)res;
/*    */ 
/* 27 */       String uri = request.getRequestURI();
/* 28 */       if (uri.endsWith("/")) {
/* 29 */         chain.doFilter(request, response);
/* 30 */         return;
/*    */       }
/* 32 */       String path = request.getContextPath();
/* 33 */       uri = uri.substring(path.length(), uri.length());
/* 34 */       uri = getLanguage(uri, request);
/* 35 */       ServletContext sc = config.getServletContext();
/* 36 */       sc.getRequestDispatcher(uri).forward(request, response);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static String getLanguage(String uri, HttpServletRequest request)
/*    */   {
/* 42 */     ServletContext sc = config.getServletContext();
/* 43 */     Enumeration enum = request.getLocales();
/* 44 */     String postfix = 
/* 45 */       uri.substring(uri.lastIndexOf("."), uri.length());
/* 46 */     String temp = uri.substring(0, uri.length() - postfix.length());
/* 47 */     while (enum.hasMoreElements()) {
/* 48 */       Locale l = (Locale)enum.nextElement();
/* 49 */       String lang = l.getISO3Language();
/* 50 */       String file = sc.getRealPath(temp + "-" + lang + postfix);
/* 51 */       System.out.println("Trying: " + file);
/* 52 */       File f = new File(file);
/* 53 */       if (f.exists()) {
/* 54 */         return temp + "-" + lang + postfix;
/*    */       }
/*    */     }
/* 57 */     return uri;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.SimpleI18nFilter
 * JD-Core Version:    0.5.4
 */