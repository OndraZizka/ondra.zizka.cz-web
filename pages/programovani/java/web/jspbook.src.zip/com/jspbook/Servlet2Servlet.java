/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class Servlet2Servlet extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 12 */     response.setContentType("text/html");
/*    */ 
/* 14 */     String param = request.getParameter("value");
/* 15 */     if ((param != null) && (!param.equals(""))) {
/* 16 */       request.setAttribute("value", param);
/* 17 */       RequestDispatcher rd = request.getRequestDispatcher("/Servlet2Servlet2");
/* 18 */       rd.forward(request, response);
/* 19 */       return;
/*    */     }
/*    */ 
/* 22 */     PrintWriter out = response.getWriter();
/* 23 */     out.println("<html>");
/* 24 */     out.println("<head>");
/* 25 */     out.println("<title>Servlet #1</title>");
/* 26 */     out.println("</head>");
/* 27 */     out.println("<body>");
/* 28 */     out.println("<h1>A form from Servlet #1</h1>");
/* 29 */     out.println("<form>");
/* 30 */     out.println("Enter a value to send to Servlet #2.");
/* 31 */     out.println("<input name=\"value\"><br>");
/* 32 */     out.print("<input type=\"submit\" ");
/* 33 */     out.println("value=\"Send to Servlet #2\">");
/* 34 */     out.println("</form>");
/* 35 */     out.println("</body>");
/* 36 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.Servlet2Servlet
 * JD-Core Version:    0.5.4
 */