/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ShowHeaders extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 13 */     response.setContentType("text/html");
/* 14 */     PrintWriter out = response.getWriter();
/* 15 */     out.println("<html>");
/* 16 */     out.println("<head>");
/* 17 */     out.println("<title>Request's HTTP Headers</title>");
/* 18 */     out.println("</head>");
/* 19 */     out.println("<body>");
/* 20 */     out.println("<p>HTTP headers sent by your client:</p>");
/* 21 */     Enumeration enum = request.getHeaderNames();
/* 22 */     while (enum.hasMoreElements()) {
/* 23 */       String headerName = (String)enum.nextElement();
/* 24 */       String headerValue = request.getHeader(headerName);
/* 25 */       out.print("<b>" + headerName + "</b>: ");
/* 26 */       out.println(headerValue + "<br>");
/*    */     }
/* 28 */     out.println("</body>");
/* 29 */     out.println("</html>");
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.ShowHeaders
 * JD-Core Version:    0.5.4
 */