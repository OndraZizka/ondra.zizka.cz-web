/*    */ package com.jspbook;
/*    */ 
/*    */ public class User
/*    */ {
/*  4 */   protected String name = null;
/*  5 */   protected String password = null;
/*    */ 
/*    */   public String getName() {
/*  8 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 11 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getPassword() {
/* 15 */     return this.password;
/*    */   }
/*    */   public void setPassword(String password) {
/* 18 */     this.password = password;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.User
 * JD-Core Version:    0.5.4
 */