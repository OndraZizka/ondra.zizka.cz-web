/*    */ package com.jspbook;
/*    */ 
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.sql.Timestamp;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.LinkedList;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class edit
/*    */   implements Control
/*    */ {
/*    */   public boolean doLogic(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 18 */     String table = request.getParameter("table");
/* 19 */     if (table == null) {
/* 20 */       response.sendRedirect("index.jsp");
/* 21 */       return false;
/*    */     }
/* 23 */     if ((!table.equals("faq")) && (!table.equals("news")) && 
/* 24 */       (!table.equals("errata")) && (!table.equals("feedback"))) {
/* 25 */       response.sendRedirect("index.jsp");
/* 26 */       return false;
/*    */     }
/*    */     try
/*    */     {
/* 30 */       InitialContext ctx = new InitialContext();
/* 31 */       DataSource ds = 
/* 32 */         (DataSource)ctx.lookup("java:comp/env/jdbc/jspbook_site");
/* 33 */       Connection conn = ds.getConnection();
/*    */       try {
/* 35 */         Statement statement = conn.createStatement();
/*    */ 
/* 37 */         ResultSet rs = 
/* 38 */           statement.executeQuery("select * from " + table);
/* 39 */         LinkedList dates = new LinkedList();
/* 40 */         LinkedList longs = new LinkedList();
/* 41 */         LinkedList visibles = new LinkedList();
/* 42 */         LinkedList texts = new LinkedList();
/* 43 */         while (rs.next()) {
/* 44 */           long l = rs.getLong(1);
/* 45 */           longs.add(new Long(l).toString());
/* 46 */           Timestamp ts = new Timestamp(l);
/* 47 */           SimpleDateFormat sdf = 
/* 48 */             new SimpleDateFormat("EEE, MMM d, yyyy HH:mm:ss z");
/* 49 */           Date d = new Date(l);
/* 50 */           dates.add(sdf.format(d));
/*    */ 
/* 52 */           if (rs.getBoolean(2))
/* 53 */             visibles.add("checked");
/*    */           else {
/* 55 */             visibles.add("");
/*    */           }
/*    */ 
/* 58 */           ServletContext sc = 
/* 59 */             request.getSession().getServletContext();
/* 60 */           String f = sc.getRealPath(
/* 61 */             "/WEB-INF/" + table + "/" + String.valueOf(l) + ".jsp");
/*    */ 
/* 63 */           StringWriter sw = new StringWriter();
/* 64 */           FileReader fr = new FileReader(f);
/* 65 */           for (int i = fr.read(); i != -1; i = fr.read()) {
/* 66 */             sw.write(i);
/*    */           }
/* 68 */           texts.add(sw.toString());
/*    */         }
/*    */ 
/* 71 */         request.setAttribute("dates", 
/* 72 */           dates.toArray(new String[0]));
/* 73 */         request.setAttribute("longs", 
/* 74 */           longs.toArray(new String[0]));
/* 75 */         request.setAttribute("visibles", 
/* 76 */           visibles.toArray(new String[0]));
/* 77 */         request.setAttribute("texts", 
/* 78 */           texts.toArray(new String[0]));
/*    */       } catch (Exception e) {
/* 80 */         throw new ServletException(e);
/*    */       } finally {
/* 82 */         conn.close();
/*    */       }
/*    */     } catch (SQLException e) {
/* 85 */       throw new ServletException(e);
/*    */     }
/*    */     catch (NamingException e) {
/* 88 */       throw new ServletException(e);
/*    */     }
/* 90 */     return true;
/*    */   }
/*    */ }

/* Location:           T:\_projekty\WicketTry\jspbook.jar
 * Qualified Name:     com.jspbook.edit
 * JD-Core Version:    0.5.4
 */