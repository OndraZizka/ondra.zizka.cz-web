
package com.rapidlime.pohlidame;


import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.logging.*;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.PropertyUtilsBean;


/**
 *
 * @author Ondrej Zizka
 */
public class NullSafePropertyUtils extends PropertyUtils
{

    public static Object getProperty(Object bean, String name)
            throws IllegalAccessException, InvocationTargetException,
            NoSuchMethodException {

        return (NullSafePropertyUtilsBean.getInstance().getProperty(bean, name));

    }

}// class NullSafePropertyUtils
