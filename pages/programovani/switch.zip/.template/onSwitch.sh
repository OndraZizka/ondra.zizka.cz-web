
##  TODO:  Check
if [ ! -x "$1/bin/mvn" ] ; then echo "Maven not found: $1/bin/mvn"; exit 1; fi

echo "export M2_HOME=$1";
export M2_HOME=$1