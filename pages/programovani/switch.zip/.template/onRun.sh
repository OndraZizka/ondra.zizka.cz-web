#####
# Variables are prepended above.
#

#echo "export M2_HOME=../homes/$TOOL_NAME";  # Debug.
#export M2_HOME=../homes/$TOOL_NAME

echo "export M2_HOME=$TOOL_HOME";  # Debug.
export M2_HOME=$TOOL_HOME
