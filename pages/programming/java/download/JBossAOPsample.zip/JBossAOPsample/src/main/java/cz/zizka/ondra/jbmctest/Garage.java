
package cz.zizka.ondra.jbmctest;


/**
 *
 * @author Ondrej Zizka
 */
public class Garage
{

  private Car car;
  public Car getCar() {    return car;  }
  public void setCar( Car car ) {    this.car = car;  }

  public String toString(){
    return "Garage with a car: "+this.getCar();
  }

}// class Garage
