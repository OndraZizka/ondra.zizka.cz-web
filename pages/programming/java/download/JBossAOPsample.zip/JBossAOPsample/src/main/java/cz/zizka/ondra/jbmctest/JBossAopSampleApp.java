package cz.zizka.ondra.jbmctest;

import cz.zizka.ondra.jbmctest.Car;
import java.net.URL;
import org.jboss.dependency.spi.ControllerContext;
import org.jboss.kernel.plugins.bootstrap.basic.BasicBootstrap;
import org.jboss.kernel.plugins.deployment.xml.BasicXMLDeployer;
import org.jboss.kernel.spi.dependency.KernelController;

/**
 * Hello world!
 *
 */
public class JBossAopSampleApp {

  public static void main( String[] args ) throws Throwable
  {
    System.out.println( "Hello Microcontainer!" );

    // Bootstrap.
    BasicBootstrap bootstrap = new BasicBootstrap();
    bootstrap.run();

    BasicXMLDeployer deployer = new BasicXMLDeployer( bootstrap.getKernel() );
		ClassLoader cl = Thread.currentThread().getContextClassLoader();

    /*
    // Load Classloader.
    if( false ){
      URL url = cl.getResource("classloader.xml");
      deployer.deploy( url );
    }

    // Load AOP.
    {
      URL url = cl.getResource("aop.xml");
      deployer.deploy( url );
    }
    */

    // Load the bean definitions.
		URL url = cl.getResource("jboss-beans.xml");
    deployer.deploy( url );

    
    KernelController cont = bootstrap.getKernel().getController();
    ControllerContext context = cont.getInstalledContext("myGarage");
    System.out.println( "I have a garage: "+context.getTarget());

    // Put some fuel in.
    Car myCar = (Car) cont.getInstalledContext("myCar").getTarget();
    myCar.setLitresOfFuel( myCar.getLitresOfFuel() + 1 );
    myCar.setReserveFuel( myCar.getReserveFuel() + 1 );
    System.out.println( "I have a garage: "+context.getTarget());


    deployer.shutdown();

  }

}
