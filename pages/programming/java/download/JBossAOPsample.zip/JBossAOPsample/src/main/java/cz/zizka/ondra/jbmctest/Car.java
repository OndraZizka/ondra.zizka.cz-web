
package cz.zizka.ondra.jbmctest;


/**
 *
 * @author Ondrej Zizka
 */
public class Car
{

  private String name;
  public String getName() {    return name;  }
  public void setName( String name ) {    this.name = name;  }

  public int litresOfFuel;
  public int getLitresOfFuel() {    return litresOfFuel;  }
  public void setLitresOfFuel( int litresOfFuel ) {    this.litresOfFuel = litresOfFuel;  }

  public int reserveFuel;
  public int getReserveFuel() {    return reserveFuel;  }
  public void setReserveFuel( int reserveFuel ) {    this.reserveFuel = reserveFuel;  }
  
  public String toString(){  return "Car \""+this.name+"\" with "+(this.litresOfFuel + this.reserveFuel)+" litres of fuel.";  }

}// class Car
